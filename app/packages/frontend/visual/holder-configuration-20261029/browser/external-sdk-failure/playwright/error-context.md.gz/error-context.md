# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: holder-configuration.spec.ts >> actual Next entrypoint uses the production reader and fails closed without RPC configuration
- Location: tests/holder-configuration.spec.ts:213:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 503
Received: 500
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - link "Skip to main content" [ref=e3] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "Application navigation" [ref=e4]:
      - generic [ref=e6]:
        - generic [ref=e7]:
          - link "Pump reconstruction home" [ref=e8] [cursor=pointer]:
            - /url: /
            - img "pump.fun logomark" [ref=e10]
          - button "Toggle Sidebar" [ref=e11] [cursor=pointer]
        - generic [ref=e14]:
          - navigation "Primary" [ref=e15]:
            - list [ref=e17]:
              - listitem [ref=e18]:
                - link "Home" [ref=e19] [cursor=pointer]:
                  - /url: /
              - listitem [ref=e23]:
                - link "Explore" [ref=e24] [cursor=pointer]:
                  - /url: /explore
              - listitem [ref=e27]:
                - button "Perps" [disabled]
              - listitem [ref=e28]:
                - link "Leaderboard" [ref=e29] [cursor=pointer]:
                  - /url: /leaderboard
              - listitem [ref=e32]:
                - link "Live" [ref=e33] [cursor=pointer]:
                  - /url: /live
            - list [ref=e38]:
              - listitem [ref=e39]:
                - link "GO" [ref=e40] [cursor=pointer]:
                  - /url: /go
              - listitem [ref=e43]:
                - link "Mayhem" [ref=e44] [cursor=pointer]:
                  - /url: /mayhem
              - listitem [ref=e47]:
                - link "Holder rewards" [ref=e48] [cursor=pointer]:
                  - /url: /holder-rewards
              - listitem [ref=e54]:
                - button "$PUMP" [disabled]
              - listitem [ref=e55]:
                - link "Portfolio" [ref=e56] [cursor=pointer]:
                  - /url: /portfolio
          - button "Create a coin" [ref=e60] [cursor=pointer]
        - list [ref=e64]:
          - listitem [ref=e65]:
            - button "Open settings" [ref=e66] [cursor=pointer]
          - listitem [ref=e70]:
            - button "Support (Intercom) is outside this reconstruction" [disabled]
          - listitem [ref=e71]:
            - button "Terminal" [disabled]
        - button "Toggle Sidebar" [ref=e73]
    - generic [ref=e75]:
      - banner [ref=e76]:
        - generic [ref=e78]:
          - generic [ref=e80]:
            - button "Go back" [ref=e81] [cursor=pointer]
            - search [ref=e85]:
              - button "Search for coins and users" [ref=e86] [cursor=pointer]:
                - generic [ref=e87]: Search for coins and users...
                - generic: ⌘K
            - button [disabled] [aria-hidden] [ref=e88]
          - generic [ref=e91]:
            - button "Create" [ref=e93] [cursor=pointer]
            - button "Sign in" [ref=e97] [cursor=pointer]
        - generic [ref=e99]:
          - button "Info bar settings" [disabled] [ref=e100]
          - radiogroup "Info bar content" [ref=e104]:
            - radio "Watchlist" [checked] [ref=e105] [cursor=pointer]
            - radio "Positions" [ref=e108] [cursor=pointer]
            - radio "Following" [ref=e111] [cursor=pointer]
            - radio "Recently viewed" [ref=e115] [cursor=pointer]
      - main [ref=e180]:
        - paragraph [ref=e181]: Pump reconstruction
        - heading "Holder rewards" [level=1] [ref=e182]
        - paragraph [ref=e183]: Derive a holder-rewards PDA locally without querying balances, eligibility or claims.
        - generic [ref=e184]:
          - generic [ref=e185]:
            - generic [ref=e186]:
              - generic [ref=e187]:
                - heading "Inspect a holder-rewards address" [level=2] [ref=e188]
                - paragraph [ref=e189]: Enter a Solana mint to compute its deterministic Pump holder-rewards PDA. Computation stays in this browser and does not query the chain.
              - generic [ref=e190]: Offline SDK computation
            - generic [ref=e191]:
              - text: Solana mint address
              - paragraph [ref=e192]: Whitespace is trimmed. A syntactically valid address does not prove that a mint or rewards account exists.
              - generic [ref=e193]:
                - textbox "Solana mint address" [ref=e194]:
                  - /placeholder: Enter a Base58 public key
                  - text: So11111111111111111111111111111111111111112
                - button "Derive address" [ref=e195] [cursor=pointer]
                - button "Clear" [ref=e196] [cursor=pointer]
          - region [ref=e197]:
            - generic [ref=e198]:
              - heading "Local derivation result" [level=2] [ref=e199]
              - generic [ref=e200]: Computed locally
            - generic [ref=e201]:
              - generic [ref=e202]:
                - paragraph [ref=e203]: Normalized mint
                - generic [ref=e204]:
                  - status [ref=e205]: So11111111111111111111111111111111111111112
                  - button "Copy normalized mint" [ref=e206] [cursor=pointer]: Copy
              - generic [ref=e207]:
                - paragraph [ref=e208]: Holder-rewards PDA
                - generic [ref=e209]:
                  - status [ref=e210]: 54SthQvXp5vQrse2JBjVUgsZVU3RrCtPAKQhqcn7XJnh
                  - button "Copy holder-rewards pda" [ref=e211] [cursor=pointer]: Copy
            - paragraph [ref=e212]:
              - text: "SDK derivation: seeds"
              - code [ref=e213]: "[\"holder-rewards\", mint]"
              - text: under the Pump program ID.
          - region [ref=e214]:
            - heading "Public holder-reward configuration" [level=2] [ref=e215]
            - paragraph [ref=e216]: Inspect the program's public Global and curve account records for this mint. Stored flags describe configuration; they do not establish reward eligibility, payout amounts or whether a transaction could succeed.
            - button "Read public configuration" [ref=e217] [cursor=pointer]
            - alert [ref=e218]: Public configuration is unavailable or unsupported. No eligibility is inferred.
          - region [ref=e219]:
            - generic [ref=e220]:
              - heading "Reward status" [level=2] [ref=e221]
              - paragraph [ref=e222]: These values remain unknown without authenticated live data.
            - generic [ref=e223]:
              - generic [ref=e224]:
                - paragraph [ref=e225]: Accrued rewards
                - paragraph [ref=e226]: Unavailable
                - paragraph [ref=e227]: Requires authenticated on-chain or service data.
              - generic [ref=e228]:
                - paragraph [ref=e229]: Claimed rewards
                - paragraph [ref=e230]: Unavailable
                - paragraph [ref=e231]: No payout history is loaded in this offline inspector.
              - generic [ref=e232]:
                - paragraph [ref=e233]: Claimable rewards
                - paragraph [ref=e234]: Unavailable
                - paragraph [ref=e235]: A derived PDA does not establish eligibility or balance.
          - region [ref=e236]:
            - heading "Offline trust boundary" [level=2] [ref=e237]
            - list [ref=e238]:
              - listitem [ref=e239]: Mint existence and Pump-coin status are not checked.
              - listitem [ref=e240]: Rewards configuration, ownership, accrual and eligibility are unknown.
              - listitem [ref=e241]: No wallet is connected and no transaction can be signed or submitted.
            - button "Claim unavailable in offline reconstruction" [disabled] [ref=e242]
          - status [ref=e243]
      - contentinfo [ref=e244]:
        - generic [ref=e245]:
          - paragraph [ref=e246]: © Pump.fun 2026
          - navigation "Footer" [ref=e247]:
            - link "Blog" [ref=e248] [cursor=pointer]:
              - /url: https://medium.com/@pumpdotfun_
            - button "Resources" [ref=e249] [cursor=pointer]
            - button "Legal" [ref=e252] [cursor=pointer]
          - generic [ref=e255]:
            - link "X" [ref=e256] [cursor=pointer]:
              - /url: https://twitter.com/pumpfun
            - link "TikTok" [ref=e259] [cursor=pointer]:
              - /url: https://www.tiktok.com/@pump.fun
            - link "YouTube" [ref=e262] [cursor=pointer]:
              - /url: https://www.youtube.com/@pumpfunofficial
  - generic [active]:
    - generic [ref=e267]:
      - generic [ref=e268]:
        - navigation [ref=e270]:
          - button [disabled] [ref=e271]:
            - img "previous" [ref=e272]
          - generic [ref=e274]:
            - generic [ref=e275]: 1/
            - generic [ref=e276]: "1"
          - button [disabled] [ref=e277]:
            - img "next" [ref=e278]
        - generic [ref=e281]:
          - generic "No Next.js version data was found." [ref=e284]: Next.js 16.4.1 (unknown)
          - generic [ref=e285]: Turbopack
      - dialog "Build Error" [ref=e287]:
        - generic [ref=e290]:
          - generic [ref=e292]:
            - generic [ref=e293]:
              - generic [ref=e294]: Build Error
              - generic [ref=e296]:
                - button "Copy Error Info" [ref=e297] [cursor=pointer]
                - button "No related documentation found" [disabled] [ref=e300]
                - button "Attach Node.js inspector" [ref=e303] [cursor=pointer]
            - generic [ref=e312]: Export default doesn't exist in target module
          - generic [ref=e315]:
            - generic [ref=e317]:
              - generic [ref=e321]: ./node_modules/.pnpm/@pump-fun+agent-payments-sdk@1.0.7_patch_hash=8820b68390474fb640cdde5bbccefc564ef216539_09834d3c05f28a99904c375566728a93/node_modules/@pump-fun/agent-payments-sdk/dist/index.js (1:19336)
              - button "Open in editor" [ref=e322] [cursor=pointer]
            - generic [ref=e327]:
              - generic [ref=e328]: "Error: Export default doesn't exist in target module"
              - text: ">"
              - generic [ref=e329]: 1 |
              - generic [ref=e330]: ...
              - text: m"@solana/spl-token";import
              - generic [ref=e331]: anchorCommonJs
              - text: from"@coral-xyz/anchor";const J=anchorCommonJ...
              - generic [ref=e332]: "|"
              - text: ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
              - generic [ref=e333]: 2 |
              - generic [ref=e334]: "... The export default was not found in module [project]/node_modules/.pnpm/@coral-xyz+anchor@0.31.1_bufferutil@4.1.0_typescript@5.9.3_utf-8-validate@6.0.6/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript). Did you mean to import validateAccounts? All exports of the module are statically known (It doesn't have dynamic exports). So it's known statically that the requested export doesn't exist. Import trace: App Route: ./node_modules/.pnpm/@pump-fun+agent-payments-sdk@1.0.7_patch_hash=8820b68390474fb640cdde5bbccefc564ef216539_09834d3c05f28a99904c375566728a93/node_modules/@pump-fun/agent-payments-sdk/dist/index.js ./packages/sdk/dist/index.mjs ./packages/frontend/src/app/holder-rewards-config/server.ts ./packages/frontend/src/app/holder-rewards-config/handler.ts ./packages/frontend/src/app/api/holder-rewards/configuration/route.ts"
    - generic [ref=e339] [cursor=pointer]:
      - button "Open Next.js Dev Tools" [ref=e340]
      - button "Open issues overlay" [ref=e345]:
        - generic [ref=e346]:
          - generic [aria-hidden] [ref=e347]: "0"
          - generic [ref=e348]: "1"
        - generic [ref=e349]: Issue
  - alert [ref=e350]
```

# Test source

```ts
  127 | });
  128 | 
  129 | test("failure/invalid identity hides provider detail and retry can return a fresh observation", async ({
  130 |   page,
  131 | }) => {
  132 |   let calls = 0;
  133 |   await page.route("**/api/holder-rewards/configuration?*", async (route) => {
  134 |     calls++;
  135 |     await route.fulfill(
  136 |       calls === 1
  137 |         ? {
  138 |             status: 503,
  139 |             json: { ok: false, error: { message: "private-provider-body" } },
  140 |           }
  141 |         : calls === 2
  142 |           ? { json: { ...payload(), mint: rewardsPda } }
  143 |           : { json: payload() },
  144 |     );
  145 |   });
  146 |   await derive(page);
  147 |   await read(page).click();
  148 |   const panel = page.getByTestId("holder-configuration");
  149 |   await expect(panel.getByRole("alert")).toContainText(
  150 |     "unavailable or unsupported",
  151 |   );
  152 |   await expect(panel).not.toContainText("private-provider-body");
  153 |   await read(page).click();
  154 |   await expect(panel.getByRole("alert")).toBeVisible();
  155 |   await read(page).click();
  156 |   await expect(page.getByTestId("holder-configuration-result")).toBeVisible();
  157 |   expect(calls).toBe(3);
  158 | });
  159 | 
  160 | test("mint edit discards pending configuration and clears previous fields", async ({
  161 |   page,
  162 | }) => {
  163 |   let release!: () => void, started!: () => void;
  164 |   const gate = new Promise<void>((resolve) => {
  165 |     release = resolve;
  166 |   });
  167 |   const pending = new Promise<void>((resolve) => {
  168 |     started = resolve;
  169 |   });
  170 |   await page.route("**/api/holder-rewards/configuration?*", async (route) => {
  171 |     started();
  172 |     await gate;
  173 |     await route.fulfill({ json: payload() }).catch(() => {});
  174 |   });
  175 |   await derive(page);
  176 |   await read(page).click();
  177 |   await pending;
  178 |   await page
  179 |     .getByLabel("Solana mint address", { exact: true })
  180 |     .fill("11111111111111111111111111111111");
  181 |   release();
  182 |   await expect(page.getByTestId("holder-configuration")).toHaveCount(0);
  183 |   await page
  184 |     .getByRole("button", { name: "Derive address", exact: true })
  185 |     .click();
  186 |   await expect(page.getByTestId("holder-configuration-result")).toHaveCount(0);
  187 | });
  188 | 
  189 | for (const width of [320, 1440])
  190 |   test(`configuration read remains contained at ${width}px`, async ({
  191 |     page,
  192 |   }) => {
  193 |     await page.setViewportSize({ width, height: width === 320 ? 640 : 900 });
  194 |     await page.route("**/api/holder-rewards/configuration?*", (route) =>
  195 |       route.fulfill({ json: payload(true) }),
  196 |     );
  197 |     await derive(page);
  198 |     await read(page).click();
  199 |     await expect(page.getByTestId("holder-configuration-result")).toBeVisible();
  200 |     expect(
  201 |       await page.evaluate(
  202 |         () => document.documentElement.scrollWidth <= innerWidth,
  203 |       ),
  204 |     ).toBe(true);
  205 |     await page
  206 |       .getByTestId("holder-configuration-result")
  207 |       .scrollIntoViewIfNeeded();
  208 |     await page.screenshot({
  209 |       path: `../../artifacts/holder-configuration-${width}.png`,
  210 |     });
  211 |   });
  212 | 
  213 | test("actual Next entrypoint uses the production reader and fails closed without RPC configuration", async ({
  214 |   page,
  215 | }) => {
  216 |   test.skip(
  217 |     process.env.HOLDER_CONFIG_TEST_NO_RPC !== "1",
  218 |     "Requires isolated runner with existing SOLANA_RPC_URL explicitly empty; no product test flag exists",
  219 |   );
  220 |   await derive(page);
  221 |   const responsePromise = page.waitForResponse(
  222 |     (response) =>
  223 |       new URL(response.url()).pathname === "/api/holder-rewards/configuration",
  224 |   );
  225 |   await read(page).click();
  226 |   const response = await responsePromise;
> 227 |   expect(response.status()).toBe(503);
      |                             ^ Error: expect(received).toBe(expected) // Object.is equality
  228 |   expect((await response.json()).error.code).toBe("RPC_CONFIGURATION_INVALID");
  229 |   expect(response.headers()["cache-control"]).toBe("no-store");
  230 |   await expect(
  231 |     page.getByTestId("holder-configuration").getByRole("alert"),
  232 |   ).toContainText("unavailable or unsupported");
  233 | });
  234 | 
```
#!/usr/bin/env python3
"""Replay the selected main-Pump checkpoint with its captured loader accounts."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from verify_pump_main_checkpoint import PACKAGE, ROOT, sha, verify


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, choices=range(1, 5), default=2)
    parser.add_argument('--shard', type=int, default=1)
    parser.add_argument('--shards', type=int, choices=range(1, 5), default=1)
    args = parser.parse_args()
    assert 1 <= args.shard <= args.shards
    verify(ROOT)
    package = ROOT / PACKAGE
    checkpoint = json.loads((package / 'CHECKPOINT.json').read_text())
    record = json.loads((package / 'canonical-build.json').read_text())
    # This is an explicit portable view of a proven identical source copy,
    # not a claim that CI executed another compiler invocation.
    record['portable_source_binding'] = {
        'kind': 'verified-equal-canonical-primary-source',
        'origin_build_record': PACKAGE + '/canonical-build.json',
        'origin_build_record_sha256': sha(package / 'canonical-build.json'),
        'original_compiled_source_sha256': record['source_sha256'],
    }
    record['source_directory'] = str(ROOT / 'programs/pump')
    record['source_sha256'] = {
        'programs/pump/' + name: digest
        for name, digest in checkpoint['primary_source_sha256'].items()
    }
    args.output = args.output.resolve()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    binding = args.output.with_name(args.output.name + '.source-binding.json')
    binding.write_text(json.dumps(record, indent=2) + '\n')
    command = [sys.executable, '-B', str(ROOT / 'scripts/pump_validate_parallel.py'),
               '--candidate', str(package / 'candidate.so'),
               '--source-directory', str(ROOT / 'programs/pump'),
               '--build-comparison', str(binding), '--output', str(args.output),
               '--captured-loader', '--workers', str(args.workers),
               '--shard', str(args.shard), '--shards', str(args.shards)]
    subprocess.run(command, cwd=ROOT, check=True)
    verify(ROOT)


if __name__ == '__main__':
    main()

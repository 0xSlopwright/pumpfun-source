"""Qualify unedited V3 function extraction against the captured compiler object."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,importlib.util,json,subprocess,time
D=Path(__file__).resolve().parent;W=D.parent;L=W/'l18';B=W/'pump-v3-branch-controls/12-bitcode-object'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
PINS={'llc.exe':'aff85aa14d18e21b98f6e17f9e4b80c26c5ed0948b9641af46d73881a3c2ab6d','llvm-extract.exe':'a0faf8ab2ee9df48db997a20d074a1b9a44cebea2bf1285139845403792ed750','llvm-dis.exe':'0206043b1be0735ede51a36b3696401e093a3d11864044f1f0c6023039873cf8'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    out=D/'qualified01';out.mkdir();tools=L/'build01/bin';env=json.loads((L/'attempt01/build-launch.json').read_bytes())['environment']
    assert all(sha(tools/n)==h for n,h in PINS.items());root=json.loads((B/'result.json').read_bytes());assert root['returncode']==0
    assert all(sha(B/n)==info['sha256'] for n,info in root['outputs'].items())
    commands=[('extract',[str(tools/'llvm-extract.exe'),'--func='+SYMBOL,'--keep-const-init',str(B/'root.bc'),'-o',str(out/'target.bc')],B/'root.bc',out/'target.bc'),
        ('compile',[str(tools/'llc.exe'),'-O3','-filetype=obj','-mcpu=generic','-mattr=+store-imm,+jmp-ext','-relocation-model=pic','-function-sections','-data-sections',str(out/'target.bc'),'-o',str(out/'target.o')],out/'target.bc',out/'target.o'),
        ('disassemble',[str(tools/'llvm-dis.exe'),str(out/'target.bc'),'-o',str(out/'target.ll')],out/'target.bc',out/'target.ll')]
    for label,command,input_path,output_path in commands:
        launch=dict(command=command,cwd=str(D),environment=env,tool_sha256=sha(Path(command[0])),input_sha256=sha(input_path),controller_sha256=sha(Path(__file__)),target_executions=0)
        save(out/(label+'-launch.json'),launch);start=time.time()
        with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
            r=subprocess.run(command,cwd=D,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        result=dict(returncode=r.returncode,seconds=time.time()-start,tool_unchanged=sha(Path(command[0]))==launch['tool_sha256'],input_unchanged=sha(input_path)==launch['input_sha256'],outputs={output_path.name:sha(output_path)} if output_path.exists() else {},logs={n:sha(out/(label+'.'+n)) for n in ['stdout','stderr']},target_executions=0)
        save(out/(label+'-result.json'),result);assert r.returncode==0 and result['input_unchanged'] and result['tool_unchanged'],label
    spec=importlib.util.spec_from_file_location('v3_inspect_codegen',L/'inspect_codegen.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.SYMBOL=SYMBOL
    stock,sb=m.target(B/'root.o');extracted,eb=m.target(out/'target.o');report=dict(stock=stock,extracted=extracted,target_raw_equal=sb==eb,relocations_equal=stock['relocations']==extracted['relocations'],whole_objects_equal=(B/'root.o').read_bytes()==(out/'target.o').read_bytes(),different_target_bytes=sum(i>=len(sb) or i>=len(eb) or sb[i]!=eb[i] for i in range(max(len(sb),len(eb)))),bitcode_sha256=sha(out/'target.bc'),target_executions=0)
    save(out/'comparison.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['stock','extracted']},indent=2),flush=True)
    assert report['target_raw_equal'] and report['relocations_equal']
if __name__=='__main__':main()

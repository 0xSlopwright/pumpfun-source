"""Retain the bounded diagnostic inputs, failures and outputs for offline review."""
from pathlib import Path
import gzip,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;C=W/'pump-v3-branch-controls';L=W/'l18'
P=W/'pumpfun-source/research/pump-v3-regalloc-20261029'
def main():
    P.mkdir(exist_ok=True);mapping={}
    def add(key,path):
        b=path.read_bytes();dest=P/'evidence'/(key+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(b,mtime=0))
        mapping[key]=dict(file=dest.relative_to(P).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    for n in ['launch.json','result.json','root.bc','root.o','symbols.so','stdout.log','stderr.log']:add('root/'+n,C/'12-bitcode-object'/n)
    for n in ['extract-launch.json','extract-result.json','compile-launch.json','compile-result.json','disassemble-launch.json','disassemble-result.json','extract.stdout','extract.stderr','compile.stdout','compile.stderr','disassemble.stdout','disassemble.stderr','target.bc','target.o','target.ll','comparison.json']:add('extracted/'+n,D/'qualified01'/n)
    for n in ['launch.json','result.json','stderr.log','stdout.log','target.o']:add('trace/'+n,D/'greedy01'/n)
    for p in (D/'mir-resume01').iterdir():
        if p.is_file():add('mir/'+p.name,p)
    for mode in ['off','on']:
        for p in (D/'counterfactual01'/mode).iterdir():
            if p.is_file():add('counterfactual/'+mode+'/'+p.name,p)
    add('counterfactual/comparison.json',D/'counterfactual01/comparison.json')
    for n in ['analysis.json','relocation-binding.json','verification.json','counterfactual-analysis.json']:add(n,D/n)
    for n in ['build-launch.json','build-result.json','stock-commands.json','response-provenance.json','LLVMCodeGen.rsp','counterfactual.patch','RegAllocGreedy.cpp','stock-build-before.json','compile.stdout','compile.stderr','archive.stdout','archive.stderr','link.stdout','link.stderr']:add('derivative/'+n,D/'derivative02'/n)
    add('compiler/source-inventory.json',L/'source-inventory.json')
    for n in ['llvm/lib/CodeGen/RegAllocGreedy.cpp','llvm/lib/CodeGen/SplitKit.cpp','llvm/lib/CodeGen/EdgeBundles.cpp','llvm/lib/Support/IntEqClasses.cpp']:add('compiler/'+n,L/'source'/n)
    for n in ['qualify.py','trace.py','qualify_mir_resume.py','bind_relocations.py','analyze.py','verify_evidence.py','build_counterfactual.py','build_counterfactual_failed01.py','run_counterfactual.py','analyze_counterfactual.py','package.py']:add('controllers/'+n,D/n)
    add('controllers/capture_candidate_bitcode.py',C/'capture_candidate_bitcode.py')
    add('controllers/build_scheduler_probe.py',L/'build_scheduler_probe.py')
    for key,path in [('root.err',C/'12-bitcode-object.err'),('extraction.err',D/'qualification.err'),('mir.err',D/'mir-resume01.err'),('derivative-preparation.err',D/'derivative-build.err')]:add('failed/'+key,path)
    add('failed/stock-commands.json',D/'derivative01/stock-commands.json')
    (P/'EVIDENCE.json').write_bytes((json.dumps(mapping,indent=2)+'\n').encode())
    print(json.dumps(dict(files=len(mapping),compressed_bytes=sum((P/x['file']).stat().st_size for x in mapping.values())),indent=2))
if __name__=='__main__':main()

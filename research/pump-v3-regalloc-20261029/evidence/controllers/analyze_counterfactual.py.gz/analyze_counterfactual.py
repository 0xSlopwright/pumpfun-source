"""Independently inspect the retained diagnostic; never executes compiler/target."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import importlib.util,json,re,struct
D=Path(__file__).resolve().parent;W=D.parent
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
    c=load('cf_controller',D/'run_counterfactual.py');m=load('cf_inspect',W/'l18/inspect_codegen.py');m.SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
    original=m.audit.Elf(W/'pumpfun-source/evidence/original/pump/deployed.so');ob=original.body(0x80df8,2120);on=original.normalize(ob,0x80df8)[0]
    base,bb=m.target(D/'qualified01/target.o');probe,pb=m.target(D/'counterfactual01/on/target.o');pn=c.normalized(pb,probe['relocations'])
    assert len(pn)==len(on)==2120
    changes=[dict(offset=i,original=on[i:i+8].hex(),counterfactual=pn[i:i+8].hex()) for i in range(0,len(on),8) if on[i:i+8]!=pn[i:i+8]]
    assert c.distance(on,pn)==2 and len(changes)==2
    def refs(rows):return [(r['type'],r['symbol'],r['addend']) for r in rows]
    assert refs(base['relocations'])==refs(probe['relocations']) and len(probe['relocations'])==33
    text=(D/'counterfactual01/on/stderr.log').read_text();marker='V3_SPLIT_COUNTERFACTUAL original=%23 previous=$r9 forced=$r3'
    assert text.count(marker)==1
    choice=re.search(r'^selectOrSplit GPR:%23 .*?'+re.escape(marker)+r'.*?(?=^selectOrSplit)',text,re.M|re.S)[0]
    assert 'Split for $r3 in 1 bundles, intv 1.' in choice and 'live-through 0 -> 1, reload on exit.' not in choice
    cfrows={}
    for label,raw in [('original',ob),('counterfactual',pb)]:
        calls=[i for i,b in m.audit.instructions(raw) if b[0]==0x85 and b[1]>>4==1];assert len(calls)==17
        call=calls[7];branch=call+24;assert raw[branch]==5
        payload=branch+8+8*struct.unpack_from('<h',raw,branch+2)[0];assert raw[payload]==0x79 and raw[payload+8]==5
        tail=payload+16+8*struct.unpack_from('<h',raw,payload+10)[0]
        cfrows[label]=dict(pre_fee_call=call,error_branch=branch,payload_load=payload,shared_tail=tail,sp400=[dict(offset=i,register=b[1]&15) for i,b in m.audit.instructions(raw) if b[0]==0x79 and b[1]>>4==10 and struct.unpack_from('<h',b,2)[0]==-400])
    assert cfrows['original']==cfrows['counterfactual']
    report=dict(result='PASS',candidate_bytes=len(bb),counterfactual_bytes=len(pb),aligned_slot_distance=2,normalized_changed_bytes=sum(a!=b for a,b in zip(on,pn)),aligned_differences=changes,ordered_33_relocation_targets_preserved=True,changed_offsets=[dict(before=a['offset'],after=b['offset']) for a,b in zip(base['relocations'],probe['relocations']) if a['offset']!=b['offset']],tail=cfrows,trace_interventions=1,
        interpretation='Selecting the already evaluated r3 region for original virtual23 is sufficient to restore the original target length and observed return-pointer/error-tail placement in this extracted diagnostic. Two normalized slots still differ. This does not identify a recovered Rust spelling or original compiler recipe; no linked original-byte or behavioral identity is claimed.')
    c.save(D/'counterfactual-analysis.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':main()

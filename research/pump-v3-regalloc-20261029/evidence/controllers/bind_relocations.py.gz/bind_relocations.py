"""Explain extraction linkage spelling using complete referenced object bytes."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,importlib.util,json,struct
D=Path(__file__).resolve().parent;W=D.parent;L=W/'l18';B=W/'pump-v3-branch-controls/12-bitcode-object';Q=D/'qualified01'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    spec=importlib.util.spec_from_file_location('v3_inspect_binding',L/'inspect_codegen.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
    objects=[m.audit.Elf(B/'root.o'),m.audit.Elf(Q/'target.o')]
    def desc(e,name):
        fs=[s for s in e.symbols if s['name']==name];assert len(fs)==1,(name,fs);s=fs[0]
        assert s['size']>0 and s['section']>0;sct=e.headers[s['section']];start=sct[4]+s['address']-sct[3];data=e.data[start:start+s['size']];assert len(data)==s['size'];rows=[]
        for h in e.headers:
            if h[1] not in [4,9] or h[7]!=s['section']:continue
            table=e.headers[h[6]];strings=e.headers[table[6]]
            for offset in range(h[4],h[4]+h[5],h[9]):
                address,info=struct.unpack_from('<QQ',e.data,offset)
                if not s['address']<=address<s['address']+s['size']:continue
                sym=struct.unpack_from('<IBBHQQ',e.data,table[4]+24*(info>>32));p=strings[4]+sym[0];target=e.data[p:e.data.index(b'\0',p)].decode()
                rows.append(dict(offset=address-s['address'],type=info&0xffffffff,symbol=target,addend=struct.unpack_from('<q',e.data,offset+16)[0] if h[1]==4 else None))
        return dict(symbol=name,bytes=s['size'],sha256=sha(data),relocations=rows),data
    a,ab=m.target(B/'root.o');b,bb=m.target(Q/'target.o');assert ab==bb and len(a['relocations'])==len(b['relocations'])==33
    aliases={};bound=[]
    def bind_symbol(left,right):
        if left==right:return
        assert left=='.L'+right and right.startswith(('alloc_','vtable.')),(left,right)
        if left in aliases:assert aliases[left]==right;return
        aliases[left]=right;x,xb=desc(objects[0],left);y,yb=desc(objects[1],right);assert xb==yb,(left,'object bytes')
        assert len(x['relocations'])==len(y['relocations'])
        for u,v in zip(x['relocations'],y['relocations']):
            assert {k:u[k] for k in ['offset','type','addend']}=={k:v[k] for k in ['offset','type','addend']}
            bind_symbol(u['symbol'],v['symbol'])
        bound.append(dict(stock=x,extracted=y,full_object_bytes_equal=True))
    for x,y in zip(a['relocations'],b['relocations']):
        assert {k:x[k] for k in ['offset','type','addend']}=={k:y[k] for k in ['offset','type','addend']}
        bind_symbol(x['symbol'],y['symbol'])
    report=dict(result='PASS',target_raw_equal=True,target_bytes=len(ab),target_relocations=33,literal_relocation_rows_equal=False,aliases=aliases,bound_constant_objects=bound,
        scope='Unedited function extraction preserves raw target bytes and relocation offsets/types/addends. LLVM extraction promotes local constant linkage, changing .L-prefixed names. Every changed constant name is bound through complete object bytes and recursively checked constant relocations. Unchanged external function names remain symbolic references; this is not whole-object identity or recursive function-body qualification.',compiler_commands=0,target_executions=0)
    save(D/'relocation-binding.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['bound_constant_objects','aliases']},indent=2))
if __name__=='__main__':main()

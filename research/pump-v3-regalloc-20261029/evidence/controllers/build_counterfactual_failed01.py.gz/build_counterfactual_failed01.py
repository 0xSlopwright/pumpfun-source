"""Build an isolated, opt-in allocator counterfactual from existing stock objects."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import difflib,hashlib,importlib.util,json,re,subprocess,time
D=Path(__file__).resolve().parent;L=D.parent/'l18';B=L/'build01';O=D/'derivative01';REL='llvm/lib/CodeGen/RegAllocGreedy.cpp'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def inv(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def main():
    O.mkdir();(O/'temp').mkdir();(O/'int').mkdir()
    helper=L/'build_scheduler_probe.py';spec=importlib.util.spec_from_file_location('isolated_llvm_helpers',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    cache=(B/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.*)$',cache,re.M)[1]
    targets=dict(compile=r'lib/CodeGen/CMakeFiles/LLVMCodeGen.dir/RegAllocGreedy.cpp.obj',archive=r'lib/LLVMCodeGen.lib',link=r'bin/llc.exe');stock_commands={}
    for name,target in targets.items():
        lines=subprocess.check_output([ninja,'-t','commands',target],cwd=B).decode().splitlines();stock_commands[name]=lines[-1]
    save(O/'stock-commands.json',stock_commands)
    stock=(L/'source'/REL).read_text();assert stock.count('#define DEBUG_TYPE "regalloc"')==1
    modified=stock.replace('#define DEBUG_TYPE "regalloc"','#define DEBUG_TYPE "regalloc"\n\n// Isolated diagnostic only; disabled by default and never a recovered recipe.\nstatic cl::opt<bool> V3DiagnosticForceR3("v3-diagnostic-force-r3", cl::Hidden,\n    cl::init(false), cl::desc("Diagnostic V3 return-pointer region counterfactual"));')
    a=modified.index('unsigned RAGreedy::calculateRegionSplitCost(const LiveInterval');b=modified.index('\nunsigned RAGreedy::doRegionSplit',a);piece=modified[a:b];assert piece.count('  return BestCand;')==1
    hook='''  if (V3DiagnosticForceR3 && MF->getName() == "'''+SYMBOL+'''" &&
      VirtReg.reg() == Register::index2VirtReg(23)) {
    unsigned Forced = NoCand;
    for (unsigned I = 0; I < NumCands; ++I)
      if (GlobalCand[I].PhysReg &&
          StringRef(TRI->getName(GlobalCand[I].PhysReg)) == "R3") {
        Forced = I;
        break;
      }
    assert(Forced != NoCand && "Expected an evaluated r3 split candidate");
    LLVM_DEBUG(dbgs() << "V3_SPLIT_COUNTERFACTUAL original=%23 previous="
                      << printReg(GlobalCand[BestCand].PhysReg, TRI)
                      << " forced=" << printReg(GlobalCand[Forced].PhysReg, TRI)
                      << "\\n");
    BestCand = Forced;
  }
  return BestCand;'''
    modified=modified[:a]+piece.replace('  return BestCand;',hook)+modified[b:];source=O/'RegAllocGreedy.cpp';source.write_bytes(modified.encode())
    (O/'counterfactual.patch').write_text(''.join(difflib.unified_diff(stock.splitlines(True),modified.splitlines(True),fromfile=REL,tofile=REL)),encoding='utf-8')
    compile=m.argv(stock_commands['compile']);archive=m.argv(m.inner(stock_commands['archive']));link=m.argv(m.inner(stock_commands['link']))
    assert Path(compile[-1]).resolve()==(L/'source'/REL).resolve();compile[-1]=str(source)
    for i,arg in enumerate(compile):
        if arg.startswith('/Fo'):compile[i]='/Fo'+str(O/'RegAllocGreedy.cpp.obj')
        elif arg.startswith('/Fd'):compile[i]='/Fd'+str(O/'RegAllocGreedy.pdb')
    obj=r'lib\CodeGen\CMakeFiles\LLVMCodeGen.dir\RegAllocGreedy.cpp.obj';assert archive.count(obj)==1
    archive=[str(O/'RegAllocGreedy.cpp.obj') if x==obj else '/out:'+str(O/'LLVMCodeGen.lib') if x.lower().startswith('/out:') else x for x in archive]
    assert link.count(r'lib\LLVMCodeGen.lib')==2
    for i,arg in enumerate(link):
        if arg.startswith('--intdir='):link[i]='--intdir='+str(O/'int')
        elif arg.lower().startswith('/out:'):link[i]='/out:'+str(O/'llc.exe')
        elif arg.lower().startswith('/implib:'):link[i]='/implib:'+str(O/'llc.lib')
        elif arg.lower().startswith('/pdb:'):link[i]='/pdb:'+str(O/'llc.pdb')
        elif arg==r'lib\LLVMCodeGen.lib':link[i]=str(O/'LLVMCodeGen.lib')
    for command in [compile,archive,link]:
        for arg in command:
            for prefix in ['/Fo','/Fd','/out:','/implib:','/pdb:','--intdir=']:
                if arg.startswith(prefix):assert Path(arg[len(prefix):]).resolve().is_relative_to(O)
    env=json.loads((L/'attempt01/build-launch.json').read_bytes())['environment'];env.update(TEMP=str(O/'temp'),TMP=str(O/'temp'))
    source_inventory=json.loads((L/'source-inventory.json').read_bytes());assert inv(L/'source')==source_inventory
    before=inv(B);save(O/'stock-build-before.json',before)
    plan=dict(llvm_revision='08aedd64bf3abe4f163407b7bcf680403b84b32d',stock_source_sha256=sha(L/'source'/REL),derivative_source_sha256=sha(source),patch_sha256=sha(O/'counterfactual.patch'),helper_sha256=sha(helper),controller_sha256=sha(Path(__file__)),commands=dict(compile=compile,archive=archive,link=link),cwd=str(B),environment=env,
        scope='Opt-in diagnostic intervention in one evaluated split-region choice for V3 costs virtual return pointer23. Default-off output must equal stock; enabled result is not recovered Rust or an original compiler recipe. All stock sources, objects and tools must remain unchanged.')
    save(O/'build-launch.json',plan);results=[]
    for name,command in plan['commands'].items():
        start=time.time()
        with (O/(name+'.stdout')).open('wb') as stdout,(O/(name+'.stderr')).open('wb') as stderr:p=subprocess.run(command,cwd=B,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        row=dict(stage=name,returncode=p.returncode,seconds=time.time()-start,logs={n:sha(O/(name+'.'+n)) for n in ['stdout','stderr']});results.append(row);save(O/'build-progress.json',results);print(json.dumps(row),flush=True)
        if p.returncode:break
    result=dict(stages=results,stock_build_unchanged=inv(B)==before,stock_source_unchanged=inv(L/'source')==source_inventory,outputs={n:sha(O/n) for n in ['RegAllocGreedy.cpp.obj','LLVMCodeGen.lib','llc.exe'] if (O/n).exists()})
    save(O/'build-result.json',result);assert len(results)==3 and all(r['returncode']==0 for r in results) and result['stock_build_unchanged'] and result['stock_source_unchanged']
    print(json.dumps(dict(result='PASS',tool_sha256=result['outputs']['llc.exe'],stock_build_unchanged=True,stock_source_unchanged=True)),flush=True)
if __name__=='__main__':main()

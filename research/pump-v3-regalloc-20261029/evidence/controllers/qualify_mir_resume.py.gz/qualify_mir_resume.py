"""Require unchanged machine-IR resume output before any isolated counterfactual."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;Q=D/'qualified01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    out=D/'mir-resume01';out.mkdir();parent=json.loads((Q/'compile-launch.json').read_bytes());base=parent['command'];env=parent['environment']
    commands=[('capture',[*base[:-3],str(Q/'target.bc'),'-stop-before=greedy','-o',str(out/'before.mir')],Q/'target.bc',out/'before.mir'),
        ('resume',[*base[:-3],str(out/'before.mir'),'-start-before=greedy','-o',str(out/'target.o')],out/'before.mir',out/'target.o')]
    for label,cmd,input_path,output_path in commands:
        launch=dict(command=cmd,cwd=str(D),environment=env,tool_sha256=sha(Path(cmd[0])),input_sha256=sha(input_path),controller_sha256=sha(Path(__file__)),target_executions=0);save(out/(label+'-launch.json'),launch);start=time.time()
        with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:p=subprocess.run(cmd,cwd=D,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        result=dict(returncode=p.returncode,seconds=time.time()-start,input_unchanged=sha(input_path)==launch['input_sha256'],tool_unchanged=sha(Path(cmd[0]))==launch['tool_sha256'],outputs={output_path.name:sha(output_path)} if output_path.exists() else {},logs={n:sha(out/(label+'.'+n)) for n in ['stdout','stderr']})
        save(out/(label+'-result.json'),result);assert p.returncode==0,label
    a=(Q/'target.o').read_bytes();b=(out/'target.o').read_bytes();report=dict(whole_extracted_object_equal=a==b,normal_sha256=sha(Q/'target.o'),resumed_sha256=sha(out/'target.o'),compiler_commands=2,target_executions=0)
    save(out/'comparison.json',report);print(json.dumps(report,indent=2));assert a==b,'MIR resume is not a qualified identical baseline'
if __name__=='__main__':main()

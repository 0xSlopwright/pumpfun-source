"""Replay local compiler-evidence bindings without running any compiler or target."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
D=Path(__file__).resolve().parent;W=D.parent;C=W/'pump-v3-branch-controls';P=W/'pumpfun-source/research/pump-v3-branch-layout-20261029';B=C/'12-bitcode-object'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    v_spec=importlib.util.spec_from_file_location('regalloc_evidence_v',P/'verify.py');v=importlib.util.module_from_spec(v_spec);v_spec.loader.exec_module(v)
    normal=read(C/'07-remapped-if-let/launch.json');launch=read(B/'launch.json');result=read(B/'result.json');expected=[x.replace(str(C/'07-remapped-if-let'),str(B)) for x in normal['command']]
    expected[expected.index('--emit=dep-info,link')]='--emit=dep-info,link,llvm-bc,obj';assert launch['command']==expected
    assert launch['environment']=={k:x.replace(str(C/'07-remapped-if-let'),str(B)) for k,x in normal['environment'].items()}
    assert launch['source_inputs']==normal['source_inputs']=={p.relative_to(B/'source').as_posix():sha(p) for p in (B/'source').rglob('*') if p.is_file()}
    assert launch['tools']==normal['tools'] and launch['dependency_files']==normal['dependency_files'] and launch['controller_sha256']==sha(C/'capture_candidate_bitcode.py')
    assert result['returncode']==0 and result['whole_output_equal'] is False and all(result[k] for k in ['source_unchanged','tools_unchanged','dependencies_unchanged'])
    assert all(sha(B/p)==info['sha256'] and (B/p).stat().st_size==info['bytes'] for p,info in result['outputs'].items())
    assert all(sha(B/p)==info['sha256'] and (B/p).stat().st_size==info['bytes'] for p,info in result['logs'].items())
    api=v.elf_reader();normal_elf=api.Elf(C/'07-remapped-if-let/symbols.so');capture=api.Elf(B/'symbols.so');original=api.Elf(W/'pumpfun-source/evidence/original/pump/deployed.so')
    nr,nn,_,nd=v.metrics(normal_elf,original);cr,cn,_,cd=v.metrics(capture,original);assert nr==cr and len(cr)==2136 and nd==cd==23
    assert normal_elf.sections.keys()==capture.sections.keys()
    differences=[k for k in normal_elf.sections if normal_elf.section_bytes(k)!=capture.section_bytes(k)];assert set(differences)=={'.strtab','.symtab'}
    audit=v.reference_audit(W/'pumpfun-source',normal_elf.data,capture.data);saved=read(C/'12-reference-audit.json');assert audit['calls']==saved['calls'] and audit['data']==saved['data']
    q=D/'qualified01';comparison=read(q/'comparison.json');assert comparison['target_raw_equal'] is True and comparison['relocations_equal'] is False
    for label,inp,out in [('extract',B/'root.bc',q/'target.bc'),('compile',q/'target.bc',q/'target.o'),('disassemble',q/'target.bc',q/'target.ll')]:
        l=read(q/(label+'-launch.json'));r=read(q/(label+'-result.json'));assert r['returncode']==0 and l['input_sha256']==sha(inp) and r['outputs'][out.name]==sha(out)
        assert sha(Path(l['command'][0]))==l['tool_sha256'] and all(sha(q/(label+'.'+n))==h for n,h in r['logs'].items())
    trace=read(D/'greedy01/launch.json');tr=read(D/'greedy01/result.json');assert tr['returncode']==0 and tr['whole_extracted_object_equal']
    assert trace['input_sha256']==sha(q/'target.bc') and sha(Path(trace['command'][0]))==trace['tool_sha256']
    assert (D/'greedy01/target.o').read_bytes()==(q/'target.o').read_bytes()
    expected=read(q/'compile-launch.json')['command'];expected[-1]=str(D/'greedy01/target.o');expected+=['-debug-only=regalloc','-print-before=greedy','-print-after=greedy','-filter-print-funcs=_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'];assert trace['command']==expected
    assert all(sha(D/'greedy01'/p)==i['sha256'] and (D/'greedy01'/p).stat().st_size==i['bytes'] for p,i in tr['logs'].items())
    for name in ['bind_relocations.py','analyze.py']:
        r=subprocess.run([sys.executable,'-I','-B',str(D/name)],capture_output=True);assert r.returncode==0,r.stderr[-500:]
    spec=importlib.util.spec_from_file_location('regalloc_negative',W/'l18/inspect_codegen.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
    _,a=m.target(q/'target.o');_,b=m.target(D/'mir-resume01/target.o');assert len(a)==len(b)==2136 and sum(x!=y for x,y in zip(a,b))==243
    report=dict(result='PASS',source_inputs=66,extra_emit_whole_output_equal=False,extra_emit_target_raw_equal=True,changed_section_contents=differences,elf_headers_not_claimed_equal=True,
        extracted_target_raw_equal=True,extracted_constant_relocations_bound=True,debug_whole_extracted_object_equal=True,structural_before_after_stages_equal=True,mir_resume_target_raw_equal=False,
        observed_region='r9',printed_margin_to_r3=read(D/'analysis.json')['printed_cost_margin_to_r3'],rustc_commands=1,llc_commands=4,other_llvm_commands=2,target_executions=0,
        scope='Local diagnostic evidence. No compiler or target ran during this verifier, no source improvement or original-byte recovery is claimed.')
    save(D/'verification.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':main()

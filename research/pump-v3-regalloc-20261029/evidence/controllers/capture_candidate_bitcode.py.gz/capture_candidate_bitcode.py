"""Retain candidate optimized bitcode/object and qualify emitted ELF; no SBF execution."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,json,shutil,subprocess,time
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def inv(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def main():
    base=D/'07-remapped-if-let';out=D/'12-bitcode-object';out.mkdir();shutil.copytree(base/'source',out/'source');shutil.copytree(base/'target',out/'target');(out/'temp').mkdir()
    parent=read(base/'launch.json');inputs=inv(out/'source');assert inputs==parent['source_inputs'] and len(inputs)==66
    command=[x.replace(str(base),str(out)) for x in parent['command']];env={k:v.replace(str(base),str(out)) for k,v in parent['environment'].items()}
    assert command.count('--emit=dep-info,link')==1;command[command.index('--emit=dep-info,link')]='--emit=dep-info,link,llvm-bc,obj'
    tools=parent['tools'];deps=parent['dependency_files'];assert all(sha(Path(p))==h for p,h in tools.items());assert all(sha(out/'target'/p)==h for p,h in deps.items())
    save(out/'launch.json',dict(command=command,cwd=str(out/'source'),environment=env,source_inputs=inputs,tools=tools,dependency_files=deps,parent=base.name,controller_sha256=sha(Path(__file__)),compiler_commands=1,target_executions=0,
        changed_emit='dep-info,link,llvm-bc,obj',hypothesis='Capture unchanged candidate optimized bitcode and relocatable object to inspect the observed return-pointer allocation using the already qualified pinned standalone LLVM. Require complete normal ELF equality before treating additional emitted artifacts as the same candidate; no compiler mutation or target execution.'))
    start=time.time()
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        r=subprocess.run(command,cwd=out/'source',env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    result=dict(returncode=r.returncode,seconds=time.time()-start,source_unchanged=inputs==inv(out/'source'),tools_unchanged=all(sha(Path(p))==h for p,h in tools.items()),dependencies_unchanged=all(sha(out/'target'/p)==h for p,h in deps.items()),logs={p:dict(sha256=sha(out/p),bytes=(out/p).stat().st_size) for p in ['stdout.log','stderr.log']},target_executions=0)
    if r.returncode==0:
        output={}
        for suffix,name in [('bc','root.bc'),('o','root.o'),('so','symbols.so')]:
            p=out/'target/sbpf-solana-solana/release/deps'/('pump_recovered.'+suffix);assert p.is_file();shutil.copyfile(p,out/name);output[name]=dict(sha256=sha(out/name),bytes=(out/name).stat().st_size)
        result.update(outputs=output,whole_output_equal=(out/'symbols.so').read_bytes()==(base/'symbols.so').read_bytes())
    save(out/'result.json',result);print(json.dumps(result,indent=2),flush=True)
    assert result['returncode']==0 and all(result[k] for k in ['source_unchanged','tools_unchanged','dependencies_unchanged','whole_output_equal'])
if __name__=='__main__':main()

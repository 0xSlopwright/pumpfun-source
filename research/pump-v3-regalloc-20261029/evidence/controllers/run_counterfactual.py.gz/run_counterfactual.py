"""Run a qualified default-off control and one opt-in allocator diagnostic."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import difflib,hashlib,importlib.util,json,struct,subprocess,time
D=Path(__file__).resolve().parent;W=D.parent;Q=D/'qualified01';DER=D/'derivative02'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def normalized(raw,relocs):
    out=bytearray(raw)
    for r in relocs:
        p=r['offset'];assert r['addend'] is None
        if r['type']==10:
            assert raw[p:p+2]==b'\x85\x10';out[p+4:p+8]=b'\0'*4
        else:
            assert r['type']==1 and raw[p]==0x18;out[p+4:p+8]=out[p+12:p+16]=b'\0'*4
    return bytes(out)
def distance(a,b):
    split=lambda b:[b[i:i+8] for i in range(0,len(b),8)]
    ops=difflib.SequenceMatcher(None,split(a),split(b),autojunk=False).get_opcodes()
    return sum(max(j-i,l-k) for t,i,j,k,l in ops if t!='equal')
def main():
    build=read(DER/'build-result.json');assert all(build[k] for k in ['stock_build_unchanged','stock_source_unchanged'])
    tool=DER/'llc.exe';assert sha(tool)==build['outputs']['llc.exe']
    parent=read(Q/'compile-launch.json');root=D/'counterfactual01';root.mkdir()
    m=load('counterfactual_elf',W/'l18/inspect_codegen.py');m.SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
    original=m.audit.Elf(W/'pumpfun-source/evidence/original/pump/deployed.so');on=original.normalize(original.body(0x80df8,2120),0x80df8)[0]
    captured=m.audit.Elf(W/'pump-v3-branch-controls/07-remapped-if-let/symbols.so');f=next(f for f in captured.functions if f['name']==m.SYMBOL);cn=captured.normalize(captured.body(f['address'],f['size']),f['address'])[0]
    baseline,bb=m.target(Q/'target.o');assert normalized(bb,baseline['relocations'])==cn
    rows={}
    for mode,flags in [('off',[]),('on',['-v3-diagnostic-force-r3','-debug-only=regalloc','-print-before=greedy','-print-after=greedy','-filter-print-funcs='+m.SYMBOL])]:
        out=root/mode;out.mkdir();cmd=parent['command'].copy();cmd[0]=str(tool);cmd[-1]=str(out/'target.o');cmd+=flags
        launch=dict(command=cmd,cwd=str(D),environment=parent['environment'],tool_sha256=sha(tool),input_sha256=sha(Q/'target.bc'),controller_sha256=sha(Path(__file__)),target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:p=subprocess.run(cmd,cwd=D,env=parent['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        result=dict(returncode=p.returncode,seconds=time.time()-start,tool_unchanged=sha(tool)==launch['tool_sha256'],input_unchanged=sha(Q/'target.bc')==launch['input_sha256'],logs={n:sha(out/n) for n in ['stdout.log','stderr.log']},target_executions=0)
        if (out/'target.o').exists():result['object_sha256']=sha(out/'target.o')
        save(out/'result.json',result);assert p.returncode==0 and result['tool_unchanged'] and result['input_unchanged']
        info,raw=m.target(out/'target.o');norm=normalized(raw,info['relocations'])
        loads=[dict(offset=i,destination_register=b[1]&15,raw=b.hex()) for i,b in m.audit.instructions(raw) if b[0]==0x79 and b[1]>>4==10 and struct.unpack_from('<h',b,2)[0]==-400]
        row=dict(object_sha256=sha(out/'target.o'),whole_object_equal=(out/'target.o').read_bytes()==(Q/'target.o').read_bytes(),target_bytes=len(raw),target_raw_sha256=hashlib.sha256(raw).hexdigest(),normalized_sha256=hashlib.sha256(norm).hexdigest(),aligned_slots_from_original=distance(on,norm),aligned_slots_from_candidate=distance(cn,norm),SP400_loads=loads,relocations=info['relocations'])
        rows[mode]=row;save(root/'comparison.json',rows)
        print(json.dumps({k:v for k,v in row.items() if k!='relocations'},indent=2),flush=True)
        if mode=='off':assert row['whole_object_equal'] and row['aligned_slots_from_original']==23
    rows['scope']='Opt-in diagnostic intervention, not recovered Rust or an original compiler recipe. Only relocation operands are normalized; literal target bytes and all relocation rows are retained. No linked/full ELF or behavioral identity is claimed.'
    save(root/'comparison.json',rows)
if __name__=='__main__':main()

"""Bind qualified Greedy diagnostics to candidate stages and rederive edge bundles."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
from decimal import Decimal
import difflib,hashlib,json,re
D=Path(__file__).resolve().parent;W=D.parent;L=W/'l18';C=W/'pump-v3-branch-controls';G=D/'greedy01'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def machine(text,stage):
    marker=f'# *** IR Dump {stage} Greedy Register Allocator (greedy) ***:'
    assert text.count(marker)==1;start=text.index('# Machine code for function',text.index(marker));end=text.index('# End machine code for function',start);end=text.index('\n',end)
    return text[start:end]
def view(text):
    rows=[];constants={}
    for line in text.splitlines():
        line=line.split(' :: ')[0]
        line=re.sub(r'^(\d+B)\s+bb\.(\d+).*',r'\1 bb.\2',line)
        line=re.sub(r'(%stack\.\d+)(?:\.[\w.$]+)?',r'\1',line)
        def symbol(m):
            name=m[1]
            if name not in constants:constants[name]=len(constants)
            return 'LD_imm64 @constant'+str(constants[name])
        line=re.sub(r'LD_imm64 @(\S+)',symbol,line)
        line=' '.join(line.split())
        if line:rows.append(line)
    return rows,constants
def edge_bundles(before):
    blocks={};current=None
    for line in before.splitlines():
        m=re.match(r'^\d+B\s+bb\.(\d+)',line)
        if m:current=int(m[1]);blocks[current]=[]
        if 'successors:' in line:
            blocks[current]=[int(n) for n in re.findall(r'%bb\.(\d+)\(',line.split(';')[0])]
    assert list(blocks)==list(range(38));parents=list(range(76))
    def root(n):
        while parents[n]!=n:n=parents[n]
        return n
    for b,succs in blocks.items():
        for succ in succs:
            x,y=root(2*b+1),root(2*succ);parents[max(x,y)]=min(x,y)
    roots=sorted({root(n) for n in range(76)});ids={r:i for i,r in enumerate(roots)}
    mapping={b:dict(incoming=ids[root(2*b)],outgoing=ids[root(2*b+1)],successors=succs) for b,succs in blocks.items()}
    return mapping,len(roots)
def main():
    raw=(G/'stderr.log').read_bytes();text=raw.decode().replace('\r\n','\n');result=read(G/'result.json');assert sha(raw)==result['logs']['stderr.log']['sha256'] and result['whole_extracted_object_equal']
    assert (G/'target.o').read_bytes()==(D/'qualified01/target.o').read_bytes()
    structural={};states={}
    for name,n in [('Before',334),('After',335)]:
        historical=(C/f'09-passive-if-let/snapshots/{n:03d}.txt').read_bytes();saved=historical.decode().replace('\r\n','\n');observed=machine(text,name);expected=machine(saved,name)
        a,ac=view(expected);b,bc=view(observed);diff='\n'.join(difflib.unified_diff(a,b,fromfile='normal root passive capture',tofile='extracted debug capture'))
        (D/(name.lower()+'-stage.diff')).write_text(diff,encoding='utf-8');assert a==b,name
        structural[name]=dict(rows=len(a),view_sha256=sha('\n'.join(a).encode()),source_snapshot_sha256=sha(historical),literal_text_equal=expected==observed,unique_constant_labels=len(ac),constant_name_mapping=dict(zip(ac,bc)))
        states[name]=observed
    blocks,bundles=edge_bundles(states['Before'])
    selections=re.findall(r'^selectOrSplit GPR:%23 .*?(?=^selectOrSplit|\Z)',text,re.M|re.S);assert len(selections)==3
    chosen=selections[2];assert 'RS_Split Cascade 3' in chosen and 'Split for $r9 in 7 bundles, intv 1.' in chosen
    rows=re.findall(r'^\$(r\d+)\tstatic = ([^,\n]+), v=(\d+), total = ([^ ]+) with bundles ([^\n]+)\.',chosen,re.M)
    costs={reg:dict(static=s,visited=int(n),total=cost,bundles=[int(x) for x in re.findall(r'EB#(\d+)',edge)]) for reg,s,n,cost,edge in rows}
    assert len(costs)==10 and min(costs,key=lambda k:Decimal(costs[k]['total']))=='r9'
    assert costs['r3']['bundles']==[16] and costs['r9']['bundles']==[1,2,16,20,21,22,24]
    assert blocks[27]['incoming'] not in costs['r9']['bundles'] and blocks[27]['outgoing'] in costs['r9']['bundles']
    assert '%bb.27 [4896B;4992B) intf invalid-invalid, live-through 0 -> 1, reload on exit.' in chosen
    assert 'enterIntvAtEnd %bb.27, 4976d' in chosen and '4952B:0\t%148:gpr = COPY %147:gpr' in chosen
    spill=re.search(r'^selectOrSplit GPR:%147 .*?(?=^selectOrSplit)',text,re.M|re.S)[0]
    assert 'Inline spilling GPR:%147' in spill and 'From original %23' in spill and '4952r\t%149:gpr = LDD_V1 %stack.19, 0' in spill
    assert 'assigning %149 to $r6:' in text
    eviction=re.search(r'^selectOrSplit GPR:%3 .*?(?=^selectOrSplit)',text,re.M|re.S)[0];assert 'unassigning %23 from $r6' in eviction
    inputs={};inventory=read(L/'source-inventory.json')
    for rel in ['llvm/lib/CodeGen/RegAllocGreedy.cpp','llvm/lib/CodeGen/SplitKit.cpp','llvm/lib/CodeGen/EdgeBundles.cpp','llvm/lib/Support/IntEqClasses.cpp']:
        b=(L/'source'/rel).read_bytes();assert sha(b)==inventory[rel];inputs[rel]=dict(sha256=sha(b),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
    greedy=(L/'source/llvm/lib/CodeGen/RegAllocGreedy.cpp').read_text();split=(L/'source/llvm/lib/CodeGen/SplitKit.cpp').read_text()
    assert 'Cost += calcGlobalSplitCost(Cand, Order);' in greedy and 'if (Cost < BestCost)' in greedy
    assert 'if (!IntvIn)' in split and 'SlotIndex Idx = enterIntvAtEnd(*MBB);' in split and 'SA.getLastSplitPointIter(&MBB)' in split
    report=dict(result='PASS',llvm_revision='08aedd64bf3abe4f163407b7bcf680403b84b32d',compiler_sources=inputs,trace_sha256=sha(raw),structural_stage_comparison=structural,
        view_scope='For analysis only: normalize whitespace, machine block IR labels, frame-object debug names, first-seen constant labels, and remove printed memory annotations. Keep all SlotIndexes, registers, opcodes, immediates, call names, CFG edges/probabilities and frame sizes. This is not literal stage-text equality. Final object bytes and bounded operand bindings are verified separately.',
        cfg_blocks=len(blocks),edge_bundles=bundles,bundle_mapping=blocks,return_pointer_virtual=23,evicted_by_virtual=3,region_costs=costs,selected_region='r9',
        printed_cost_margin_to_r3=str(Decimal(costs['r3']['total'])-Decimal(costs['r9']['total'])),
        early_reload=dict(block=27,slot_index='4952B',incoming_bundle=blocks[27]['incoming'],outgoing_bundle=blocks[27]['outgoing'],spill_frame=19,final_virtual=149,assigned_register='r6'),
        next_hypothesis='The early reload is selected by a global split-region cost comparison, before eventual r6 assignment. An alternative r3 region contains only bundle16 and has a slightly higher printed cost. This is a diagnostic lead for a controlled allocator counterfactual or source CFG/frequency hypothesis, not proof that selecting it recovers original bytes.',
        rejected_qualifications=dict(extra_emit_whole_elf_equal=False,extra_emit_text_and_rodata_equal=True,extracted_literal_relocation_names_equal=False,mir_resume_target_raw_equal=False,mir_resume_different_target_bytes=243),
        limits='No source improvement, full original ELF identity, unique original compiler provenance, target execution, or behavioral qualification. The original function has no retained internal compiler trace; correspondence is observed for our candidate only.')
    save(D/'analysis.json',report);print(json.dumps({k:report[k] for k in ['result','cfg_blocks','edge_bundles','selected_region','printed_cost_margin_to_r3','early_reload','structural_stage_comparison']},indent=2))
if __name__=='__main__':main()

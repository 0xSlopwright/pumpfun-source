"""Observe Greedy allocation in the qualified unedited target extraction."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;Q=D/'qualified01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    assert json.loads((D/'relocation-binding.json').read_bytes())['result']=='PASS'
    out=D/'greedy01';out.mkdir();parent=json.loads((Q/'compile-launch.json').read_bytes());cmd=list(parent['command']);cmd[-1]=str(out/'target.o');cmd+=['-debug-only=regalloc','-print-before=greedy','-print-after=greedy','-filter-print-funcs=_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E']
    assert sha(Path(cmd[0]))==parent['tool_sha256'];launch=dict(command=cmd,cwd=str(D),environment=parent['environment'],tool_sha256=sha(Path(cmd[0])),input_sha256=sha(Q/'target.bc'),controller_sha256=sha(Path(__file__)),scope='Unedited extracted candidate with passive Greedy debug/print flags. Require byte-identical complete extracted object; original full module capture has differing non-loadable symbol strings and remains separately bounded.',compiler_commands=1,target_executions=0)
    save(out/'launch.json',launch);start=time.time()
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        p=subprocess.run(cmd,cwd=D,env=launch['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    result=dict(returncode=p.returncode,seconds=time.time()-start,input_unchanged=sha(Q/'target.bc')==launch['input_sha256'],tool_unchanged=sha(Path(cmd[0]))==launch['tool_sha256'],logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
    if p.returncode==0:result.update(whole_extracted_object_equal=(out/'target.o').read_bytes()==(Q/'target.o').read_bytes(),object_sha256=sha(out/'target.o'))
    save(out/'result.json',result);print(json.dumps(result,indent=2),flush=True)
    assert result['returncode']==0 and all(result[k] for k in ['input_unchanged','tool_unchanged','whole_extracted_object_equal'])
if __name__=='__main__':main()

"""Capture stock machine frequencies, requiring complete object equality."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;Q=D.parent/'pump-v3-regalloc/qualified01';O=D/'stock01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    O.mkdir();parent=json.loads((Q/'compile-launch.json').read_bytes());cmd=parent['command'].copy();cmd[-1]=str(O/'target.o');cmd+=['-print-machine-bfi','-print-bfi-func-name=_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E','-debug-only=regalloc']
    assert sha(Path(cmd[0]))==parent['tool_sha256'];launch=dict(command=cmd,cwd=str(D),environment=parent['environment'],tool_sha256=sha(Path(cmd[0])),input_sha256=sha(Q/'target.bc'),controller_sha256=sha(Path(__file__)),target_executions=0)
    save(O/'launch.json',launch);start=time.time()
    with (O/'stdout.log').open('wb') as stdout,(O/'stderr.log').open('wb') as stderr:r=subprocess.run(cmd,cwd=D,env=parent['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    result=dict(returncode=r.returncode,seconds=time.time()-start,input_unchanged=sha(Q/'target.bc')==launch['input_sha256'],tool_unchanged=sha(Path(cmd[0]))==launch['tool_sha256'],logs={n:sha(O/n) for n in ['stdout.log','stderr.log']},object_sha256=sha(O/'target.o') if (O/'target.o').exists() else None,whole_object_equal=(O/'target.o').read_bytes()==(Q/'target.o').read_bytes() if (O/'target.o').exists() else False,target_executions=0)
    save(O/'result.json',result);print(json.dumps(result,indent=2),flush=True);assert r.returncode==0 and result['whole_object_equal'] and result['input_unchanged'] and result['tool_unchanged']
if __name__=='__main__':main()

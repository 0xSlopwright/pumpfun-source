"""Recompute exact split costs and isolate the r3/r9 frequency difference."""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import hashlib,json,re
D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def model(text,stock,expected_winner):
    # New debug insertions may split an existing debug line, but do not change it.
    stripped=re.sub(r'COST_PROBE [^\n]*\n','',text);assert stripped==stock
    heading='********** GREEDY REGISTER ALLOCATION **********';assert text.count(heading)==1
    pre=text[:text.index(heading)];start=pre.rindex('block-frequency-info:');block=pre[start:]
    freqs={int(n):dict(label=name,frequency=int(f)) for n,name,f in re.findall(r'^ - BB(\d+)\[(.*?)\]: float = [^,]+, int = (\d+)$',block,re.M)};assert list(freqs)==list(range(38))
    regions=re.split(r'(?=COST_PROBE begin )',text)[1:];assert len(regions)==11;regions=regions[-10:];models={}
    for region in regions:
        m=re.match(r'COST_PROBE begin reg=\$(r\d+) best=(\d+) entry=(\d+)',region);reg,best,entry=m.groups();entry=int(entry)
        subtotal=int(re.search(r'COST_PROBE subtotal reg=\$'+reg+r' static=(\d+)',region)[1]);total=int(re.search(r'COST_PROBE total reg=\$'+reg+r' value=(\d+)',region)[1])
        static=[];global_rows=[]
        for kind,n,ins,f in re.findall(r'COST_PROBE (static|use|active)(?: reg=\$r\d+)? block=(\d+) ins=(\d+) freq=(\d+)',region):
            n,ins,f=map(int,[n,ins,f]);assert freqs[n]['frequency']==f
            row=dict(block=n,instructions=ins,frequency=f,cost=ins*f)
            (static if kind=='static' else global_rows).append(row)
        assert sum(r['cost'] for r in static)==subtotal
        assert subtotal+sum(r['cost'] for r in global_rows)==total
        coeffs=Counter()
        for r in static+global_rows:coeffs[r['block']]+=r['instructions']
        models[reg]=dict(best_before=int(best),entry=entry,static=subtotal,total=total,normalized=str(Fraction(total,entry)),static_rows=static,global_rows=global_rows,coefficients={k:v for k,v in coeffs.items() if v})
    a=models['r3'];b=models['r9'];delta={n:a['coefficients'].get(n,0)-b['coefficients'].get(n,0) for n in freqs};delta={n:c for n,c in delta.items() if c}
    weighted=sum(c*freqs[n]['frequency'] for n,c in delta.items());assert weighted==a['total']-b['total']
    f=lambda n:freqs[n]['frequency']
    best=2**64-1;winner=None
    for reg,m in models.items():
        assert m['best_before']==best
        if m['total']<best:best=m['total'];winner=reg
    assert winner==expected_winner
    report=dict(result='PASS',debug_removed_trace_equal=True,frequencies=freqs,regions=models,winner=winner,r3_minus_r9=weighted,entry_frequency=entry,exact_normalized_margin=str(Fraction(weighted,entry)),delta_terms=[dict(block=n,label=freqs[n]['label'],coefficient=c,frequency=freqs[n]['frequency'],cost=c*freqs[n]['frequency']) for n,c in delta.items()],limits='Exact integer cost replay for this candidate, not original compiler provenance or a natural source improvement. No target execution.')
    report['collapsed_delta']=dict(first_panic_block=3,first_panic_frequency=f(3),net_error_format_panic_block=31,net_error_format_panic_frequency=f(31),panic_frequency_difference=f(3)-f(31),integer_flow_residual=weighted-(f(3)-f(31)))
    return report
def main():
    text=(D/'probe01/stderr.log').read_text();stock=(D/'stock01/stderr.log').read_text()
    for folder in ['stock01','probe01']:
        result=read(D/folder/'result.json');assert result['returncode']==0 and result['whole_object_equal'] and sha(D/folder/'stderr.log')==result['logs']['stderr.log']
    assert (D/'stock01/target.o').read_bytes()==(D/'probe01/target.o').read_bytes()
    report=model(text,stock,'r9');assert report['r3_minus_r9']==4831840080 and report['collapsed_delta']['integer_flow_residual']==0
    save(D/'costs.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['frequencies','regions']},indent=2))
if __name__=='__main__':main()

"""Reuse the qualified private build routing, replacing only patch generation."""
from pathlib import Path
D=Path(__file__).resolve().parent;old=D.parent/'pump-v3-regalloc/build_counterfactual.py'
s=old.read_text();s=s.replace('isolated, opt-in allocator counterfactual','isolated, logging-only allocator cost probe').replace("O=D/'derivative02'","O=D/'derivative01'")
a=s.index('    stock=(L/');b=s.index('    compile=m.argv',a)
s=s[:a]+'''    stock=(L/'source'/REL).read_text()
    patch_spec=importlib.util.spec_from_file_location('cost_patch',D/'cost_patch.py');patch_module=importlib.util.module_from_spec(patch_spec);patch_spec.loader.exec_module(patch_module)
    modified=patch_module.patch(stock);source=O/'RegAllocGreedy.cpp';source.write_bytes(modified.encode())
    (O/'counterfactual.patch').write_text(''.join(difflib.unified_diff(stock.splitlines(True),modified.splitlines(True),fromfile=REL,tofile=REL)),encoding='utf-8')
'''+s[b:]
s=s.replace("scope='Opt-in diagnostic intervention in one evaluated split-region choice for V3 costs virtual return pointer23. Default-off output must equal stock; enabled result is not recovered Rust or an original compiler recipe. All stock sources, objects and tools must remain unchanged.'","cost_patch_sha256=sha(D/'cost_patch.py'), scope='Logging-only diagnostic of integer split costs for V3 return pointer23. Complete target object must equal the qualified stock output. All stock sources, objects and tools must remain unchanged; no target execution.'")
out=D/'build_cost_probe.py';assert not out.exists();out.write_bytes(s.encode())
print(out)

"""One synthetic profile input; use unmodified stock LLVM and retain baseline."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;Q=D.parent/'pump-v3-regalloc/qualified01';O=D/'ir01'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
OLD=b'  br i1 %_15.i16, label %bb5.i26, label %bb6.i17'
NEW=OLD+b', !prof !14'
META=b'!14 = !{!"branch_weights", i32 1, i32 16777215}\n'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    O.mkdir();raw=(Q/'target.ll').read_bytes();assert raw.count(OLD)==1 and b'!14' not in raw
    modified=raw.replace(OLD,NEW)+META;parent=json.loads((Q/'compile-launch.json').read_bytes())
    for mode,source in [('baseline',raw),('frequency',modified)]:
        out=O/mode;out.mkdir();inp=out/'input.ll';inp.write_bytes(source)
        cmd=parent['command'].copy();cmd[8]=str(inp);cmd[10]=str(out/'target.o');cmd+=['-debug-only=regalloc','-print-machine-bfi','-print-bfi-func-name='+SYMBOL,'-print-before=greedy','-filter-print-funcs='+SYMBOL]
        assert sha(Path(cmd[0]))==parent['tool_sha256']
        launch=dict(command=cmd,cwd=str(D),environment=parent['environment'],tool_sha256=sha(Path(cmd[0])),input_sha256=sha(inp),controller_sha256=sha(Path(__file__)),scope='Synthetic branch metadata diagnostic only: first panic profile probability1/16777216 instead of inferred1/1048576. No semantic instruction edit, forced allocator, recovered Rust or original compiler provenance claim.',target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:r=subprocess.run(cmd,cwd=D,env=parent['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        result=dict(returncode=r.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==launch['input_sha256'],tool_unchanged=sha(Path(cmd[0]))==launch['tool_sha256'],logs={n:sha(out/n) for n in ['stdout.log','stderr.log']},object_sha256=sha(out/'target.o') if (out/'target.o').exists() else None,whole_stock_object_equal=(out/'target.o').read_bytes()==(Q/'target.o').read_bytes() if (out/'target.o').exists() else False,target_executions=0)
        save(out/'result.json',result);print(json.dumps(dict(mode=mode,**result),indent=2),flush=True)
        assert r.returncode==0 and result['input_unchanged'] and result['tool_unchanged']
        if mode=='baseline':assert result['whole_stock_object_equal']
if __name__=='__main__':main()

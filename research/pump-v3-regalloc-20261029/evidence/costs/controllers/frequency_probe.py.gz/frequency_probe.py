"""Bind the synthetic-weight run to exact observed allocator costs."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;O=D/'frequency-probe01';I=D/'ir01/frequency'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    O.mkdir();parent=json.loads((I/'launch.json').read_bytes());build=json.loads((D/'derivative01/build-result.json').read_bytes());assert build['stock_build_unchanged'] and build['stock_source_unchanged']
    cmd=parent['command'].copy();cmd[0]=str(D/'derivative01/llc.exe');cmd[10]=str(O/'target.o');assert sha(Path(cmd[0]))==build['outputs']['llc.exe']
    launch=dict(command=cmd,cwd=str(D),environment=parent['environment'],tool_sha256=sha(Path(cmd[0])),input_sha256=sha(I/'input.ll'),controller_sha256=sha(Path(__file__)),target_executions=0)
    save(O/'launch.json',launch);start=time.time()
    with (O/'stdout.log').open('wb') as stdout,(O/'stderr.log').open('wb') as stderr:r=subprocess.run(cmd,cwd=D,env=parent['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    result=dict(returncode=r.returncode,seconds=time.time()-start,input_unchanged=sha(I/'input.ll')==launch['input_sha256'],tool_unchanged=sha(Path(cmd[0]))==launch['tool_sha256'],logs={n:sha(O/n) for n in ['stdout.log','stderr.log']},object_sha256=sha(O/'target.o') if (O/'target.o').exists() else None,whole_stock_frequency_object_equal=(O/'target.o').read_bytes()==(I/'target.o').read_bytes() if (O/'target.o').exists() else False,target_executions=0)
    save(O/'result.json',result);print(json.dumps(result,indent=2),flush=True);assert r.returncode==0 and result['whole_stock_frequency_object_equal'] and result['input_unchanged'] and result['tool_unchanged']
if __name__=='__main__':main()

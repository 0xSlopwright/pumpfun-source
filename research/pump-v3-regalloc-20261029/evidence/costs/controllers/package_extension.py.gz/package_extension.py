from pathlib import Path
import gzip,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;P=W/'pumpfun-source/research/pump-v3-regalloc-20261029';L=W/'l18'
def main():
    mapping=json.loads((P/'EVIDENCE.json').read_bytes())
    def add(key,path):
        key='costs/'+key;b=path.read_bytes();dest=P/'evidence'/(key+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(b,mtime=0));mapping[key]=dict(file=dest.relative_to(P).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    for folder in ['stock01','probe01','ir01/baseline','ir01/frequency','frequency-probe01']:
        for p in (D/folder).iterdir():
            if p.is_file():add(folder+'/'+p.name,p)
    for n in ['build-launch.json','build-result.json','stock-commands.json','response-provenance.json','LLVMCodeGen.rsp','counterfactual.patch','RegAllocGreedy.cpp','stock-build-before.json','compile.stdout','compile.stderr','archive.stdout','archive.stderr','link.stdout','link.stderr']:add('derivative/'+n,D/'derivative01'/n)
    for n in ['capture_bfi.py','cost_patch.py','prepare_builder.py','build_cost_probe.py','run_probe.py','ir_frequency_control.py','frequency_probe.py','analyze_costs.py','analyze_frequency.py','package_extension.py']:add('controllers/'+n,D/n)
    for n in ['costs.json','frequency-analysis.json','before-greedy.diff','analyze_frequency_failed01.py','frequency-analysis-failed01.err','before-greedy-failed01.diff']:add(n,D/n)
    for n in ['llvm/lib/Analysis/BranchProbabilityInfo.cpp','llvm/lib/CodeGen/SpillPlacement.cpp','llvm/include/llvm/Analysis/BlockFrequencyInfoImpl.h']:add('compiler/'+n,L/'source'/n)
    (P/'EVIDENCE.json').write_bytes((json.dumps(mapping,indent=2)+'\n').encode())
    provenance=json.loads((P/'PROVENANCE.json').read_bytes());provenance['frequency_followup']=dict(base_revision='465715f453c1f52d9d4047fba942858cb78d78bc',reviewed_upstream='5afa7b928c50aacd5ef08415766ae6999c61650d',root_rustc_commands=0,llc_commands=5,host_build_commands=3,target_executions=0,synthetic_profile=True,source_improvement=False)
    (P/'PROVENANCE.json').write_bytes((json.dumps(provenance,indent=2)+'\n').encode());print(json.dumps(dict(evidence_files=len(mapping),added=sum(k.startswith('costs/') for k in mapping)),indent=2))
if __name__=='__main__':main()

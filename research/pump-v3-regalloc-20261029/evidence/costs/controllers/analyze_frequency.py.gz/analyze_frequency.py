"""Verify the single synthetic metadata change and its stock compiler result."""
from pathlib import Path
import difflib,hashlib,importlib.util,json,re
D=Path(__file__).resolve().parent;W=D.parent;Q=W/'pump-v3-regalloc/qualified01'
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
    costs=load('v3_costs',D/'analyze_costs.py');controller=load('v3_frequency_control',D/'ir_frequency_control.py');a=load('v3_machine',W/'pump-v3-regalloc/analyze.py')
    before=(D/'ir01/baseline/input.ll').read_bytes();after=(D/'ir01/frequency/input.ll').read_bytes();assert before==(Q/'target.ll').read_bytes()
    assert after==before.replace(controller.OLD,controller.NEW)+controller.META
    assert (D/'ir01/baseline/target.o').read_bytes()==(Q/'target.o').read_bytes()
    forced=(W/'pump-v3-regalloc/counterfactual01/on/target.o').read_bytes();assert (D/'ir01/frequency/target.o').read_bytes()==(D/'frequency-probe01/target.o').read_bytes()==forced
    baseline=(D/'ir01/baseline/stderr.log').read_text();frequency=(D/'ir01/frequency/stderr.log').read_text();probe=(D/'frequency-probe01/stderr.log').read_text()
    x=a.machine(baseline,'Before');y=a.machine(frequency,'Before')
    changes=list(difflib.unified_diff(x.splitlines(),y.splitlines(),fromfile='baseline',tofile='one synthetic profile'))
    (D/'before-greedy.diff').write_text('\n'.join(changes)+'\n',encoding='utf-8')
    assert x.count('!range !3')==y.count('!range !4')==3
    assert b'!3 = !{i64 0, i64 3}' in before and b'!3 = !{i64 0, i64 3}' in after
    def view(s,range_id):
        s=s.replace('!range !'+str(range_id),'!range RANGE_ID')
        return [re.sub(r'\(0x[0-9a-f]+\)','(PROBABILITY)',line) if 'successors:' in line else line for line in s.splitlines()]
    assert view(x,3)==view(y,4)
    model=costs.model(probe,frequency,'r3');stock=costs.model((D/'probe01/stderr.log').read_text(),(D/'stock01/stderr.log').read_text(),'r9')
    assert {r:m['coefficients'] for r,m in model['regions'].items()}=={r:m['coefficients'] for r,m in stock['regions'].items()}
    assert model['r3_minus_r9']==-1207958222 and model['collapsed_delta']['integer_flow_residual']==-2
    result=dict(result='PASS',input_delta='Only first protocol-fee-split panic branch gains !prof weights [1,16777215], plus one metadata definition.',baseline_whole_object_equal=True,frequency_whole_object_equals_forced_allocator=True,frequency_object_sha256=hashlib.sha256(forced).hexdigest(),before_greedy_only_successor_probability_and_three_range_id_changes=True,before_greedy_diff=changes,cost_coefficients_identical=True,model=model,
        limits='Synthetic profile metadata changes emitted instructions through stock optimization. It is not a recovered Rust spelling or original profile/compiler provenance, and does not recover raw original bytes.')
    costs.save(D/'frequency-analysis.json',result);print(json.dumps({k:v for k,v in result.items() if k!='model'},indent=2));print(json.dumps(model['collapsed_delta']))
if __name__=='__main__':main()

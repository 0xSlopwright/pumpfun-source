"""Logging-only patch of the already qualified allocator translation unit."""
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
SCOPE='MF->getName() == "'+SYMBOL+'" && SA->getParent().reg() == Register::index2VirtReg(23)'
def once(s,old,new):assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
def log(fields):return '    LLVM_DEBUG(if ('+SCOPE+') dbgs() << "COST_PROBE '+fields+' << "\\n");\n'
def patch(stock):
    text=stock
    anchor='    // Accumulate the total frequency of inserted spill code.\n'
    text=once(text,anchor,log('static block=" << BC.Number << " ins=" << Ins << " freq=" << SpillPlacer->getBlockFrequency(BC.Number).getFrequency()')+anchor)
    anchor='    while (Ins--)\n      GlobalCost += SpillPlacer->getBlockFrequency(BC.Number);'
    text=once(text,anchor,log('use reg=" << printReg(Cand.PhysReg, TRI) << " block=" << BC.Number << " ins=" << Ins << " freq=" << SpillPlacer->getBlockFrequency(BC.Number).getFrequency() << " livein=" << BI.LiveIn << " liveout=" << BI.LiveOut << " regin=" << RegIn << " regout=" << RegOut << " entry=" << unsigned(BC.Entry) << " exit=" << unsigned(BC.Exit)')+anchor)
    anchor='      if (Cand.Intf.hasInterference()) {\n        GlobalCost += SpillPlacer->getBlockFrequency(Number);'
    text=once(text,anchor,'      if (Cand.Intf.hasInterference()) {\n'+log('active reg=" << printReg(Cand.PhysReg, TRI) << " block=" << Number << " ins=2 freq=" << SpillPlacer->getBlockFrequency(Number).getFrequency()')+'        GlobalCost += SpillPlacer->getBlockFrequency(Number);')
    anchor='    // live-in / stack-out or stack-in live-out.\n    GlobalCost += SpillPlacer->getBlockFrequency(Number);'
    text=once(text,anchor,log('active reg=" << printReg(Cand.PhysReg, TRI) << " block=" << Number << " ins=1 freq=" << SpillPlacer->getBlockFrequency(Number).getFrequency()')+anchor)
    a=text.index('RAGreedy::calculateRegionSplitCostAroundReg(');b=text.index('\nunsigned RAGreedy::calculateRegionSplitCost(',a);piece=text[a:b]
    anchor='  BlockFrequency Cost;\n';piece=once(piece,anchor,anchor+log('begin reg=" << printReg(PhysReg, TRI) << " best=" << BestCost.getFrequency() << " entry=" << MBFI->getEntryFreq().getFrequency()'))
    anchor='  Cost += calcGlobalSplitCost(Cand, Order);';piece=once(piece,anchor,log('subtotal reg=" << printReg(PhysReg, TRI) << " static=" << Cost.getFrequency()')+anchor+'\n'+log('total reg=" << printReg(PhysReg, TRI) << " value=" << Cost.getFrequency()'))
    return text[:a]+piece+text[b:]

"""One source control for the remaining checked-arithmetic/return-pointer join."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess,time
D=Path(__file__).resolve().parent
OLD=b'    let net=first.checked_add(second).and_then(|sum|sum.checked_sub(total_buyback))'
NEW=b'    let net=(match first.checked_add(second){Some(sum)=>sum.checked_sub(total_buyback),None=>None})'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def inv(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def main():
 base=D/'07-remapped-if-let';out=D/'10-explicit-net-match';out.mkdir();shutil.copytree(base/'source',out/'source');shutil.copytree(base/'target',out/'target');(out/'temp').mkdir()
 prior=read(base/'launch.json');assert inv(out/'source')==prior['source_inputs']
 p=out/'source/programs/pump/src/trade_v3.rs';raw=p.read_bytes();assert raw.splitlines()[373]==OLD and raw.count(OLD)==1
 p.write_bytes(raw.replace(OLD,NEW));inputs=inv(out/'source');assert [p for p in inputs if inputs[p]!=prior['source_inputs'][p]]==['programs/pump/src/trade_v3.rs']
 command=[x.replace(str(base),str(out)) for x in prior['command']];env={k:v.replace(str(base),str(out)) for k,v in prior['environment'].items()}
 tools=prior['tools'];dependencies=prior['dependency_files'];assert all(sha(Path(p))==h for p,h in tools.items());assert all(sha(out/'target'/p)==h for p,h in dependencies.items())
 save(out/'launch.json',dict(command=command,cwd=str(out/'source'),environment=env,source_inputs=inputs,tools=tools,dependency_files=dependencies,controller_sha256=sha(Path(__file__)),parent=base.name,
  compiler_commands=1,target_executions=0,source_change=dict(path='programs/pump/src/trade_v3.rs',line=374,old=OLD.decode(),new=NEW.decode()),
  hypothesis='The qualified candidate trace still introduces the return-pointer reload at the checked net guard during Greedy allocation, retaining it through pre_fee_amount and later error calls. Test an explicit Option match at the checked-add/sub join instead of the and_then closure, preserving both checked operations, the unchanged line375 error callback, and the source line373 branch improvement. No output bytes or compiler flags are changed.'))
 start=time.time()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:r=subprocess.run(command,cwd=out/'source',env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
 result=dict(returncode=r.returncode,seconds=time.time()-start,source_unchanged=inv(out/'source')==inputs,tools_unchanged=all(sha(Path(p))==h for p,h in tools.items()),dependencies_unchanged=all(sha(out/'target'/p)==h for p,h in dependencies.items()),logs={p:sha(out/p) for p in ['stdout.log','stderr.log']},target_executions=0)
 if r.returncode==0:
  shutil.copyfile(out/'target/sbpf-solana-solana/release/deps/pump_recovered.so',out/'symbols.so');result.update(symbols_sha256=sha(out/'symbols.so'),whole_output_equal=(out/'symbols.so').read_bytes()==(base/'symbols.so').read_bytes())
 save(out/'result.json',result);print(json.dumps(result,indent=2),flush=True)
 assert result['returncode']==0 and all(result[k] for k in ['source_unchanged','tools_unchanged','dependencies_unchanged'])
 s=importlib.util.spec_from_file_location('v3_measure',D/'control.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.measure(out)
if __name__=='__main__':main()

"""Two isolated compiler controls; neither runs a produced SBF image."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import difflib,gzip,hashlib,importlib.util,json,shutil,subprocess,sys,time
D=Path(__file__).resolve().parent;W=D.parent;R=W/'pumpfun-source';BASE=W/'pump-exact-sol-controls/02-guard'
OLD=b'    let second=match post{Some(p)=>add3(p.quote_in,p.fees.protocol_fee,p.fees.creator_fee)?,None=>0};'
NEW=b'    let second=post.map(|p|add3(p.quote_in,p.fees.protocol_fee,p.fees.creator_fee)).transpose()?.unwrap_or(0);'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def inv(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def measure(out):
 tools=R/'research/pump-exact-sol-guard-20261029/tools';sys.path.insert(0,str(tools))
 import census as c
 c.ROOT=R;blob=(out/'symbols.so').read_bytes();sections=c.sections(blob)
 fs=[f for f in c.functions(blob) if '5trade12v3_buy_costs17h' in f[2]];assert len(fs)==1
 addr,size,name=fs[0];body=c.body(blob,sections,addr,size);norm,refs=c.normalize(body,addr,sections)
 original=(R/'evidence/original/pump/deployed.so').read_bytes();os=c.sections(original);raw=c.body(original,os,0x80df8,2120);on,oref=c.normalize(raw,0x80df8,os)
 chunks=lambda b:[b[i:i+8] for i in range(0,len(b),8)]
 sm=difflib.SequenceMatcher(None,chunks(on),chunks(norm),autojunk=False)
 edits=[dict(kind=t,original=[i,j],candidate=[k,l]) for t,i,j,k,l in sm.get_opcodes() if t!='equal']
 counts=c.census(out/'symbols.so');(out/'census.json.gz').write_bytes(gzip.compress(json.dumps(counts).encode(),mtime=0))
 result=dict(image_sha256=sha(out/'symbols.so'),target_address=addr,target_bytes=size,target_symbol=name,
  target_raw_sha256=hashlib.sha256(body).hexdigest(),target_normalized_sha256=hashlib.sha256(norm).hexdigest(),
  aligned_differing_slots=sum(max(e['original'][1]-e['original'][0],e['candidate'][1]-e['candidate'][0]) for e in edits),
  alignment=edits,counts=counts['counts'],direct_calls=sum(r['kind']=='direct-call' for r in refs))
 (out/'target.raw').write_bytes(body);(out/'target.normalized').write_bytes(norm);save(out/'measurement.json',result)
 print(json.dumps({k:v for k,v in result.items() if k!='alignment'},indent=2),flush=True)
 return result
def main(label):
 assert label in ['06-remapped-baseline','02-option-transpose']
 prep=read(D/'preparation.json');manifest=read(D/'inputs/MANIFEST.json')
 for path in ['source-candidate.tar.gz','source-candidate.json','build/candidate/costs-measurement.json']:
  assert sha(D/'inputs'/path.replace('/','--'))==manifest[path]
 source=Path(prep['source']);assert inv(source)==prep['source_inputs']==read(D/'inputs/source-candidate.json')
 if label!='06-remapped-baseline':
  baseline=read(D/'06-remapped-baseline/measurement.json')
  assert baseline['target_bytes']==2144 and baseline['aligned_differing_slots']==25
  assert baseline['target_normalized_sha256']=='33cbf02cfaa3594484fa1077ea1296cc9df35eed2930083fb083792770d33e08'
 out=D/label;out.mkdir();shutil.copytree(source,out/'source');shutil.copytree(BASE/'target',out/'target');(out/'temp').mkdir()
 if label=='02-option-transpose':
  p=out/'source/programs/pump/src/trade_v3.rs';data=p.read_bytes();assert data.splitlines()[372]==OLD and data.count(OLD)==1
  p.write_bytes(data.replace(OLD,NEW))
 old=read(BASE/'launch.json');command=[x.replace(str(BASE),str(out)) for x in read(BASE/'root-command.json')]
 assert command[4].replace(chr(92),chr(47))==chr(47).join(['programs','pump','src','lib.rs'])
 command[4]=command[4].replace(chr(92),chr(47))
 command.append('--remap-path-prefix=programs/pump/src'+chr(92)+'trade_v3.rs=programs/pump/src/trade_v3.rs')
 env={k:v.replace(str(BASE),str(out)) for k,v in old['environment'].items()};env.update(CARGO_MANIFEST_DIR=str(out/'source/programs/pump'),CARGO_PKG_NAME='pump-recovered',CARGO_PKG_VERSION='0.1.0',CARGO_CRATE_NAME='pump_recovered')
 inputs=inv(out/'source');tools=old['tools'];assert all(sha(Path(p))==h for p,h in tools.items())
 depfiles={p.relative_to(out/'target').as_posix():sha(p) for p in (out/'target').rglob('*') if p.is_file() and p.suffix in ['.rlib','.dll','.so'] and 'pump_recovered' not in p.name}
 save(out/'launch.json',dict(command=command,cwd=str(out/'source'),environment=env,source_inputs=inputs,tools=tools,dependency_files=depfiles,
  controller_sha256=sha(Path(__file__)),compiler_commands=1,target_executions=0,recipe_origin='Qualified Windows v1.44 root invocation; unchanged dependency source inputs and private dependency artifacts reused. Separate from the two native builds archived by PR909.',
  hypothesis='In the final qualified native trace the second add3 success block is not the next IR block at SelectionDAG lowering, so it gets JEQ-to-success plus JMP-to-error. The pinned SBF target cannot analyze conditional branches for late inversion. The forward-slash root argument corrected lib.rs but left a mixed separator in the module filename. This baseline-only input-path control adds one exact-file remap for trade_v3.rs; it is a declared compiler-input change, not binary normalization; it preserves arithmetic and physical Source lines. It is not a source recovery or behavioral claim.',
  changed_lines=[] if label=='06-remapped-baseline' else [373],source_change=None if label=='06-remapped-baseline' else dict(path='programs/pump/src/trade_v3.rs',old=OLD.decode(),new=NEW.decode())))
 start=time.time()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  r=subprocess.run(command,cwd=out/'source',env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
 result=dict(returncode=r.returncode,seconds=time.time()-start,source_unchanged=inv(out/'source')==inputs,
  tools_unchanged=all(sha(Path(p))==h for p,h in tools.items()),dependencies_unchanged=all(sha(out/'target'/p)==h for p,h in depfiles.items()),
  logs={p:sha(out/p) for p in ['stdout.log','stderr.log']},target_executions=0)
 if r.returncode==0:
  shutil.copyfile(out/'target/sbpf-solana-solana/release/deps/pump_recovered.so',out/'symbols.so');result['symbols_sha256']=sha(out/'symbols.so')
 save(out/'result.json',result);print(json.dumps(result,indent=2),flush=True)
 assert r.returncode==0 and result['source_unchanged'] and result['tools_unchanged'] and result['dependencies_unchanged']
 measure(out)
if __name__=='__main__':main(sys.argv[1])

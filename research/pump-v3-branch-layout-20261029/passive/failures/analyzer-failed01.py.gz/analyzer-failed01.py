"""Qualify the passive capture and derive the observed V3 lowering boundaries."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,importlib.util,json,re,struct
D=Path(__file__).resolve().parent;W=D.parent;R=W/'pumpfun-source';S=D/'09-passive-if-let';B=D/'07-remapped-if-let'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def inv(p):return {f.relative_to(p).as_posix():sha(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file()}
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def block(text,ir):
 parts=re.split(r'(?=^(?:\d+B\s*)?bb\.\d+ \(%ir-block\.)',text,flags=re.M)
 return [b for b in parts if re.match(r'(?:\d+B\s*)?bb\.\d+ \(%ir-block\.'+str(ir)+r'\):',b)]
def main():
 launch=read(S/'launch.json');result=read(S/'result.json');parent=read(B/'launch.json')
 assert launch['controller_sha256']==sha((D/'trace_candidate.py').read_bytes())
 assert launch['command']==[x.replace(str(B),str(S)) for x in parent['command']]+launch['extra_arguments']
 assert launch['environment']=={k:v.replace(str(B),str(S)) for k,v in parent['environment'].items()}
 assert launch['compiler_commands']==1 and launch['target_executions']==result['target_executions']==0
 assert result['returncode']==0 and all(result[k] for k in ['source_unchanged','tools_unchanged','dependencies_unchanged','whole_output_equal'])
 assert inv(S/'source')==launch['source_inputs']==parent['source_inputs'] and len(launch['source_inputs'])==66
 assert launch['tools']==parent['tools'] and all(sha(Path(p).read_bytes())==h for p,h in launch['tools'].items())
 assert launch['dependency_files']==parent['dependency_files'] and all(sha((S/'target'/p).read_bytes())==h for p,h in launch['dependency_files'].items())
 assert (S/'symbols.so').read_bytes()==(B/'symbols.so').read_bytes() and sha((S/'symbols.so').read_bytes())==result['symbols_sha256']=='6c84199027e127ab72809f4b9b359609f0e30e1992af754a5b47ac96ce8ed229'
 for path,info in result['logs'].items():
  b=(S/path).read_bytes();assert len(b)==info['bytes'] and sha(b)==info['sha256']
 assert inv(Path(result['mir_directory']))==result['mir_files'] and len(result['mir_files'])==548
 raw=(S/'stderr.log').read_bytes();heads=list(re.finditer(rb'^[^\n]*IR Dump (?:Before|After)[^\n]*\n',raw,re.M));index=read(S/'snapshot-index.json');assert len(heads)==len(index)==392
 texts={};pins={}
 for i,(h,row) in enumerate(zip(heads,index)):
  end=heads[i+1].start() if i+1<len(heads) else len(raw);data=raw[h.start():end]
  assert row['start']==h.start() and row['end']==end and row['sha256']==sha(data) and (S/'snapshots'/f'{i:03d}.txt').read_bytes()==data
  texts[i]=data.decode().replace('\r\n','\n');pins[i]=sha(data)
 assert next(i for i in texts if '# Machine code for function' in texts[i])==276
 ir=texts[275];labels=re.findall(r'^(\d+):',ir,re.M);assert labels[labels.index('95')+1]=='103'
 ir_block=re.search(r'^95:.*?(?=^103:)',ir,re.M|re.S)[0];assert 'br i1 %102, label %103, label %106' in ir_block
 isel=block(texts[276],95);assert len(isel)==1 and 'JNE_ri' in isel[0] and 'JMP' not in isel[0]
 before=texts[334];after=texts[335]
 assert 'Function Live Ins: $r1 in %23' in before and '%23:gpr = COPY $r1' in before and '%stack.19' not in before
 assert '%151:gpr = COPY $r1' in after and 'STD_V1 %151:gpr, %stack.19, 0' in after
 reloads=re.findall(r'^(\d+B)\s+%149:gpr = LDD_V1 %stack\.19, 0$',after,re.M);assert reloads==['4040B','4248B','4664B','4952B']
 net=next(b for b in block(after,111) if '%149:gpr = LDD_V1 %stack.19, 0' in b)
 assert net.index('%149:gpr = LDD_V1 %stack.19, 0')<net.index('JNE_ri')
 assert '$r6 = LDD_V1 %stack.19, 0' in ''.join(block(texts[337],111))
 assert '$r6 = LDD_V1 $r10, -400' in ''.join(block(texts[355],111))
 pre=block(texts[358],150);post=block(texts[359],150)
 assert len(pre)==len(post)==1 and 'STD_V1' in pre[0] and 'STD_V1' not in post[0] and 'JMP %bb.20' in post[0]
 assert 'LDD_V1 $r10, -400' not in post[0]
 joined=block(texts[359],166);assert any('STD_V1 killed $r2, $r6, 16' in b and 'STD_V1 killed $r1, $r6, 8' in b for b in joined)
 api=load('v3_trace_elf',R/'research/pump-exact-sol-guard-20261029/audit_target.py');original=api.Elf(R/'evidence/original/pump/deployed.so');candidate=api.Elf(S/'symbols.so')
 fs=[f for f in candidate.functions if '5trade12v3_buy_costs17h' in f['name']];assert len(fs)==1
 targets=[('original',original,0x80df8,2120),('candidate',candidate,fs[0]['address'],fs[0]['size'])];tails={}
 for name,e,address,size in targets:
  body=e.body(address,size);norm,refs=e.normalize(body,address);calls=[r for r in refs if r['kind']=='direct-call'];assert len(calls)==17
  call=calls[7]['offset'];branch=call+24;op,regs,off,imm=struct.unpack_from('<BBhi',body,branch);assert op==5
  payload=branch+8+8*off;assert body[payload]==0x79 and body[payload+8]==5
  tail=payload+16+8*struct.unpack_from('<h',body,payload+10)[0]
  pointer_loads=[i for i in range(0,len(body),8) if body[i:i+8]==bytes.fromhex('79a670fe00000000')]
  tails[name]=dict(pre_fee_call_offset=call,error_branch_offset=branch,payload_load_offset=payload,common_store_tail_offset=tail,return_pointer_r6_SP400_load_offsets=pointer_loads)
 assert tails['original']['payload_load_offset']==1008 and tails['original']['common_store_tail_offset']==1712
 assert tails['candidate']['payload_load_offset']==1992 and tails['candidate']['common_store_tail_offset']==1728
 report=dict(result='PASS',launch_sha256=sha((S/'launch.json').read_bytes()),result_sha256=sha((S/'result.json').read_bytes()),image_sha256=result['symbols_sha256'],whole_output_equal=True,
  source_inputs=66,mir_files=548,snapshots=392,raw_trace=result['logs']['stderr.log'],
  selected_snapshot_hashes={str(i):pins[i] for i in [275,276,334,335,337,355,358,359,371,391]},
  second_add=dict(ir_block=95,true_successor=103,next_ir_block=103,false_successor=106,first_machine='JNE without JMP'),
  return_pointer=dict(before_virtual_register=23,spill_frame_index=19,physical_stack_offset=-400,reload_slot_index_labels=reloads,
   note='The B-suffixed labels are LLVM SlotIndex printouts, not emitted byte addresses.',early_reload_ir_block=111),
  final_tails=tails,
  finding='The statement-form source makes second-add success the next IR block and JNE-only lowering is already visible in snapshot276. Greedy334-to335 still reloads the spilled return pointer before the net overflow branch, retaining it into pre_fee_amount. Branch folding358-to359 shares return stores but leaves the pre_fee payload load in a separate tail without a reload. Thus the source improvement does not remove the earlier observed lifetime/tail residual.',
  limits='Qualified passive observations of the published candidate. Source/trace correspondence does not prove a unique original spelling or identify all causes of the remaining23aligned slots. The native parent trace is a different cohort. No target/VM execution or compiler mutation.',
  compiler_commands=1,target_executions=0)
 (D/'candidate-trace-analysis.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
 print(json.dumps({k:report[k] for k in ['result','snapshots','mir_files','second_add','return_pointer','final_tails']},indent=2))
if __name__=='__main__':main()

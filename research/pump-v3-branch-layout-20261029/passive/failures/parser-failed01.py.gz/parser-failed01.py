if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,json,re
D=Path(__file__).resolve().parent;S=D/'09-passive-if-let';O=S/'snapshots'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 result=json.loads((S/'result.json').read_bytes());raw=(S/'stderr.log').read_bytes()
 assert sha(raw)==result['logs']['stderr.log']['sha256'] and result['whole_output_equal']
 headers=list(re.finditer(rb'^\*\*\* IR Dump (?:Before|After)[^\n]*\n',raw,re.M));assert headers
 O.mkdir();rows=[]
 for i,h in enumerate(headers):
  stop=headers[i+1].start() if i+1<len(headers) else len(raw);b=raw[h.start():stop]
  # Saved intervals are literal stderr bytes, including any final diagnostics.
  (O/f'{i:03d}.txt').write_bytes(b)
  rows.append(dict(index=i,header=h[0].decode().strip(),start=h.start(),end=stop,sha256=sha(b),bytes=len(b),machine=b'# Machine code for function' in b))
 (S/'snapshot-index.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode())
 print(json.dumps(dict(snapshots=len(rows),first_machine=next(x['index'] for x in rows if x['machine']),stages=[r for r in rows if any(k in r['header'] for k in ['Greedy','Control Flow Optimizer','Block Placement','Module Verifier','Finalize ISel'])]),indent=2))
if __name__=='__main__':main()

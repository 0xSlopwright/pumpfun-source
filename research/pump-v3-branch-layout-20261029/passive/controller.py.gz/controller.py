"""Passive MIR/LLVM capture of the published V3 source candidate; no SBF execution."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,json,shutil,subprocess,time
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def inv(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def main():
 base=D/'07-remapped-if-let';out=D/'09-passive-if-let';mir=D.parent/'mpv309';out.mkdir();mir.mkdir()
 shutil.copytree(base/'source',out/'source');shutil.copytree(base/'target',out/'target');(out/'temp').mkdir()
 old=read(base/'launch.json');inputs=inv(out/'source');assert inputs==old['source_inputs'] and len(inputs)==66
 tools=old['tools'];assert all(sha(Path(p))==h for p,h in tools.items())
 dependencies=old['dependency_files'];assert all(sha(out/'target'/p)==h for p,h in dependencies.items())
 command=[x.replace(str(base),str(out)) for x in old['command']]
 env={k:v.replace(str(base),str(out)) for k,v in old['environment'].items()}
 symbol=read(base/'measurement.json')['target_symbol']
 flags=['-C','llvm-args=-print-before-all','-C','llvm-args=-print-after-all','-C','llvm-args=-filter-print-funcs='+symbol,
  '-Zdump-mir=v3_buy_costs','-Zdump-mir-dir='+str(mir)]
 command+=flags
 save(out/'launch.json',dict(command=command,cwd=str(out/'source'),environment=env,source_inputs=inputs,tools=tools,dependency_files=dependencies,
  parent='07-remapped-if-let',extra_arguments=flags,controller_sha256=sha(Path(__file__)),compiler_commands=1,target_executions=0,
  hypothesis='Observe candidate block layout, return-pointer lifetime and error-tail transformations with only passive diagnostic flags added to the published normal invocation. Qualify the entire emitted ELF against control07; do not infer behavior or unique original source.'))
 start=time.time()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  r=subprocess.run(command,cwd=out/'source',env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
 result=dict(returncode=r.returncode,seconds=time.time()-start,source_unchanged=inputs==inv(out/'source'),tools_unchanged=all(sha(Path(p))==h for p,h in tools.items()),
  dependencies_unchanged=all(sha(out/'target'/p)==h for p,h in dependencies.items()),target_executions=0,
  logs={p:dict(sha256=sha(out/p),bytes=(out/p).stat().st_size) for p in ['stdout.log','stderr.log']},mir_files=inv(mir),mir_directory=str(mir))
 if r.returncode==0:
  shutil.copyfile(out/'target/sbpf-solana-solana/release/deps/pump_recovered.so',out/'symbols.so')
  result.update(symbols_sha256=sha(out/'symbols.so'),whole_output_equal=(out/'symbols.so').read_bytes()==(base/'symbols.so').read_bytes())
 save(out/'result.json',result)
 print(json.dumps({k:(len(v) if k=='mir_files' else v) for k,v in result.items()},indent=2),flush=True)
 assert result['returncode']==0 and all(result[k] for k in ['source_unchanged','tools_unchanged','dependencies_unchanged','whole_output_equal'])
 assert result['mir_files']
if __name__=='__main__':main()

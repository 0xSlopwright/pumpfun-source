; ModuleID = 'C:\Users\Wind\Documents\Codex\2026-10-26\https-x-com-shawmakesmagic-status-2114560456891445597\work\l18\extracted01\target.bc'
source_filename = "pump_recovered.f975be7d669a43ae-cgu.0"
target datalayout = "e-m:e-p:64:64-i64:64-n32:64-S128"
target triple = "sbf"

@alloc_31365cfefba383c4d2bf6b6a04cc10aa = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"capacity overflow" }>, align 1
@alloc_e760b8a82485eab475ddc4c0d696a7ac = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, [8 x i8] c"\11\00\00\00\00\00\00\00" }>, align 8
@alloc_7cb3f93b3ba6531fd2aa2397755a323b = hidden unnamed_addr constant <{ [103 x i8] }> <{ [103 x i8] c"/home/runner/work/platform-tools/platform-tools/out/rust/library/alloc/src/vec/spec_from_iter_nested.rs" }>, align 1
@alloc_9c83b52252c910a197dd2a3d1d5a127e = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7cb3f93b3ba6531fd2aa2397755a323b, [16 x i8] c"g\00\00\00\00\00\00\00;\00\00\00\12\00\00\00" }>, align 8
@alloc_6ca8591423d98ecbd315de1d1a6fea68 = hidden unnamed_addr constant <{ [32 x i8] }> zeroinitializer, align 1
@alloc_eb0f2155ac27cbbf3e56027a6a349e9f = hidden unnamed_addr constant <{ [7 x i8] }> <{ [7 x i8] c"account" }>, align 1
@vtable.0 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\18\02\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN114_$LT$pump_recovered..token_incentives..volume_accumulator..GlobalVolumeAccumulator$u20$as$u20$core..fmt..Debug$GT$3fmt17h88a090966823c1abE" }>, align 8
@alloc_de851d3808df3e9c4c7c0aadc50a5875 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"info" }>, align 1
@vtable.1 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17hfa916cc1caf72622E" }>, align 8
@alloc_f5ffd2fd1476bab43ad89fb40c72d0c5 = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"src/lib.rs" }>, align 1
@alloc_0ac3a3859ca57b7ef50acb929ce28f62 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f5ffd2fd1476bab43ad89fb40c72d0c5, [16 x i8] c"\0A\00\00\00\00\00\00\00\A8\00\00\001\00\00\00" }>, align 8
@alloc_de8c009ff76e8b3e6bfdadd4461775e9 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr205drop_in_place$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$GT$17h27ac60e58d0430abE", [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN223_$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$u20$as$u20$core..fmt..Display$GT$3fmt17h90a7b52b4b824722E" }>, align 8
@vtable.2 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr }> <{ ptr @"_ZN4core3ptr205drop_in_place$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$GT$17h27ac60e58d0430abE", [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN221_$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$u20$as$u20$core..fmt..Debug$GT$3fmt17hec448305f4a90e51E", ptr @"_ZN223_$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$u20$as$u20$core..fmt..Display$GT$3fmt17h90a7b52b4b824722E", ptr @alloc_de8c009ff76e8b3e6bfdadd4461775e9, ptr @_ZN4core5error5Error5cause17h958760fef6acec7aE, ptr @_ZN4core5error5Error7type_id17h2110e4cd5cfd7c4fE, ptr @"_ZN223_$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$u20$as$u20$core..error..Error$GT$11description17hf25e5ff77ea0398dE", ptr @_ZN4core5error5Error5cause17h958760fef6acec7aE, ptr @_ZN4core5error5Error7provide17hb16b28c2591f110bE }>, align 8
@alloc_6bd46028dd5544964a6ecdc7f0a2138c = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"src\\de\\mod.rs" }>, align 1
@alloc_b7e15506b320f9957c2cb8c8ebc14cf2 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6bd46028dd5544964a6ecdc7f0a2138c, [16 x i8] c"\0D\00\00\00\00\00\00\00e\02\00\002\00\00\00" }>, align 8
@alloc_71400f724d40df1ad286a16089108cb1 = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"failed to fill whole buffer" }>, align 1
@alloc_98afe290087844da31649655198ddd96 = hidden unnamed_addr constant <{ ptr, [9 x i8], [7 x i8] }> <{ ptr @alloc_71400f724d40df1ad286a16089108cb1, [9 x i8] c"\1B\00\00\00\00\00\00\00%", [7 x i8] undef }>, align 8
@alloc_ae6dc619079e3c3b08144a35532ecff7 = hidden unnamed_addr constant <{ [2 x i8] }> <{ [2 x i8] c"()" }>, align 1
@vtable.4 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr, ptr, ptr }> <{ ptr @"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h53681e21be2b428cE", [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN58_$LT$alloc..string..String$u20$as$u20$core..fmt..Write$GT$9write_str17h4b62f46a222bd5b2E", ptr @"_ZN58_$LT$alloc..string..String$u20$as$u20$core..fmt..Write$GT$10write_char17hfde5b685689164ccE", ptr @_ZN4core3fmt5Write9write_fmt17h53c8d8d7fdb75a67E }>, align 8
@alloc_cc656815297f75969399c3f4b1ad3de4 = hidden unnamed_addr constant <{ [55 x i8] }> <{ [55 x i8] c"a Display implementation returned an error unexpectedly" }>, align 1
@vtable.5 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17hfff795df28ddb366E", [16 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @"_ZN53_$LT$core..fmt..Error$u20$as$u20$core..fmt..Debug$GT$3fmt17h85666afa16c4890eE" }>, align 8
@alloc_0c7342d701a2219de6bddb6c078f5127 = hidden unnamed_addr constant <{ [84 x i8] }> <{ [84 x i8] c"/home/runner/work/platform-tools/platform-tools/out/rust/library/alloc/src/string.rs" }>, align 1
@alloc_d5d9fccaf545b6e0545ef73245a3c43f = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0c7342d701a2219de6bddb6c078f5127, [16 x i8] c"T\00\00\00\00\00\00\00\FF\09\00\00\0E\00\00\00" }>, align 8
@alloc_6f4357e3a3c9006d5d6d935934a9de54 = hidden unnamed_addr constant <{ [5 x i8] }> <{ [5 x i8] c"false" }>, align 1
@alloc_c9ee9951a160df092319190fa06505e4 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"true" }>, align 1
@vtable.6 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h224faf946767fbc8E" }>, align 8
@alloc_7b73f73f49a8b1a2b56b11f4317d5a4d = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6bd46028dd5544964a6ecdc7f0a2138c, [16 x i8] c"\0D\00\00\00\00\00\00\00\A1\00\00\006\00\00\00" }>, align 8
@alloc_bca19676efa78b9e7fcb01d94d4c0d5a = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"Unexpected length of input" }>, align 1
@alloc_d81dc6d0b85a0517a90bd431d102ce73 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6bd46028dd5544964a6ecdc7f0a2138c, [16 x i8] c"\0D\00\00\00\00\00\00\00\A9\00\00\00\15\00\00\00" }>, align 8
@alloc_603472fcea6a9fc2af74ff24b89bda39 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"Invalid bool representation: " }>, align 1
@alloc_30ee8369a28ffb738dd1f60fce83b267 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_603472fcea6a9fc2af74ff24b89bda39, [8 x i8] c"\1D\00\00\00\00\00\00\00" }>, align 8
@alloc_99ac8a81a24cac863217ce4a5cbfabea = hidden unnamed_addr constant <{ [5 x i8] }> <{ [5 x i8] c"Error" }>, align 1
@alloc_97f258b5404f9aad211c607c9158830b = hidden unnamed_addr constant <{ [104 x i8] }> <{ [104 x i8] c"/home/runner/work/platform-tools/platform-tools/out/rust/library/alloc/src/collections/btree/navigate.rs" }>, align 1
@alloc_3937f3d3e8db7244fcfa1c3b0113e994 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_97f258b5404f9aad211c607c9158830b, [16 x i8] c"h\00\00\00\00\00\00\00Y\02\00\000\00\00\00" }>, align 8
@alloc_b38aff3a6ff2b35340e262da817c1070 = hidden unnamed_addr constant <{ [85 x i8] }> <{ [85 x i8] c"/home/runner/work/platform-tools/platform-tools/out/rust/library/alloc/src/vec/mod.rs" }>, align 1
@alloc_21fb3a4531199f65e9b4751b9e3816cb = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b38aff3a6ff2b35340e262da817c1070, [16 x i8] c"U\00\00\00\00\00\00\00(\0C\00\00\0D\00\00\00" }>, align 8
@alloc_a62a4ed9a4f6cb12004726ac0a3eacf7 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"Not all bytes read" }>, align 1
@alloc_dbbec7e9ccaadddef423de02c4aee690 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\06\DD\F6\E1\D7e\A1\93\D9\CB\E1F\CE\EBy\AC\1C\B4\85\ED_[7\91:\8C\F5\85~\FF\00\A9" }>, align 1
@alloc_535624b4d91d04fd1c38f9a9a6c3a58b = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"MaxSeedLengthExceeded" }>, align 1
@alloc_d5148c53152e1d5faf1e5eba32a2e626 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"InvalidSeeds" }>, align 1
@alloc_a6abf6fb0908525f5f82cf8d0fdf3ff7 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"IllegalOwner" }>, align 1
@alloc_4ae674906ed32b449492a903e3132a41 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\0Bpe\B1\E3\D1|E8\9DR\7Fk\04\C3\CDX\B8ls\1A\A0\FD\B5I\B6\D1\BC\03\F8)F" }>, align 1
@vtable.9 = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h44a058432f38c65bE" }>, align 8
@alloc_01e997627eb226f7f1f6c343aba6a79b = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\06\DD\F6\E1\EEu\8F\DE\18B]\BC\E4l\CD\DA\B6\1A\FCM\83\B9\0D'\FE\BD\F9(\D8\A1\8B\FC" }>, align 1
@alloc_dc42eb79c008f8376af822bf36dea6b6 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6bd46028dd5544964a6ecdc7f0a2138c, [16 x i8] c"\0D\00\00\00\00\00\00\00}\02\00\00\15\00\00\00" }>, align 8
@alloc_5cb263f26a5d50117adfcc5c7225745e = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"TryFromIntError" }>, align 1
@alloc_3b0387272f41620dda4018b53d7e88c0 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"Unexpected variant index: " }>, align 1
@alloc_baf38683b0c7fd0e7bdf2069845b5ce3 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_3b0387272f41620dda4018b53d7e88c0, [8 x i8] c"\1A\00\00\00\00\00\00\00" }>, align 8
@alloc_160cd9dc12a0e24312faa35b3cd08381 = hidden unnamed_addr constant <{ [6 x i8] }> <{ [6 x i8] c"Custom" }>, align 1
@vtable.a = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17hbc73631fb23b9a71E" }>, align 8
@alloc_ffc5a366cb1631fac44681b805c26365 = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"InvalidArgument" }>, align 1
@alloc_309723647777e2abb581866a138e56d0 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"InvalidInstructionData" }>, align 1
@alloc_158608be73da124260accb69cee8141f = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"InvalidAccountData" }>, align 1
@alloc_e303c9d3c3aa51d700a9d50b8b3a6f77 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"AccountDataTooSmall" }>, align 1
@alloc_375115f23c11798ad3e1831e50c8f3b0 = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"InsufficientFunds" }>, align 1
@alloc_4ba93db50abd996d36191d587a1a8bd7 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"IncorrectProgramId" }>, align 1
@alloc_c16819ed381dc3d8330dd4fbf7608687 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"MissingRequiredSignature" }>, align 1
@alloc_df956248b356e34aaba5606e296aa326 = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"AccountAlreadyInitialized" }>, align 1
@alloc_fcf16569b0b173cd2bea7bf76eb5a0dd = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"UninitializedAccount" }>, align 1
@alloc_0b1925b05a65f699943dbc9b2959a1e3 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"NotEnoughAccountKeys" }>, align 1
@alloc_17e92a740d5f0cbaad5669fe0f93bfe1 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"AccountBorrowFailed" }>, align 1
@alloc_57abc5c31744084dd73eb79c38812e79 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"BorshIoError" }>, align 1
@vtable.b = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h53b179cc1d7f7e79E" }>, align 8
@alloc_87c97045fdfd76726961462d656d4c19 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"AccountNotRentExempt" }>, align 1
@alloc_c5fcc3fa26f6cf8948af3c2f919c69be = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"UnsupportedSysvar" }>, align 1
@alloc_4e0c9af860f62a415029d63330268c47 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"MaxAccountsDataAllocationsExceeded" }>, align 1
@alloc_2cc539c76dc43d0e064b0c3927f6632e = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"InvalidRealloc" }>, align 1
@alloc_d45ed2f3fb9915d85b6f356e1b721f39 = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"MaxInstructionTraceLengthExceeded" }>, align 1
@alloc_584c53d4e606eba5a6a57ac49401016f = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"BuiltinProgramsMustConsumeComputeUnits" }>, align 1
@alloc_16e2c3db4b9d70e542110411f2492215 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"InvalidAccountOwner" }>, align 1
@alloc_937ef498e46ce3dd2899f48f05d77c47 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"ArithmeticOverflow" }>, align 1
@alloc_71f80a1b579055168bb233afed18ca75 = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"Immutable" }>, align 1
@alloc_8ebfcac1eb6786483fa6fc876e58caf4 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"IncorrectAuthority" }>, align 1
@alloc_1a30e9f5fb9cee2547551078183bc130 = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"Invalid Option representation: " }>, align 1
@alloc_8284c68d72a0422d899c58d4645aa650 = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c". The first byte must be 0 or 1" }>, align 1
@alloc_11d3a53330601bb5ad8112ec6c9d62a1 = hidden unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_1a30e9f5fb9cee2547551078183bc130, [8 x i8] c"\1F\00\00\00\00\00\00\00", ptr @alloc_8284c68d72a0422d899c58d4645aa650, [8 x i8] c"\1F\00\00\00\00\00\00\00" }>, align 8
@alloc_f5542b9f318d526016e1b9baaaadbffa = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"Uninitialized" }>, align 1
@alloc_1190bf4064171add2275f3df22248adb = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"TransferFeeConfig" }>, align 1
@alloc_9cd990d5d248c39ebdc9607e9143bc39 = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"TransferFeeAmount" }>, align 1
@alloc_775f29598939ee7bb52acde31f7b471e = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"MintCloseAuthority" }>, align 1
@alloc_c3f3d9df3e0164987abf365641e41863 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"ConfidentialTransferMint" }>, align 1
@alloc_19dd49a4cc9dcc2a6799cbb6e4c516da = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"ConfidentialTransferAccount" }>, align 1
@alloc_b2fd940a6958d914f7ff0f425727c652 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"DefaultAccountState" }>, align 1
@alloc_d137368cb6f78403ab4c9b987f2b01b6 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"ImmutableOwner" }>, align 1
@alloc_613a419a9338b35a4d056b2ab4be1a0a = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"MemoTransfer" }>, align 1
@alloc_223476a89c7d867259db8b891b05b719 = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"NonTransferable" }>, align 1
@alloc_3b8861cdf52a55d739e5eabf1f07845f = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"InterestBearingConfig" }>, align 1
@alloc_41824bf42c66930808a60a7f43007a5b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"CpiGuard" }>, align 1
@alloc_85ae8d0901125a59221b6e4becb6ea1c = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"PermanentDelegate" }>, align 1
@alloc_9f36054864c0b6db55768c5873cfd3d4 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"NonTransferableAccount" }>, align 1
@alloc_48112cc46f498a60ee8b2b33e05705ec = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"TransferHook" }>, align 1
@alloc_2ee095bed7a41b2d857c6dd72a1c0600 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"TransferHookAccount" }>, align 1
@alloc_39d69bb3b75ab0e33046a6fe919b4c6f = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"ConfidentialTransferFeeConfig" }>, align 1
@alloc_906b31239e72393bdac8a27ef95fed8b = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"ConfidentialTransferFeeAmount" }>, align 1
@alloc_83bf6df597ab614dbd313a974c179213 = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"MetadataPointer" }>, align 1
@alloc_1650ec5c75b037bb679970bc6baa6288 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"TokenMetadata" }>, align 1
@alloc_6f2722d2ca5aee11a5ef0ec55ba000b2 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"GroupPointer" }>, align 1
@alloc_887eb9dc9bc24345a7eaa2b2d6311806 = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"TokenGroup" }>, align 1
@alloc_4580d0ca7a471523ec389e80202f3e02 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"GroupMemberPointer" }>, align 1
@alloc_19923f9a33cd85fe630b1a7936fcc1e5 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"TokenGroupMember" }>, align 1
@alloc_8111738db6d701d02c7d0821de4f554b = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"ConfidentialMintBurn" }>, align 1
@alloc_90b534e8918f824e66f9fe54e8079088 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\18Fb\BF:\90{\9E" }>, align 1
@alloc_c5abb6066b2124781c57c4362dc0ae45 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\8C\97%\8FN$\89\F1\BB=\10)\14\8E\0D\83\0BZ\13\99\DA\FF\10\84\04\8E{\D8\DB\E9\F8Y" }>, align 1
@alloc_2a2c3337e4ac91b043ecf1388048ce4e = hidden unnamed_addr constant <{ [7 x i8] }> <{ [7 x i8] c"Account" }>, align 1
@alloc_34f98efaaefeba3e70f7cb335625c0f9 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\C4\0B\00\00" }>, align 4
@alloc_497143d5a435058af86380b8b50d7aca = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"programs\\pump\\src\\buy_v2.rs" }>, align 1
@alloc_7bf4d83167a444e3cf51563928dad022 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 4
@alloc_85b5ec2b6dd9d9b3c047fa3c0ea49204 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\00\00\00" }>, align 4
@alloc_2f475e84d260dce0bf2e60beae6b9ec7 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\D6\07\00\00" }>, align 4
@alloc_e953c1d75e6a4349f2dca6892c168ab2 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\06\9B\88W\FE\AB\81\84\FBh\7FcF\18\C05\DA\C49\DC\1A\EB;U\98\A0\F0\00\00\00\00\01" }>, align 1
@alloc_472c5e093ab64810a72f5ef4158854b7 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"?\00\00\00" }>, align 4
@alloc_65b7b62d1c393af7ea07c820158a5930 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"bonding-curve" }>, align 1
@alloc_4aabaedbd62f6ec96f36599a97af2908 = hidden unnamed_addr constant <{ [3 x i8] }> <{ [3 x i8] c"buy" }>, align 1
@alloc_d1e50873cb16f1fc41ca481a2a657dfa = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E4E\A5.Q\CB\9A\1D" }>, align 1
@alloc_7a7952b5e0d15f2b72d0341cef6d4739 = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"__event_authority" }>, align 1
@alloc_2e38410fced2c310c68bdf2d45d0c3bd = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 4
@alloc_9032913b93df2a93f8a032d18ba5abf9 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\15\00\00\00" }>, align 4
@alloc_e3e143fb26e9bc2a81054057f78086ba = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\14\00\00\00" }>, align 4
@alloc_cdbdeba67b052fefbde5996b437aa24e = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 4
@alloc_129e638c7e77b36305a17c29941dd237 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\19\00\00\00" }>, align 4
@alloc_e7ecca184d1801ae8ba4577ecc1a7822 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\18\00\00\00" }>, align 4
@alloc_004acfa89553cbafbb2b2f00006c54c3 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"*\00\00\00" }>, align 4
@alloc_73667b43dd614c93c329aef199c5ef8b = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c")\00\00\00" }>, align 4
@alloc_435cd7fec56ec5d48bfe9f58bddc4b9c = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"buy_exact_quote_in" }>, align 1
@alloc_d94ed8e97f85e9d4a928f6843960fd6f = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"mint-authority" }>, align 1
@alloc_f8b9c94f4a1e21fc26594ad8880f6dcd = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"programs\\pump\\src\\create_v2.rs" }>, align 1
@alloc_b7f057a700061b96879a1cf049d1c13f = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"@\00\00\00" }>, align 4
@alloc_a3589b010e8c0a509a420d55bdd24119 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\83\0D\FC\9F\DE_\E6\B8\AA|\04\A4v\E9\1E\8A\C6\BB&J\AD\90\FA\19\C9\DFI\D8\\>[^" }>, align 1
@alloc_d8c0a5dba5e722d6ee3b9565370a7c8b = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\0CE\F7\DF\8D\9Er\95b\84\93?m\98\B7W\03.\83\DF\84`O\B5\E1\17\FF\F6\1D[\12\F9" }>, align 1
@alloc_3978b63fb96cd488af3e7f8e0944e743 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"A\00\00\00" }>, align 4
@alloc_7abef1d9605f2433edf33d364558b41c = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\1B\00\00\00" }>, align 4
@alloc_57449aa894846faa4c18fccb8ba383a5 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"quote-control" }>, align 1
@alloc_59a8698f926c3cca805b152172005aad = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_57449aa894846faa4c18fccb8ba383a5, [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@alloc_eb885cc9dbb161546a71699288342bcb = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"K\00\00\00" }>, align 4
@alloc_4c19c2f7a0bfa516fdb81172c7999bfc = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f8b9c94f4a1e21fc26594ad8880f6dcd, [16 x i8] c"\1E\00\00\00\00\00\00\00\81\01\00\00\1D\00\00\00" }>, align 8
@alloc_0c7c662ad902b0f9889ae3e7d4a1e0f6 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f8b9c94f4a1e21fc26594ad8880f6dcd, [16 x i8] c"\1E\00\00\00\00\00\00\00\AA\01\00\00@\00\00\00" }>, align 8
@alloc_af995923a0f2cfedcdb19bb6362b5829 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"d\00\00\00" }>, align 4
@alloc_49b783a8987cf5e8baf94494c746b206 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"m\00\00\00" }>, align 4
@alloc_5b64c5758b3793302fbedcd0481de01a = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"c\00\00\00" }>, align 4
@alloc_433d831c25c8c7123394421d4775e9f3 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"e\00\00\00" }>, align 4
@alloc_837d2dfc2ca6132d7e624d246f381ca4 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"pool-authority" }>, align 1
@alloc_bfc098cb63b041e1e9ec31a95db422e0 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"pool" }>, align 1
@alloc_039ed2e6f9c8eb49c78833344691f9d1 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f8b9c94f4a1e21fc26594ad8880f6dcd, [16 x i8] c"\1E\00\00\00\00\00\00\00\E8\01\00\00\13\00\00\00" }>, align 8
@alloc_2c0b2ec70715e6c5f61803e915dfc897 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"k\00\00\00" }>, align 4
@alloc_98fb01e586ad980c5471b8ec107fefb9 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"-\00\00\00" }>, align 4
@alloc_022a7224973e9ad3ccb65a26923fb420 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c",\00\00\00" }>, align 4
@alloc_576b45ec2f88fc1b160b0731788b05b1 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"+\00\00\00" }>, align 4
@alloc_f94f166953c814e4161e699857179a1e = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"T\00\00\00" }>, align 4
@alloc_df68464402562fbf659e5577c3ed192b = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"holder-rewards" }>, align 1
@alloc_f76a96604a454814dbba396bf7b74843 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"G\00\00\00" }>, align 4
@alloc_01eaaa187d2be542d4425f23ab284310 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"M\00\00\00" }>, align 4
@alloc_973adb9e8664e25d4750ddb14e0de56a = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"N\00\00\00" }>, align 4
@alloc_10c47fca48632193e88591e682957392 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c".\00\00\00" }>, align 4
@alloc_0e3505805f4905816c1bd644811a7869 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\1E\00\00\00" }>, align 4
@alloc_b0b2a182f92294de465c6bd658b159d4 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"R\00\00\00" }>, align 4
@alloc_17ff8408cb8e527722e7af61db344e75 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"0\00\00\00" }>, align 4
@alloc_be1870a47f24c9603a822713d0fb2fae = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"programs\\pump\\src\\creator\\admin_cto.rs" }>, align 1
@alloc_b5f839a6bda937f2cae73e49fc88071f = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"Z\00\00\00" }>, align 4
@alloc_1ba5e1e397ae92b788c97e688ac0b362 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"Y\00\00\00" }>, align 4
@alloc_861c8964bbad6d9cede9df277e628fe9 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\13\00\00\00" }>, align 4
@alloc_835bb996f1795bf0338da0490417da62 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"P\00\00\00" }>, align 4
@alloc_e75cefee4bb91125af0ea8444b842ed0 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"[\00\00\00" }>, align 4
@alloc_ee8d284dcc9255c78333f4d983077741 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\\\00\00\00" }>, align 4
@alloc_84e4dd413cb0e2cff6ff4abdd65f9f92 = hidden unnamed_addr constant <{ [61 x i8] }> <{ [61 x i8] c"Creator is not a system-owned wallet; fees left in the vaults" }>, align 1
@alloc_deddac2d627577b5c14e9bbeacabf74e = hidden unnamed_addr constant <{ [62 x i8] }> <{ [62 x i8] c"Creator quote token account is frozen; fees left in the vaults" }>, align 1
@alloc_ed0c7b53f6fd188c408cb80c27c2e0f7 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"creator-vault" }>, align 1
@alloc_cd7b816cab57a667caebec1ad637a70c = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"]\00\00\00" }>, align 4
@alloc_f1e0cbbc2b934c2f02dd0c84a052221d = hidden unnamed_addr constant <{ [48 x i8] }> <{ [48 x i8] c"No canonical pump pool for this mint; curve only" }>, align 1
@alloc_8c4fa5903d7de618e7d31a64bef65c37 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"_\00\00\00" }>, align 4
@alloc_8f95cb73e89711d65e95d13598508b19 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"S\00\00\00" }>, align 4
@alloc_eb4f91695bc6f999067c65f428fcc4d8 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"X\00\00\00" }>, align 4
@alloc_188c7f0256b9c07988f4e8d375e3d989 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"2\00\00\00" }>, align 4
@alloc_1e69a7824691c6e9f5bfca38bf965fc5 = hidden unnamed_addr constant <{ [48 x i8] }> <{ [48 x i8] c"programs\\pump\\src\\creator\\collect_creator_fee.rs" }>, align 1
@alloc_5498dfd4a968bfcaaac4f558136ebcbb = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"No creator fee to collect" }>, align 1
@alloc_1c40824c376acf160424c4cacdf01ccf = hidden unnamed_addr constant <{ [60 x i8] }> <{ [60 x i8] c"Creator account does not have enough rent-exemption lamports" }>, align 1
@alloc_7ca949c2da004eae129a27ba8277f787 = hidden unnamed_addr constant <{ [60 x i8] }> <{ [60 x i8] c"Creator account is executable, so it cannot receive lamports" }>, align 1
@alloc_1af00ae4c528fb4548c2d6dac315a336 = hidden unnamed_addr constant <{ [52 x i8] }> <{ [52 x i8] c"programs\\pump\\src\\creator\\distribute_creator_fees.rs" }>, align 1
@alloc_e989b8ff5101f0d1a057a8b3a6d8e720 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\17\B7\F87`\D8\AC`" }>, align 1
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = hidden unnamed_addr constant <{ [43 x i8] }> <{ [43 x i8] c"called `Result::unwrap()` on an `Err` value" }>, align 1
@alloc_173e3e7540865e0ac58f9d0d81a34672 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"6\00\00\00" }>, align 4
@alloc_fe8b410779777ec2de82c43c8cef11c1 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"Unable to distribute to " }>, align 1
@alloc_99ac492ffbe57a744fd3c1b1bc715ca0 = hidden unnamed_addr constant <{ [108 x i8] }> <{ [108 x i8] c". Shareholder is a program account, use pump_fees::update_fee_shares to remove the shareholder from the team" }>, align 1
@alloc_8c82311c9d7a463b563df7ec3b8fd049 = hidden unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_fe8b410779777ec2de82c43c8cef11c1, [8 x i8] c"\18\00\00\00\00\00\00\00", ptr @alloc_99ac492ffbe57a744fd3c1b1bc715ca0, [8 x i8] c"l\00\00\00\00\00\00\00" }>, align 8
@alloc_5f5a29cb9d4b09eb429f7773a22cce85 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"4\00\00\00" }>, align 4
@alloc_9c8e592ae99883418f5f3096d1bf9544 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"7\00\00\00" }>, align 4
@alloc_291096b6f55f52ba95f5780c18f27cb0 = hidden unnamed_addr constant <{ [66 x i8] }> <{ [66 x i8] c"Insufficient fees for distribution. Minimum vault balance needed: " }>, align 1
@alloc_a0eee4cb1f0ad3303950fd26c1f7e916 = hidden unnamed_addr constant <{ [99 x i8] }> <{ [99 x i8] c" lamports. Use get_minimum_distributable_fee instruction to check the minimum distributable amount." }>, align 1
@alloc_270c27ee6ce426a26e1f0b51f3ac7d89 = hidden unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_291096b6f55f52ba95f5780c18f27cb0, [8 x i8] c"B\00\00\00\00\00\00\00", ptr @alloc_a0eee4cb1f0ad3303950fd26c1f7e916, [8 x i8] c"c\00\00\00\00\00\00\00" }>, align 8
@alloc_ca30031b23f38a88b69f101290358f81 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"3\00\00\00" }>, align 4
@alloc_cf5d42488f4d370d58fb9f46c1f93e62 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1af00ae4c528fb4548c2d6dac315a336, [16 x i8] c"4\00\00\00\00\00\00\00G\01\00\00\16\00\00\00" }>, align 8
@alloc_8f2173acecde08102f9482d52f61bc57 = hidden unnamed_addr constant <{ [54 x i8] }> <{ [54 x i8] c"programs\\pump\\src\\creator\\distribute_creator_fee_v2.rs" }>, align 1
@alloc_38bc4bb7d37d51c4df67f6f4b77ab7a8 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"F\00\00\00" }>, align 4
@alloc_6b589eb72437b39aa25e2ffb59095cfe = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8f2173acecde08102f9482d52f61bc57, [16 x i8] c"6\00\00\00\00\00\00\00V\01\00\00\16\00\00\00" }>, align 8
@alloc_071a8c0ac61f198bf6c9a451edea482d = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"U\00\00\00" }>, align 4
@alloc_e81637b6cbc166f0268c098c52304abe = hidden unnamed_addr constant <{ [54 x i8] }> <{ [54 x i8] c"programs\\pump\\src\\creator\\distribute_fee_to_holders.rs" }>, align 1
@alloc_7281624ae182d84fc7aeabf975644b24 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"V\00\00\00" }>, align 4
@alloc_2a7644ee5be710b59f37f51b3b165f9a = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e81637b6cbc166f0268c098c52304abe, [16 x i8] c"6\00\00\00\00\00\00\00r\00\00\00\16\00\00\00" }>, align 8
@alloc_726b9e1154b90a8aca86675bd51e6f5e = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e81637b6cbc166f0268c098c52304abe, [16 x i8] c"6\00\00\00\00\00\00\00y\00\00\00,\00\00\00" }>, align 8
@alloc_05d779aac731d365773324f7854b0e40 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"W\00\00\00" }>, align 4
@alloc_35d63c4ab7f569806e0412089134d94b = hidden unnamed_addr constant <{ [58 x i8] }> <{ [58 x i8] c"programs\\pump\\src\\creator\\migrate_bonding_curve_creator.rs" }>, align 1
@alloc_3d2a4c41352957abf6b920bd54cb9069 = hidden unnamed_addr constant <{ [40 x i8] }> <{ [40 x i8] c"programs\\pump\\src\\creator\\set_creator.rs" }>, align 1
@alloc_556944164b60f331267cc12cc78e5ad0 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3d2a4c41352957abf6b920bd54cb9069, [16 x i8] c"(\00\00\00\00\00\00\00?\00\00\00\1F\00\00\00" }>, align 8
@alloc_0628ff60cb17dfcd0d68fa09474b0737 = hidden unnamed_addr constant <{ [37 x i8] }> <{ [37 x i8] c"Bonding curve has creator already set" }>, align 1
@alloc_da90d4b7a2bea00f88a6d095e2777a92 = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"Missing metaplex creators" }>, align 1
@alloc_843fb92659a6ea29ea44050a8e95584d = hidden unnamed_addr constant <{ [49 x i8] }> <{ [49 x i8] c"programs\\pump\\src\\creator\\set_metaplex_creator.rs" }>, align 1
@alloc_0e60ce1737b3e7c26507f9e86c69cbbb = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_843fb92659a6ea29ea44050a8e95584d, [16 x i8] c"1\00\00\00\00\00\00\00+\00\00\00\1F\00\00\00" }>, align 8
@alloc_3239b484319fa41f90ac18623353bb60 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"programs\\pump\\src\\buy.rs" }>, align 1
@alloc_550d7884d781858aa06fd1f9f6baa933 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"buy_exact_sol_in" }>, align 1
@alloc_c50bce385362215ca5f1bf126ebde296 = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"Account already has more than " }>, align 1
@alloc_0f6d902ea281db90dc288f1fb0e42028 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c" bytes: " }>, align 1
@alloc_daefa1bc22becf43e3bccc0d01a94689 = hidden unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_c50bce385362215ca5f1bf126ebde296, [8 x i8] c"\1E\00\00\00\00\00\00\00", ptr @alloc_0f6d902ea281db90dc288f1fb0e42028, [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@alloc_3e24b76d4373702a88796db30a28e45c = hidden unnamed_addr constant <{ [36 x i8] }> <{ [36 x i8] c"Account already has the correct size" }>, align 1
@alloc_53b9f85d633812f12e2fee88cbdafe33 = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"programs\\pump\\src\\extend_account.rs" }>, align 1
@alloc_6dd084cfaeca32bc891063d2e2dafe7e = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_53b9f85d633812f12e2fee88cbdafe33, [16 x i8] c"#\00\00\00\00\00\00\00Y\00\00\009\00\00\00" }>, align 8
@alloc_a974a47c4e4953ae4144f8def4d3b8a5 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\A7\E8\E8\B1\C8lr\7F" }>, align 1
@alloc_e0daa402169c5d00cc3209abbe6eac7f = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\CA*\F6+\8E\BE\1E\FF" }>, align 1
@alloc_b20e4c2865dc14cf2e2bc422dbdb0ea6 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"V\FFp\0Ef5\9A\FA" }>, align 1
@alloc_23cd3c8b5d61033fcc842cf3d9439bee = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 4
@alloc_cedbe0e69324b1e6a8306e2fa98652d2 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"programs\\pump\\src\\migrate.rs" }>, align 1
@alloc_6f6dc29b2dca005d8b0cd1eacbefa61f = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"Bonding curve already migrated" }>, align 1
@vtable.d = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17h53bad7d65d9ed72bE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN58_$LT$std..io..error..Error$u20$as$u20$core..fmt..Debug$GT$3fmt17had9d55c5608fe73bE" }>, align 8
@alloc_5e603a17cff5412c19238cfd83fdcf84 = hidden unnamed_addr constant <{ [4 x i8], [76 x i8] }> <{ [4 x i8] c"\11\00\00\00", [76 x i8] undef }>, align 8
@alloc_5988afcf0b7004c7e877209ec2df5f18 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cedbe0e69324b1e6a8306e2fa98652d2, [16 x i8] c"\1C\00\00\00\00\00\00\00\93\02\00\00+\00\00\00" }>, align 8
@alloc_73dab1a1deecc3f11630b3eba238c203 = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"programs\\pump\\src\\migrate_v2.rs" }>, align 1
@alloc_cd8d6bedf7d6dfc966e7b3272095af97 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_7a7952b5e0d15f2b72d0341cef6d4739, [8 x i8] c"\11\00\00\00\00\00\00\00" }>, align 8
@alloc_67b53d2e596e5ce18f820e66fe69ee72 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"n\00\00\00" }>, align 4
@alloc_32dceda0b9137740cc04529d1f58634a = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_73dab1a1deecc3f11630b3eba238c203, [16 x i8] c"\1F\00\00\00\00\00\00\004\03\00\00+\00\00\00" }>, align 8
@alloc_cb78adb47405fa5c7993aa2bc1118c67 = hidden unnamed_addr constant <{ [41 x i8] }> <{ [41 x i8] c"programs\\pump\\src\\multi_hop_curve_swap.rs" }>, align 1
@alloc_8492bd270dcefb77a29b075f946eb9d7 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\8F4\92\BB\DB{L\9B" }>, align 1
@alloc_0e4cd3ca48427525e62bdc7fe48442ec = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\BA\0B\00\00" }>, align 4
@alloc_880a0465935e76b0f8f5fc417ab21bfc = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\B9\0B\00\00" }>, align 4
@alloc_5ba5b226d6eac5c86f5bced2d75aa471 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\BB\0B\00\00" }>, align 4
@alloc_2089b7ef4a8e828fe7e054c0f82596ff = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\1A\00\00\00" }>, align 4
@alloc_71406ec535923812f66dcf232ef12304 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"j\00\00\00" }>, align 4
@alloc_4ec106804a8f5cec067459e8804c2e9d = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"b\00\00\00" }>, align 4
@alloc_8b6dd88f9666cc940fc9eee638dda53a = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb78adb47405fa5c7993aa2bc1118c67, [16 x i8] c")\00\00\00\00\00\00\00\E8\00\00\00 \00\00\00" }>, align 8
@alloc_e66071d94605838e7dc5950cdad7bb3a = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\16\00\00\00" }>, align 4
@alloc_013b1ce26fcfe133dc7bd48feec9d10b = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"multi_hop_swap" }>, align 1
@alloc_d363254d70c842edf8891da61932dc9d = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"l\00\00\00" }>, align 4
@alloc_42ac2a07657cfe45f91240cd4b0ab720 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"i\00\00\00" }>, align 4
@alloc_e1b7beb5b69d8366b1a63170253ac2aa = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"programs\\pump\\src\\pump_quote.rs" }>, align 1
@alloc_766f21e34fd7facce577e1e15aa15ec3 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"h\00\00\00" }>, align 4
@alloc_08c5434f9bf26d5f8247a10be362dee9 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\F1\9Am\04\11\B1m\BC" }>, align 1
@alloc_19b30b7ef982010a55577617309874c3 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"g\00\00\00" }>, align 4
@alloc_ffac07c43414ef1a6e0e87389fc8fbb8 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"f\00\00\00" }>, align 4
@alloc_74b629c72efcdc1614418b0c46630921 = hidden unnamed_addr constant <{ [40 x i8] }> <{ [40 x i8] c"programs\\pump\\src\\quote_control\\state.rs" }>, align 1
@alloc_17162b45ee17511577f0706c6fb7cd67 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"C\00\00\00" }>, align 4
@alloc_1049cd8c59f9ff665bbb603eedfa6b88 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"B\00\00\00" }>, align 4
@alloc_5921072e4df4f99a3b42c78318e01529 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"E\00\00\00" }>, align 4
@alloc_d023d1d21dc8ac6bdbac0e1db6d6c769 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"D\00\00\00" }>, align 4
@alloc_758639ec0787b0163ab6b34982b5ae95 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"8\F4#\EE\C1\D5\A2\C9" }>, align 1
@alloc_3b35b96e6eae623def8bfb23b096e2a5 = hidden unnamed_addr constant <{ [61 x i8] }> <{ [61 x i8] c"programs\\pump\\src\\quote_control\\update_quote_control_mints.rs" }>, align 1
@alloc_83ea17bf0c4f4a5a5a13d3ae7955acd0 = hidden unnamed_addr constant <{ [4 x i8] }> zeroinitializer, align 4
@alloc_78384a8f7347a07a88bfb48a13c0c77c = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"programs\\pump\\src\\fee_recipient.rs" }>, align 1
@alloc_b091ea0fed7e3a4cea05781baed486d6 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\1C\00\00\00" }>, align 4
@alloc_c494d62ab9e88ddf93a565513be3cd06 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\1D\00\00\00" }>, align 4
@alloc_3eaa20157d77f4bf13868cb264d2a237 = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"fee_recipients[" }>, align 1
@alloc_7a6887ef0f93938f57a4bb958cf80311 = hidden unnamed_addr constant <{ [1 x i8] }> <{ [1 x i8] c"]" }>, align 1
@alloc_6c820937830caf674e2b5f8ecad15688 = hidden unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_3eaa20157d77f4bf13868cb264d2a237, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @alloc_7a6887ef0f93938f57a4bb958cf80311, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@alloc_fabafc038ecb1ba6e1a90d59317e3f88 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"user_volume_accumulator" }>, align 1
@alloc_b343bb90cb5b8cd3aea891815b41ee59 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"I\00\00\00" }>, align 4
@alloc_497f2f2d7ea467462554563ab6979ab9 = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"programs\\pump\\src\\sell.rs" }>, align 1
@alloc_696b87fbd957ea511b91681bcb141d88 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_497f2f2d7ea467462554563ab6979ab9, [16 x i8] c"\19\00\00\00\00\00\00\00<\00\00\00\0D\00\00\00" }>, align 8
@alloc_402d5828f4f47d9f7b77d9d72611269f = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_497f2f2d7ea467462554563ab6979ab9, [16 x i8] c"\19\00\00\00\00\00\00\00=\00\00\00\0D\00\00\00" }>, align 8
@alloc_6ac7cb0b08a6f87d7a8f69323bf9faf2 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"J\00\00\00" }>, align 4
@alloc_6054b559f7f298738fff03bb75f35079 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"bonding-curve-v2" }>, align 1
@alloc_775ee4878a6ce17fa6bd1f4a6689f4c4 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"H\00\00\00" }>, align 4
@alloc_60cd7092cdeacdea3a02e802f3f788b7 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"programs\\pump\\src\\util\\fee.rs" }>, align 1
@alloc_3820a2467563375e87dd503192695b40 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"`\00\00\00" }>, align 4
@alloc_5e1f7e2186c534569e1bce6fa9329954 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"a\00\00\00" }>, align 4
@alloc_91dc7198fcb52d54c5307b3b1115d768 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\C6\FAz\F3\BE\DB\AD:=e\F3j\AB\C9t1\B1\BB\E4\C2\D2\F6\E0\E4|\A6\02\03E/]a" }>, align 1
@alloc_5bb83cc25a7fae0c017019be8976bd4d = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c">\00\00\00" }>, align 4
@alloc_26a1ca2481379954c55292f0120334eb = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"programs\\pump\\src\\sell_v2.rs" }>, align 1
@alloc_a8e2a7837cf47ea0175cf2cdf296029a = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"sell" }>, align 1
@alloc_bc6c24833cc57d8ab679f3fbe0b0ac4a = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 4
@alloc_1f1600f67af89fc229573eafc1a3b5f5 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\17\00\00\00" }>, align 4
@alloc_7e3d068963922fe06b0b93efdaba1410 = hidden unnamed_addr constant <{ [48 x i8] }> <{ [48 x i8] c"programs\\pump\\src\\set_reserved_fee_recipients.rs" }>, align 1
@alloc_a8bce8d05cd02d3e0f2bb9ed983bb595 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"reserved_fee_recipients[" }>, align 1
@alloc_4fc76a7bf9e3de1def9ef20508b5e9c1 = hidden unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_a8bce8d05cd02d3e0f2bb9ed983bb595, [8 x i8] c"\18\00\00\00\00\00\00\00", ptr @alloc_7a6887ef0f93938f57a4bb958cf80311, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@alloc_bd072da4dc5aa322914b9aa5b0dc7ef4 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"=\00\00\00" }>, align 4
@alloc_292ce6bf9090d44a9e4412db66b3ffaa = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"Nothing to sweep for fee bucket " }>, align 1
@alloc_9f72cf9f41c5b7315a0f9d612a07daf3 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_292ce6bf9090d44a9e4412db66b3ffaa, [8 x i8] c" \00\00\00\00\00\00\00" }>, align 8
@alloc_c9ecec1964dd14afe1df70fd8c3b87ce = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"programs\\pump\\src\\sweep_fees.rs" }>, align 1
@alloc_2ff5546dd34282b7d06d9710e1ed2ce8 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"GlobalVolumeAccumulator=" }>, align 1
@alloc_3d11246b8f5895ad90304fe49b9b936c = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_2ff5546dd34282b7d06d9710e1ed2ce8, [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
@alloc_888dc331af984dc79f7bf84d83f0be62 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"No tokens to claim" }>, align 1
@alloc_19d5b7333c5961fcce9b62928076669e = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"global_volume_accumulator" }>, align 1
@alloc_88ff191317cce9f7b6b39a8f0c3fa561 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"No cashback to claim" }>, align 1
@alloc_bf37dd379c0e1d7ac3ce7aa720e09afe = hidden unnamed_addr constant <{ [60 x i8] }> <{ [60 x i8] c"programs\\pump\\src\\token_incentives\\claim_token_incentives.rs" }>, align 1
@alloc_18fe676585cd3bfb2012b939f89d07ca = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"L\00\00\00" }>, align 4
@alloc_32a30decd3d0832fcf3c701785113c5a = hidden unnamed_addr constant <{ [39 x i8] }> <{ [39 x i8] c"Overflowing user accumulator sol volume" }>, align 1
@alloc_aa49c6ccda626ab96f39084410630cad = hidden unnamed_addr constant <{ [56 x i8] }> <{ [56 x i8] c"programs\\pump\\src\\token_incentives\\volume_accumulator.rs" }>, align 1
@alloc_b0b6cad3658f0428069f69142c5b3a76 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\005\00\00\00\0E\00\00\00" }>, align 8
@alloc_6aa4d93da8d894339d35e2c0d9ff8f34 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00N\00\00\00\11\00\00\00" }>, align 8
@alloc_f935f4ff6baf5a59f2fa75181b78404b = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"Unexpected overflow" }>, align 1
@alloc_1965cabbc44a9a62a6ef79eed31cbf0a = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00l\00\00\00\0E\00\00\00" }>, align 8
@alloc_45cd16e086cfddb91d65d38e3d7eba81 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\88\00\00\00\0E\00\00\00" }>, align 8
@alloc_47da0cfb3502a4393e8c215b679213c1 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Overflowing stable cashback earned" }>, align 1
@alloc_2495c7f34c284396de3bafc0adf95b98 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\AA\00\00\00\16\00\00\00" }>, align 8
@alloc_8bdce13327853e385db3209d3d74dfa0 = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"Overflowing cashback earned" }>, align 1
@alloc_81707c4fc570396b9e750fed39d05786 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\A4\00\00\00\16\00\00\00" }>, align 8
@alloc_6559cf62d25e79d1742781296dbf346d = hidden unnamed_addr constant <{ [41 x i8] }> <{ [41 x i8] c"Overflowing total stable cashback claimed" }>, align 1
@alloc_fb5de3b2d742110b1c7c5082c4f14bae = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\C0\00\00\00\16\00\00\00" }>, align 8
@alloc_7370a650efb80ceebb6c45fc5de588ef = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Overflowing total cashback claimed" }>, align 1
@alloc_2405c3d72a6f4cbd674f89d98bd5cb5d = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\BA\00\00\00\16\00\00\00" }>, align 8
@alloc_efe7c7396b0a465e396630206ed2add6 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"SVM is 64-bit" }>, align 1
@vtable.f = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17hfff795df28ddb366E", [16 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @"_ZN70_$LT$core..num..error..TryFromIntError$u20$as$u20$core..fmt..Debug$GT$3fmt17h19e859f4ad052900E" }>, align 8
@alloc_226f896d5496ca39c5ce9629e9eb79bb = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\B4\01\00\00\1C\00\00\00" }>, align 8
@alloc_6724397af0324d902fe86314f8ec0a77 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"$\00\00\00" }>, align 4
@alloc_db57ac4aa764b092fd3f0ffa615d4086 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00=\01\00\00\0D\00\00\00" }>, align 8
@alloc_b8f7a26b57feffa344ad6ab5eb421303 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"%\00\00\00" }>, align 4
@alloc_2ec257a4043401d558293e3b7e93ab56 = hidden unnamed_addr constant <{ [50 x i8] }> <{ [50 x i8] c"current_timestamp should be bigger than start_time" }>, align 1
@alloc_f5608682b95f2b20a611c7e0deeb16c0 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00K\01\00\00\0E\00\00\00" }>, align 8
@alloc_69fd96902d895a6751516321ec98d30c = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00Z\01\00\00\0D\00\00\00" }>, align 8
@alloc_bf568c21db5fedbd3d4e3979d76f50af = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"&\00\00\00" }>, align 4
@alloc_79109b7398cb7130a203c41a2aeca845 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\86\01\00\00\12\00\00\00" }>, align 8
@alloc_d54293b2202ec39da357064998ac4a9d = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\8D\01\00\00\11\00\00\00" }>, align 8
@alloc_7c62bcd8d3ebb5cb67b9b95221cc2ea5 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"#\00\00\00" }>, align 4
@alloc_346fb21e774d5ea1ce44010888712ad1 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\22\00\00\00" }>, align 4
@alloc_218ddb49fb9e35383b33476231e104b6 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00}\01\00\00\12\00\00\00" }>, align 8
@alloc_4ae6e9acb1b43c12e705a034dc5d8b63 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00x\01\00\00\12\00\00\00" }>, align 8
@alloc_66d9fd9949f01151d8406804091f09a7 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"!\00\00\00" }>, align 4
@alloc_5b66301ade9e29b84d934b21047ee8a3 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c" \00\00\00" }>, align 4
@alloc_04a3177051e518c6fbe28821180a6bc4 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\1F\00\00\00" }>, align 4
@alloc_da218557aa9923ff524085e43c2eed9f = hidden unnamed_addr constant <{ [41 x i8] }> <{ [41 x i8] c"end_time should be bigger than start_time" }>, align 1
@alloc_e4ad027ddaec008a8fc8078620cda2d3 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\A9\01\00\00\0E\00\00\00" }>, align 8
@alloc_f5c66c4cc3f121db8d1fd806c42443fb = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\AD\01\00\00+\00\00\00" }>, align 8
@alloc_d4e817fdb468408bde04ab9a3e8da949 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"Overflowing sol volume" }>, align 1
@alloc_1c3f022fdda315c0d940c0af04c4b53c = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\AF\01\00\00\0E\00\00\00" }>, align 8
@alloc_8936ea8c1f367d531a24c4c4f276dc72 = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"No changes in accumulator for user=" }>, align 1
@alloc_518ccbcc83e328b42baed59e4d3cd24f = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_8936ea8c1f367d531a24c4c4f276dc72, [8 x i8] c"#\00\00\00\00\00\00\00" }>, align 8
@alloc_232332a33e5bde24aaf9b2927e38f831 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"^\00\00\00" }>, align 4
@alloc_eb48ecb58154a62efa0821ef8f471327 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"programs\\pump\\src\\trade_v3.rs" }>, align 1
@alloc_ab3c76e753d2c8a1b6dd7e6114f34c72 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"programs\\pump\\src\\lib.rs" }>, align 1
@alloc_e5642880fbf4fd13c2267b30f522a5c1 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00\A2\05\00\00>\00\00\00" }>, align 8
@alloc_5d742fdd5578525ee3cd9f8935735b1f = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00\A3\05\00\00(\00\00\00" }>, align 8
@alloc_e807ec7c58f2029114b8c44cd0f17633 = hidden unnamed_addr constant <{ [42 x i8] }> <{ [42 x i8] c"programs\\pump\\src\\util\\constant_product.rs" }>, align 1
@alloc_851b1ebd397b789db44c0a710637b917 = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"programs\\pump\\src\\util\\transfer_fee.rs" }>, align 1
@alloc_0d00ce50d82536458393bb5dd06bdde4 = hidden unnamed_addr constant <{ [44 x i8] }> <{ [44 x i8] c"programs\\pump\\src\\admin_set_idl_authority.rs" }>, align 1
@alloc_756f143700e91e3b17005522f4adc978 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d00ce50d82536458393bb5dd06bdde4, [16 x i8] c",\00\00\00\00\00\00\00V\00\00\00\0D\00\00\00" }>, align 8
@alloc_c5d63e851ad5c7bd87c5704be3c0666b = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d00ce50d82536458393bb5dd06bdde4, [16 x i8] c",\00\00\00\00\00\00\00e\00\00\00-\00\00\00" }>, align 8
@alloc_40502334712e5a63ea0fd7eb9c6b3b89 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d00ce50d82536458393bb5dd06bdde4, [16 x i8] c",\00\00\00\00\00\00\00`\00\00\00%\00\00\00" }>, align 8
@alloc_a68ca997f481ac42c15ed3deab5fd046 = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"anchor:idl" }>, align 1
@alloc_9348a6d0135e4bb8777d851374adfb84 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"<\00\00\00" }>, align 4
@alloc_39d65a58a7655737c877038bc6e949bc = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"9\00\00\00" }>, align 4
@alloc_f05e12bcbc79b387ebe5395943702764 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c":\00\00\00" }>, align 4
@alloc_734f334906a1a2cd2d30c23afb39c35c = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c";\00\00\00" }>, align 4
@alloc_c53ee819a6028c03a31d0ed6681cb6a4 = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"buyback_fee never exceeds protocol_fee" }>, align 1
@alloc_c17f15cea547f19e22245a4388a86b11 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00\93\07\00\00\0E\00\00\00" }>, align 8
@alloc_32439d5d787bfd24f2fa4e3df982e7bc = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"buyback fee is at most protocol_fee" }>, align 1
@alloc_46369ee8c8b6a2abe980ba830351534a = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00\90\07\00\00-\00\00\00" }>, align 8
@alloc_7b7918e2b25837ebf5daa45836ead39b = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00\C5\05\00\00*\00\00\00" }>, align 8
@alloc_5e54cd686132e669245d25ecd4124951 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00\C6\05\00\00(\00\00\00" }>, align 8
@alloc_8fa6180967da64f9b75a655d2ffc0abf = hidden unnamed_addr constant <{ [6 x i8] }> <{ [6 x i8] c"global" }>, align 1
@alloc_80e21990e168f482083b4e34e5287dfd = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_8fa6180967da64f9b75a655d2ffc0abf, [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@alloc_78c2a69dc2703ce009e17497993c0ac9 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"fee_recipient" }>, align 1
@alloc_4faf804fb2882eb0bfbbbd9963da0333 = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"associated_quote_fee_recipient" }>, align 1
@alloc_9ad02455b8cb95a32fe17867ff8e5bca = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"buyback_fee_recipient" }>, align 1
@alloc_f11b4aca27c5553ed2925aec6372ecb9 = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"associated_quote_buyback_fee_recipient" }>, align 1
@alloc_3a5cf6ef726427bc208273bd8a6ed2d6 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"bonding_curve" }>, align 1
@alloc_ec7006489682c13806d8b5a4c5d33c9e = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"associated_base_bonding_curve" }>, align 1
@alloc_87e21227085c55c2b088855af56b8fc0 = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"associated_quote_bonding_curve" }>, align 1
@alloc_6fe715b96e5c8b1b977010fc2948a032 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"user" }>, align 1
@alloc_c13792d8dcec7b7781e60a811c441194 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"associated_base_user" }>, align 1
@alloc_f5d90a6456722c9afa3de68723848e2b = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"associated_quote_user" }>, align 1
@alloc_a01d4e5b90abb2e89ef109229f8e0f16 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"associated_creator_vault" }>, align 1
@alloc_7bc5412b5b13cfcd1bdd6c957b21843c = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"sharing-config" }>, align 1
@alloc_c1828caea07d8aebcd50922f0fe708da = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_19d5b7333c5961fcce9b62928076669e, [8 x i8] c"\19\00\00\00\00\00\00\00" }>, align 8
@alloc_843742b3afb9a7375ef225576f6963a8 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"associated_user_volume_accumulator" }>, align 1
@alloc_c1e304e9a8d353cfbaf9c87d366b999e = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"fee_config" }>, align 1
@alloc_2b84f75a3eda48bc9afffbbdc56b1c3b = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"event_authority" }>, align 1
@alloc_c2e1d2978ed073501bd9a4d7f3d4cd11 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"sharing_config" }>, align 1
@alloc_315189f9a8121a8721e89698f8df70f4 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"creator_vault" }>, align 1
@alloc_960a4fb5f9a1a40641dd1c9f38aedb18 = hidden unnamed_addr constant <{ [7 x i8] }> <{ [7 x i8] c"program" }>, align 1
@alloc_e5102a9c6553a4b6ef5a360cf53f9abe = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"system_program" }>, align 1
@alloc_85bff4dc1b8740f8e6389c783cbbf5df = hidden unnamed_addr constant <{ [11 x i8] }> <{ [11 x i8] c"fee_program" }>, align 1
@alloc_376f7abf283234c746a030214490a2ec = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"associated_token_program" }>, align 1
@alloc_ea201cb1e4d4674e824a504905794472 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"quote_token_program" }>, align 1
@alloc_885c26ce219de7421322e2501f17b1ff = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"base_token_program" }>, align 1
@alloc_178db84c1d7f8c4bb1609040b2486979 = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"quote_mint" }>, align 1
@alloc_f72125c53e1d5561e4060f172c87b071 = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"base_mint" }>, align 1
@alloc_5e0723b434b085f01ad85a13674fb9fd = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\05\10\00\00" }>, align 4
@alloc_14e89b0bb1b42bb36c5f54345f7b0935 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f8b9c94f4a1e21fc26594ad8880f6dcd, [16 x i8] c"\1E\00\00\00\00\00\00\00\1B\00\00\00\0A\00\00\00" }>, align 8
@alloc_37ecffd933ffb652389b18e544c3f62f = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"mint" }>, align 1
@alloc_c1a1428356069e529f436c63eeed1a3e = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"associated_bonding_curve" }>, align 1
@alloc_67eab08794078fe9b14146ec5716111a = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_d94ed8e97f85e9d4a928f6843960fd6f, [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
@alloc_a740e1ca2f18ea3c741dea1efc9ab68b = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"mayhem_program_id" }>, align 1
@alloc_8bd2e5f3cd99fbe1da27d6446eb6c37c = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\05*\E5\D7\A7\DA\A7$\A6\EA\B0\A7)T\91\85Z\D4\A0g\16`gLN\03EY\80=e\A3" }>, align 1
@alloc_2f70324af7aad172276d6f726156585c = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"global-params" }>, align 1
@alloc_598df843d11c614590d431708d9c4f68 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_2f70324af7aad172276d6f726156585c, [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@alloc_d2eb5d0379978132df1c005748f1deb4 = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"sol-vault" }>, align 1
@alloc_bc26518401955a2ba694e492f81b7311 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_d2eb5d0379978132df1c005748f1deb4, [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@alloc_23c6d29e3a0a145d67d21dad10d46235 = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"sol_vault" }>, align 1
@alloc_3721bad2a403fb12df2373801f1737eb = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"mayhem-state" }>, align 1
@alloc_ee9d540924febe03178adc3da63d60cc = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"mayhem_state" }>, align 1
@alloc_fc0594767f76ef89f8c64924813d6b4c = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"mayhem_token_vault" }>, align 1
@alloc_3e09fbb0f4715c652bf3dd5ac16ed0f3 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"global_params" }>, align 1
@alloc_c4a15a12ad91a42af21ea9db0e23cccf = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"mint_authority" }>, align 1
@alloc_51c41213910de2b05ae625f00e932b26 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"token_program" }>, align 1
@alloc_ed9c0bc09222151debf54253419027a3 = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"not implemented: " }>, align 1
@alloc_d0b750b5126d5b9ade00a9e7a453b5c7 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_ed9c0bc09222151debf54253419027a3, [8 x i8] c"\11\00\00\00\00\00\00\00" }>, align 8
@alloc_ac18a33c1c3147171cfe1341e26a24c9 = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"admin_set_creator_authority" }>, align 1
@alloc_979663b0d52a281afa93f3e38a5c4470 = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"current_creator_quote_token_account" }>, align 1
@alloc_211450da9c5e2cdfbece53519c808f36 = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"creator_vault_quote_token_account" }>, align 1
@alloc_4edcc48fa8674d860ce62562c39376a3 = hidden unnamed_addr constant <{ [40 x i8] }> <{ [40 x i8] c"holder_creator_vault_quote_token_account" }>, align 1
@alloc_4c413b46aced7d78986a36ce9cb5c74e = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"global_config" }>, align 1
@alloc_a90dcaad6adc6e51ece72128774cde87 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_4c413b46aced7d78986a36ce9cb5c74e, [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@alloc_1128b71b621fbc8ab75a72430f3ec9aa = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"coin_creator_vault_authority" }>, align 1
@alloc_af31ee817ceda77cb0e074a7f9ea1bb1 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"coin_creator_vault_ata" }>, align 1
@alloc_779b04ef1424a9d1c3ab8fe82745cabc = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"pump_fees_event_authority" }>, align 1
@alloc_f26ae80672ceb6129b17685be4d321f1 = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"pump_amm_event_authority" }>, align 1
@alloc_ada2550bfb18010c5242cbbe8c7d44b3 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"pool_authority" }>, align 1
@alloc_bd68949e6405349ddc7719ec9c408b92 = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"amm_global_config" }>, align 1
@alloc_d1bfc10779b041acc3a88415e9d02102 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"holder_creator_vault" }>, align 1
@alloc_5437c1e0e12127f1f43885c339fa43f7 = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"current_creator" }>, align 1
@alloc_5c25f94a51ef29b4c9247f6e51dbf71c = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"pump_fees" }>, align 1
@alloc_e06fd55f77e73d0fe91c5ad5e5b85017 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"pump_amm" }>, align 1
@alloc_0e13cc05f383884e34919cdb4040d640 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"creator_token_account" }>, align 1
@alloc_30423781447697ada6c1e57df713c1cf = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"creator_vault_token_account" }>, align 1
@alloc_184c99ab49e5c091a8b34e0ec96a1fba = hidden unnamed_addr constant <{ [7 x i8] }> <{ [7 x i8] c"creator" }>, align 1
@alloc_b1ac596e8ff006067cd135b0d8e5d94d = hidden unnamed_addr constant <{ [5 x i8] }> <{ [5 x i8] c"payer" }>, align 1
@alloc_c885f0aea1b3131eb243b64244feed17 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1af00ae4c528fb4548c2d6dac315a336, [16 x i8] c"4\00\00\00\00\00\00\00\D9\00\00\00\01\00\00\00" }>, align 8
@alloc_fd959a1a5e64bdaf2fbbeaa9acb60b54 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"holder_reward_claim_authority" }>, align 1
@alloc_2f26e92dca89bfbbaad1bbd3da57703c = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"holder_rewards" }>, align 1
@alloc_dc1378449e0c475e45f6035dcf8508d0 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"holder_rewards_token_account" }>, align 1
@alloc_670772c5db542b0dbf2f0a341c0a82f0 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"metadata" }>, align 1
@alloc_64778ebd1c4ba2d860767a8afa9ed465 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"set_creator_authority" }>, align 1
@alloc_2f0e65e7154da6c5ad36490067ea5bf5 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"aa\D7\90]\92\16|" }>, align 1
@alloc_eed9d66dfeab06be2758fb7b80f4df31 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"withdraw_authority" }>, align 1
@alloc_56363561c75c1e4884be38f4c0cd5a5d = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"pool_authority_mint_account" }>, align 1
@alloc_fb60bae47ae81f994bd609720c90b6f6 = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"pool_authority_wsol_account" }>, align 1
@alloc_9834c6a49b18be2bc638e712d496dc41 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"pool_lp_mint" }>, align 1
@anon.daed28ed302f5d790bec94e67e4a70fa.0 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\06\A7\D5\17\19,\\Q!\8C\C9L=J\F1\7FX\DA\EE\08\9B\A1\FDD\E3\DB\D9\8A\00\00\00\00" }>, align 1
@alloc_5d8a946c01cb7ae9a345e64bebf811d1 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"rent" }>, align 1
@alloc_14bcf537023ee882bca47ee8de60760e = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"pool_quote_token_account" }>, align 1
@alloc_f0567283544f7cbe3d6aa20016f32413 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"pool_base_token_account" }>, align 1
@alloc_4c0540ab205ec7570ac01d6e0f61b551 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"user_pool_token_account" }>, align 1
@alloc_48a2db28eae32c539980e190a6809a8f = hidden unnamed_addr constant <{ [7 x i8] }> <{ [7 x i8] c"lp_mint" }>, align 1
@alloc_cbafd482b615df9cf45224c6bfd7a3da = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"wsol_mint" }>, align 1
@alloc_d4d892a4a238770bb04189df8889743a = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"token_2022_program" }>, align 1
@alloc_108399c53e9d6fb8e0d19361b96aefd2 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"pool_authority_quote_account" }>, align 1
@alloc_2d1abda73e6150f56d5ce7d36aeb59ff = hidden unnamed_addr constant <{ [6 x i8] }> <{ [6 x i8] c"source" }>, align 1
@alloc_7af814e4f50490f029ada962b7242330 = hidden unnamed_addr constant <{ [11 x i8] }> <{ [11 x i8] c"destination" }>, align 1
@alloc_9090dfc8cb03169d783f46b5258c4758 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"pump_amm_global_config" }>, align 1
@alloc_be4aa7f5a1d312b5e0fe96af2b6e3cb9 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"source_authority" }>, align 1
@alloc_afa8c4a1e46506b21eb06f3f8b86d9a5 = hidden unnamed_addr constant <{ [59 x i8] }> <{ [59 x i8] c"programs\\pump\\src\\quote_control\\initialize_quote_control.rs" }>, align 1
@alloc_e0337e48e320dad8d93c6dc6fcc87011 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"quote_control" }>, align 1
@alloc_d434558afaf80e2f91130b7ce1e2f56c = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_74b629c72efcdc1614418b0c46630921, [16 x i8] c"(\00\00\00\00\00\00\00\10\00\00\00\01\00\00\00" }>, align 8
@alloc_f5d98d7464f97416447458a1ab6d33e2 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"QuoteControl" }>, align 1
@alloc_b7479d7c84902d514e780a3cdcafbda3 = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"authority" }>, align 1
@alloc_ab7015c5d571fdf48d4f8fcd82a9bebc = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"associated_user" }>, align 1
@alloc_b879a376be4a56bfd22d773cb11294e5 = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"recipient" }>, align 1
@alloc_55a8d3fe9d9924fe5ec7a6acad2d918b = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"associated_quote_recipient" }>, align 1
@alloc_aaa87ee3d06f724c4b787efb20ebfc8b = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"global_incentive_token_account" }>, align 1
@alloc_29cd35651195f77413373a455cfc5e1d = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\93\FAlx\F7\1DC\DE" }>, align 1
@alloc_ac9a74296ce473cc8bad4372269b6ebe = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"user_ata" }>, align 1
@alloc_e5cc8ca24ce1d71b7542ce0a359a1064 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"O\AC\F61\CD[\CE\E8" }>, align 1
@alloc_5b87bf9349cccbff0211ba026de02103 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E2\D6\F6!\07\F2\93\E5" }>, align 1
@alloc_3ec034106f3a654a9d388409477b87e7 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\08\00\00\00\01\00\00\00" }>, align 8
@alloc_15e2d784bf785b73d8e74e84842b9912 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"GlobalVolumeAccumulator" }>, align 1
@vtable.g = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN4core3fmt3num50_$LT$impl$u20$core..fmt..Debug$u20$for$u20$i64$GT$3fmt17h09fd8368c16afbbbE" }>, align 8
@vtable.h = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr42drop_in_place$LT$solana_pubkey..Pubkey$GT$17hda00edcff73cda79E", [16 x i8] c" \00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @"_ZN58_$LT$solana_pubkey..Pubkey$u20$as$u20$core..fmt..Debug$GT$3fmt17h45f9cee000b25b6cE" }>, align 8
@vtable.i = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\F0\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN4core5array69_$LT$impl$u20$core..fmt..Debug$u20$for$u20$$u5b$T$u3b$$u20$N$u5d$$GT$3fmt17h3b707ff253e65a4fE" }>, align 8
@vtable.j = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE", [16 x i8] c"\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17hc49c56ffa469469bE" }>, align 8
@alloc_55dcc4c5e01df15126adc45aaf6073b8 = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"start_time" }>, align 1
@alloc_6d5e77bd81fb0ab70f370a88da80338d = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"end_time" }>, align 1
@alloc_f9a57368c96fe7618a0dd70ce51581ca = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"seconds_in_a_day" }>, align 1
@alloc_af015f7f84e6c8fc579750f65dc482fe = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"total_token_supply" }>, align 1
@alloc_475e31f6fca4dfec55bec1209684a5bc = hidden unnamed_addr constant <{ [11 x i8] }> <{ [11 x i8] c"sol_volumes" }>, align 1
@alloc_1ff5c16505047f980865d6ae7f3ecd65 = hidden unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_55dcc4c5e01df15126adc45aaf6073b8, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @alloc_6d5e77bd81fb0ab70f370a88da80338d, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @alloc_f9a57368c96fe7618a0dd70ce51581ca, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @alloc_37ecffd933ffb652389b18e544c3f62f, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @alloc_af015f7f84e6c8fc579750f65dc482fe, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @alloc_475e31f6fca4dfec55bec1209684a5bc, [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@alloc_9e6b5afce03379e4c46fcbbea38d6881 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_aa49c6ccda626ab96f39084410630cad, [16 x i8] c"8\00\00\00\00\00\00\00\13\00\00\00\01\00\00\00" }>, align 8
@alloc_6bc5c12ac1e0f36b3a374a0cba4f3af0 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"UserVolumeAccumulator" }>, align 1
@alloc_c866c07f994284212be256c2bcfca9be = hidden unnamed_addr constant <{ [66 x i8] }> <{ [66 x i8] c"programs\\pump\\src\\token_incentives\\init_user_volume_accumulator.rs" }>, align 1
@alloc_6d58e7353221c5a543f78f53cead9580 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\C5z\A7|tQ[\FF" }>, align 1
@alloc_f5a854219b47b11bd7586727b8c2f260 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"program_signer" }>, align 1
@alloc_9557e3fb131e2393b8b6c953617c68b4 = hidden unnamed_addr constant <{ [11 x i8] }> <{ [11 x i8] c"idl_account" }>, align 1
@alloc_3b0a9124f1e83dcefdb3f6026b48ebbd = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"sol_vault_authority" }>, align 1
@_ZN14pump_recovered8pump_amm2ID17h75346fef4aa1fe5dE = hidden constant <{ [32 x i8] }> <{ [32 x i8] c"\0C\14\DE\FC\82^\C6v\94%\08\18\BBe@e\F4)\8D1V\D5q\B4\D4\F8\09\0C\18\E9\A8c" }>, align 1
@_ZN14pump_recovered8pump_amm4__ID17h25ee5892d76fd795E = hidden local_unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\0C\14\DE\FC\82^\C6v\94%\08\18\BBe@e\F4)\8D1V\D5q\B4\D4\F8\09\0C\18\E9\A8c" }>, align 1
@alloc_19f36cb6bd251cca1069c5c6ef09c23e = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00S\00\00\00\01\00\00\00" }>, align 8
@alloc_4ee083ca7f35c8f73f0b9aca2f1e1fc9 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"BondingCurve" }>, align 1
@alloc_4099ed5f46dd2a3a8ef227446cef9094 = hidden unnamed_addr constant <{ [9 x i8] }> <{ [9 x i8] c"FeeConfig" }>, align 1
@alloc_403cb52dfc6589b9caba4a9d8184659f = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\95\08\9C\CA\A0\FC\B0\D9" }>, align 1
@alloc_e084fa83af58649270d83fb6f7b39d3e = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"GlobalConfig" }>, align 1
@alloc_04fe3e69450d4b20ebb9b0486d63b7b0 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"Pool" }>, align 1
@alloc_ea83e9aa6191b8a93a13795ff61c49f3 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\D8J\09\008\8C]K" }>, align 1
@alloc_8522c5de5cc2b765022bf3f7852b8bef = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"SharingConfig" }>, align 1
@alloc_8049a97426515ff9d21ba7a630759b63 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"/#\A3\F9\96\9D\93z" }>, align 1
@alloc_a4e29de93f3ae09c9e303744275192f4 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"?E\1C\160\\\C2\B9" }>, align 1
@alloc_d6fc8faa9833a14f96863b286f2717b6 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"g\F4R\1F,\F5ww" }>, align 1
@alloc_5b9aa52e94d1b961a342a364d972fed0 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\92\9F\BD\AC\92X8\F4" }>, align 1
@alloc_c6f6638df3c45864b74de9507e5f6137 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\F5\C2\EE\EA\DA:Y" }>, align 1
@alloc_b7f7529a6168efd4432f23d854a11189 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"k4Y\817\E2Q\16" }>, align 1
@alloc_7533c51e020666675f9fab2dedd1cc5b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\B11\0C\D2\A0v\A7t" }>, align 1
@alloc_76c2242be5593646f11b3d0f65854fba = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"x\F8=S\1F\8Ek\90" }>, align 1
@alloc_86afda335beb0bf8374e95064cbe5e84 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"k\FD\C1L\E4\CA\1Bh" }>, align 1
@alloc_1190557d2c148ce466de481e8222f670 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\AE|J\F9\04Q\F6\11" }>, align 1
@alloc_58140e03d55b060128198852f5344076 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\86$\0DH\E8e\82\D8" }>, align 1
@alloc_c926dd37e16f3838cec29bd500a98a38 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\AA\DDR\C7\93\A5\F7." }>, align 1
@alloc_b9672b3d8916770c35ae035fc0df4a69 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"+\BC\FA\12\DDK\BB_" }>, align 1
@alloc_6aa6c45d7e7315b1a54faa57d1abe715 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c">/7\0A\A5\03\DC*" }>, align 1
@alloc_2040cbd4656c11be3b230e023521854d = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\F2\E7\EBfAc\BD\D3" }>, align 1
@alloc_e2b6300ff41b1a5ecd78fdf9a8139d45 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"Y\80\F0\8D[\CAGi" }>, align 1
@alloc_a660a225a516f02a64edaf37dccbffd9 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\96k\C7{|\CFf\E4" }>, align 1
@alloc_7b702ee005b8999276fd6d6915c2aac3 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\82\A4$a\E4\82\87\A5" }>, align 1
@alloc_566d06e72fd606967517a2f1ffa99e0c = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E1\98\ABW\F6?B\EA" }>, align 1
@alloc_f1b3ab50e5989091f64079b10cb3a772 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\98\C6||j\F6\7F\BF" }>, align 1
@alloc_6b1a00236117f4d637a4e24bbd9a621b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"Z\17A#>\F4\BC\D0" }>, align 1
@alloc_f48270acadf794fa55cee3e4063ee919 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\16\09\85\1A\A0,G\C0" }>, align 1
@alloc_1c4e1042f7f27ea7b170fa7201cba309 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\D1\0BsW\D5\17|\CC" }>, align 1
@alloc_e62a0a336584702b68f46361b68a8ed3 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"f\06=\12\01\DA\EB\EA" }>, align 1
@alloc_615d558dde7286d3844c09dca83d5460 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\C2\AB\1CFhM[/" }>, align 1
@alloc_8bf94a37cfd4fafca08ef7d451531fd0 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\B8\17\EEag\C5\D3=" }>, align 1
@alloc_dc368f406b2a4794f2b5e32e8a85fabc = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"%:#~\BE5\E4\C5" }>, align 1
@alloc_e4c63177903d73bc622a84b3916c31ac = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\10\04G\1C\CC\01(\1B" }>, align 1
@alloc_9847f1e0d08f792d29946241dda65fe8 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\F9E\A4\DA\96gT\8A" }>, align 1
@alloc_972ea8aa3342089b25226b9f788a9e8b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\EAf\C2\CB\96H>\E5" }>, align 1
@alloc_7eac1800e3f89407b76afcfa00c09a43 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"^\06\CAs\FF`\E8\B7" }>, align 1
@alloc_20f6fe07ed87d3841c871bbe10479b06 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"3\E6\85\A4\01\7F\83\AD" }>, align 1
@alloc_f34dbbb85942f6130217f61b03f7f664 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"]\F6\82<\E7\E9@\B2" }>, align 1
@alloc_bad0c047ef309b27a7ad1571ea25dbf2 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"o\AC\A2\E8rY\D5\8E" }>, align 1
@alloc_3cbd21392c25662e88589d017b555eaf = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c" \F6\BF4\08\C9I\BA" }>, align 1
@alloc_926ae3e1fb7242d236c40cfe6ea05bb2 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\080\BE\07\B6D\B7\E5" }>, align 1
@alloc_90173967d35fa997a779ca8053d0cf56 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"V\1F\C0W\A3WO\EE" }>, align 1
@alloc_4b21d798263f261583021d60559b2b1e = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"sg\E0\FF\BDYV\C3" }>, align 1
@alloc_c4aa74c3cb6616d6a11cdcffe8181208 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\01\09o\D0d\1F\FF\A3" }>, align 1
@alloc_20606274b8832b828b7e5daefb40a342 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\FB\E0\AB\92\A0\1Aq\E9" }>, align 1
@alloc_6ae59c6e82ab61f8baa978b29d580285 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"=\AF\A0\F9BB\88\AF" }>, align 1
@_ZN14pump_recovered9pump_fees2ID17ha1c56025ced5965bE = hidden local_unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\0C5\FF\A9\05Z\8EV\8D\A8\F7\BC\07V\15'L\F1\C9,\A4\1F@\00\9CQj\A4\14\C2|p" }>, align 1
@_ZN14pump_recovered9pump_fees4__ID17h0034efd954ea125aE = hidden local_unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"\0C5\FF\A9\05Z\8EV\8D\A8\F7\BC\07V\15'L\F1\C9,\A4\1F@\00\9CQj\A4\14\C2|p" }>, align 1
@alloc_661245e69d780d91ff98aa1a7faaf964 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00T\00\00\00\01\00\00\00" }>, align 8
@alloc_2ab211bee05517b1d0c1ecd0501464e8 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\99\A6G\90\B3\BD\89\FB" }>, align 1
@alloc_d710a3e2c2ebc86dba8c866b1301eca1 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"BuybackVault" }>, align 1
@alloc_22c6f07e7fdc74b59930202dc3580828 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\F6\C5`\09\C1\1E]s" }>, align 1
@alloc_b4a7ff8318508135122115f78618a50b = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"DonationFeePda" }>, align 1
@alloc_e1274acb74cf9135abc0efddc427cc1e = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\A2\A5\F51\1D%7\F2" }>, align 1
@alloc_617155e22042c5a616595858b6356d48 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"FeeProgramGlobal" }>, align 1
@alloc_8abd1fcc798e597ab292f1862062add8 = hidden unnamed_addr constant <{ [6 x i8] }> <{ [6 x i8] c"Global" }>, align 1
@alloc_c414c8fabf73fe27d6d0949bd750873e = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\8B`5\11*\A9\CE\96" }>, align 1
@alloc_21e7229899bcd31de6873ec6d58d32f2 = hidden unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"SocialFeePda" }>, align 1
@alloc_cbc6a352c58e6b237a7a57ce28258cb4 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\85i\AA\C8\B8t\FBX" }>, align 1
@alloc_628282e0507d9741438123e5708183a7 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\1E\D0k]\B1\00\DFN" }>, align 1
@alloc_5053fd9b165fa64117ace57aa8e347e6 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"^\14\89\EF#M\E1\EB" }>, align 1
@alloc_42be03912e2a7c6cd1f26bb32376f94b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E2\CB\E0#\99\0AX3" }>, align 1
@alloc_a7eee849bbec8961a3a61fabcfbc04f4 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"Y\8A\F4\E6\0A8\E2~" }>, align 1
@alloc_04223535c0710c122d1605b6a55e65d4 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"(\E9\9CN_\00\08\C7" }>, align 1
@alloc_93d01720a91f727a01e366bdfc01a1e3 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\CB\CC\97\E2x7\D6\F3" }>, align 1
@alloc_2c39dad9714cda1594a6579fcee4899b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\12\AF\84B\D0\C9W\F2" }>, align 1
@alloc_47eca7c31377c2f8234c4ca25c018dc5 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\8F\8F\EB\B5\133(" }>, align 1
@alloc_f6ef4f04866f35580fdc3578ffc17be4 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\05\08\B3A17\91~" }>, align 1
@alloc_ff792f58563fb2d9003e8b70cc23ba4e = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\C3\8Al\0F\08MD\09" }>, align 1
@alloc_96d2e112e2cc254b597fae4e0b7dd03a = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"<v\7F\84\EF4\FE\0E" }>, align 1
@alloc_ad31cbf8d57c530e0fbfd3a8183c81c6 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"2\12\C1A\ED\D2\EA\EC" }>, align 1
@alloc_8d4f2e384831496546d1bc39a071471e = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\B7\B7\DA\93\18|\89\A9" }>, align 1
@alloc_55a57e99c7d5848e82572629a95bcf58 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"+8*\D6\999\A6\89" }>, align 1
@alloc_1389313137b0bff82adc417a1f1c6673 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\15\BA\C4\B8[\E4\E1\CB" }>, align 1
@alloc_1be6ed86fee05eacfb54b09381309ed4 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"^\05+\EDg\93\E8\F5" }>, align 1
@alloc_90bdae3dac2640881b38c77ea3398bdd = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\ABY\A9\BBz\BA!\CC" }>, align 1
@alloc_44911953e7f28c188e64df9e2d24470e = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\ED\ED4b\92I\F3" }>, align 1
@_ZN14pump_recovered2ID17h35b1dab65cd91d3eE = hidden constant <{ [32 x i8] }> <{ [32 x i8] c"\01V\E0\F6\93fZ\CFD\DB\15h\BF\17[\AAQ\89\CB\97\F5\D2\FF;e]+\B6\FDm\18\B0" }>, align 1
@alloc_1f514165fed49695f5434c0eb511f939 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\AF\AFm\1F\0D\98\9B\ED" }>, align 1
@alloc_7aeaa72e78299b7f078679a5806dd977 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E3\B5J\C4\D0\15a\D5" }>, align 1
@alloc_0e101259211b1ed143f2b4580802ecf6 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\1C\FF\E6\F0\ACk\CB\AB" }>, align 1
@alloc_202cf0a7e035927571e89a6ca2ee7a67 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E1\FCB\04\C7#\EC\10" }>, align 1
@alloc_5c3c5f8b37da0e70ac45d20d053ba9b3 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c" \9A\98\DB\8El\DA\A5" }>, align 1
@alloc_0658209239ce0a50a8f59962a8c42e06 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"oy\158(\18^\D1" }>, align 1
@alloc_ec62c932425743f120ffee46978c9ada = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\B1A\DF&X\D1\9E\9B" }>, align 1
@alloc_77c843298b6cc710109f23157c9cd5cf = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"e\87\BFh\09X\14`" }>, align 1
@alloc_863da18463f018989db100b95ba461c7 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\1B\EA\B24\93\02\BB\8D" }>, align 1
@alloc_fcc5748896d9ff485cbbc8c8037a7701 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"=\A9\BC\BF\99\95*a" }>, align 1
@alloc_c359201bef75213a12a4e34df2532fd6 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\18\1E\C8(\05\1C\07w" }>, align 1
@alloc_2c892a2f0ba35c1349e20138b7617b03 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\D6\90L\EC_\8B1\B4" }>, align 1
@alloc_37f5701b3997fd84de6dd95de6dc4c51 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\07\05\1D\C4\F5\17eP" }>, align 1
@alloc_26f7ab274faddcf1fc0fbb0389efdf7b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E1\F7P\1E\D5\B3\84\88" }>, align 1
@alloc_e984ea73ed4f52fcd9dc7772b554ed42 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\1C\92\DEw&\C4i\D5" }>, align 1
@alloc_dd25ca79dfe72a3dcaa455d5cfba2e87 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\E1\9Au\16\D7V\F6g" }>, align 1
@alloc_70c2790dd334d37a68a579324a6a7d82 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"8\FCt\08\9E\DF\CD_" }>, align 1
@alloc_e66e64434f922ace51062f9ae86e1c3b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\9B\EA\E7\92\EC\9E\A2\1E" }>, align 1
@alloc_a17cac7d44e93b3111c59d4c4d1a4b18 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\BB\CB\12\1F\CE\ED\FE)" }>, align 1
@alloc_eae239175d5d98581a256689a1cc2297 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\14\16V{\C6\1C\DB\84" }>, align 1
@alloc_397ee3cbcac1b5a50257bd5aa1157621 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\CF\11\8A\F2\04\22\138" }>, align 1
@alloc_b54a7839e0448f765d197f3144202fa8 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"b6\91a\02F\AD+" }>, align 1
@alloc_92e4534edfd0557cd9e53811f8764ce6 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\8A`\AE\D90U\C5\F6" }>, align 1
@alloc_17a55b4b38948a05269aec2f4a92879b = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\94\FFp\CF\8E\AA\A5" }>, align 1
@alloc_7cc43d4c700e160b2b326aa8829bedd3 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"}~\D6\86M\E5\BCY" }>, align 1
@alloc_e3473bed851b84a6e3210c403dc15c3f = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"z\F3\CCA^t\1D7" }>, align 1
@alloc_4fc059528729c78d861391080a2eab45 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\08\D9`\E7\90h\C0\05" }>, align 1
@alloc_363bce73bf22a4630b9f9be4b1caf0b9 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"W|4\BF4&\D6\E8" }>, align 1
@alloc_8cbf60769c05ae568b06807165147cac = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"u\E1\7F\CA\86_D#" }>, align 1
@alloc_bd047dbaa82b4e9d7487d4b40f048414 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\A5rg\00y\CE\F7Q" }>, align 1
@alloc_d16c8b9145963e57f947f6c0ee395670 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\CB\13O\F4D\08\9F" }>, align 1
@alloc_b73f5683e306f38e710e6eeab56c3050 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\EFI\F5\AD\D1\B1TB" }>, align 1
@alloc_f8f8fb546488519828c31dd4741db918 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c">O\A1\D3\A5\AA\D6\D2" }>, align 1
@alloc_898d837d1a1fd45e49a8316ece4c280d = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\02\0E=\8A\AA\8E\0E_" }>, align 1
@alloc_b909dce9aae9f7c9991af4ebd54b8a2d = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\DF\07\FD\1AQ\A5\DA\A6" }>, align 1
@alloc_6084c68db62fbe5b6119811f9cef6ccb = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"\A1\C3\DE\A5\E1e\C0>" }>, align 1
@alloc_2b1966425c221858932e562da5d1a84e = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"t\DCkS\BF, I" }>, align 1
@alloc_62b919ed0bfd61e344af769280285f39 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"@\F4\BCx\A7\E9i\0A" }>, align 1
@alloc_2f129049fd906dc414872be793ac408f = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00Z\00\00\00\01\00\00\00" }>, align 8
@vtable.k = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr55drop_in_place$LT$solana_program_error..ProgramError$GT$17h71466a9929f872e5E", [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN71_$LT$solana_program_error..ProgramError$u20$as$u20$core..fmt..Debug$GT$3fmt17he5da34f9213c2408E" }>, align 8
@alloc_4de323e28158503a2a257aa634b15cac = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"Instruction: IdlCreateAccount" }>, align 1
@vtable.l = hidden unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @"_ZN4core3ptr42drop_in_place$LT$solana_pubkey..Pubkey$GT$17hda00edcff73cda79E", [16 x i8] c"\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @"_ZN63_$LT$solana_pubkey..PubkeyError$u20$as$u20$core..fmt..Debug$GT$3fmt17h51eee67aafad0389E" }>, align 8
@alloc_7dabd0de5ab674438b26397fd295f180 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"Instruction: IdlResizeAccount" }>, align 1
@alloc_f0c6a657e1e5fb3c28862460ba842e4b = hidden unnamed_addr constant <{ [54 x i8] }> <{ [54 x i8] c"data_len should always be >= the current account space" }>, align 1
@alloc_23f0ea81f54e403d3da407b68396aa1b = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Instruction: IdlCloseAccount" }>, align 1
@alloc_50e1e449df690ed55dfeae0ac2e5b952 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Instruction: IdlCreateBuffer" }>, align 1
@alloc_1630d18ef5accce314cce0481ae59a8c = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"Instruction: IdlWrite" }>, align 1
@alloc_a67c87e61662f61ebcaaa063538aee76 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\C5\09\00\00" }>, align 4
@alloc_2237634e94624c7ca87956b6bed5dae5 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Instruction: IdlSetAuthority" }>, align 1
@alloc_987d9c6dfa98dec9db93cfc8f4e06901 = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"Instruction: IdlSetBuffer" }>, align 1
@alloc_976814ac43dc68d27df92a4503232bf4 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\CA\09\00\00" }>, align 4
@alloc_a613efeff25f0128fa2b7774b39cbbf0 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"Instruction: Initialize" }>, align 1
@alloc_b82beac74a9e6ca2336a6fd018af1624 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Instruction: UpdateGlobalAuthority" }>, align 1
@alloc_2d184c1e5614e3968a48a3a81468c249 = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"Instruction: ToggleCreateV2" }>, align 1
@alloc_d3a3a5b2f3b992949f0fbbb2285960df = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Instruction: ToggleCashbackEnabled" }>, align 1
@alloc_e50cca1057d07492237c9ab1d1232bd5 = hidden unnamed_addr constant <{ [37 x i8] }> <{ [37 x i8] c"Instruction: UpdateHolderRewardConfig" }>, align 1
@alloc_16526bf1ccedc9443a0f0d007e760a79 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"Instruction: SetMaxCurveDepth" }>, align 1
@alloc_910a060b0bec74419eae0eb6c892a6d9 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"Instruction: ToggleMayhemMode" }>, align 1
@alloc_20b3be751f232dbf51f3bc0d29ebd9a0 = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"Instruction: UpdateCreatorFeeConfig" }>, align 1
@alloc_96c69483f260228bc8ee7316c26a4f4e = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"Instruction: AddQuoteMint" }>, align 1
@alloc_e7a1264658569b12e9b769144b550e8c = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Instruction: RemoveQuoteMint" }>, align 1
@alloc_9f1e8fb923b60c945f982d52c442609d = hidden unnamed_addr constant <{ [36 x i8] }> <{ [36 x i8] c"Instruction: SetVirtualQuoteReserves" }>, align 1
@alloc_cc52fd145556c297e31200c7724f7f3e = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"Instruction: SetParams" }>, align 1
@alloc_95af52d57d9087283bea0e28d562bbad = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"Instruction: SetMayhemVirtualParams" }>, align 1
@alloc_5f2b7d81763b62d03ff6fc52f3866f0c = hidden unnamed_addr constant <{ [37 x i8] }> <{ [37 x i8] c"Instruction: SetReservedFeeRecipients" }>, align 1
@alloc_3d2f00b10f3731d57c107690d48fcebe = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"Instruction: Create" }>, align 1
@alloc_ea46c229c730077b464a67b2d340afb6 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"Instruction: CreateV2" }>, align 1
@alloc_0913d9b1343e76d9b0a9444ff0bec7f7 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"Instruction: BuyV2" }>, align 1
@alloc_5b05c7dac92983e7df9facb95a075af6 = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"Instruction: BuyExactQuoteInV2" }>, align 1
@alloc_adfe7973e07412f024057c0e6a1de379 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"Instruction: SellV2" }>, align 1
@alloc_90441552b655b1df13d88399c2b0be5d = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"Instruction: BuyV3" }>, align 1
@alloc_1a1cb93e46eeb7a4c565d41be350a1cb = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"Instruction: BuyExactQuoteInV3" }>, align 1
@alloc_7bfed06368b85d5643a56b52142f4111 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"Instruction: SellV3" }>, align 1
@alloc_fd541588aa2e7279ce60b1d0b8c6e3ce = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"Instruction: MultiHopCurveSwap" }>, align 1
@alloc_f15f833ccc75dd6a63d66ecf0a98ec0e = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"Instruction: SweepProtocolFee" }>, align 1
@alloc_b344ab3400696c49eb4e854abdcaad7a = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Instruction: SweepCreatorFee" }>, align 1
@alloc_8263a05550180ae2b9ca24a968c9eb1f = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"Instruction: Buy" }>, align 1
@alloc_0f780137aaefe59c8d4a9b1d5349a93f = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"Instruction: BuyExactSolIn" }>, align 1
@alloc_e68282052735995202ec849739a650fa = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"Instruction: Sell" }>, align 1
@alloc_7e276bf92d5a665325a562b61870b598 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"Instruction: Migrate" }>, align 1
@alloc_ce5904d6a7643af3675e8ed14a110101 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"Instruction: MigrateV2" }>, align 1
@alloc_1be63126171d875a2f43d1e046dd7ce5 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"Instruction: ExtendAccount" }>, align 1
@alloc_036100237e66ea91137aef698cfbf1e9 = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"Instruction: CollectCreatorFee" }>, align 1
@alloc_58afd6355909bf1d60eb4de7b8c60c7a = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"Instruction: CollectCreatorFeeV2" }>, align 1
@alloc_45b612a7ebf09a3618d811a54c500df5 = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"Instruction: DistributeFeeToHolders" }>, align 1
@alloc_02c7185c22b65fd90f38a1d105908499 = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"Instruction: SetMetaplexCreator" }>, align 1
@alloc_6274248b3f4d12c87c9843b45b975728 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"Instruction: SetCreator" }>, align 1
@alloc_77c3a7e8c6a77140d272d4b877438ec7 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"Instruction: AdminCto" }>, align 1
@alloc_657dcf5f516aaceb755fa984dcce52e0 = hidden unnamed_addr constant <{ [39 x i8] }> <{ [39 x i8] c"Instruction: AdminUpdateTokenIncentives" }>, align 1
@alloc_58cf497455d926cbd9319c936975aa7e = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"Instruction: ClaimTokenIncentives" }>, align 1
@alloc_180064c361bb542dc017a2e849cdac51 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"Instruction: ClaimCashback" }>, align 1
@alloc_7afd8b54ee3a6218ebb090746c93479b = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Instruction: ClaimCashbackV2" }>, align 1
@alloc_a8d6c995d2f035c0aa5caa043b67553c = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"Instruction: InitUserVolumeAccumulator" }>, align 1
@alloc_731d12a62b8c297f098a23621be5cc2a = hidden unnamed_addr constant <{ [39 x i8] }> <{ [39 x i8] c"Instruction: CloseUserVolumeAccumulator" }>, align 1
@alloc_7c2798ef6576bb4bc4fd2eb4c968f989 = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"Instruction: SyncUserVolumeAccumulator" }>, align 1
@alloc_864930dabcbff1e21ead9d70d6852776 = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"Instruction: AdminSetIdlAuthority" }>, align 1
@alloc_c3230ee4692a6ab7f59884d06206d73f = hidden unnamed_addr constant <{ [39 x i8] }> <{ [39 x i8] c"Instruction: MigrateBondingCurveCreator" }>, align 1
@alloc_8e110a1721f259321d1e57103b8d933e = hidden unnamed_addr constant <{ [39 x i8] }> <{ [39 x i8] c"Instruction: GetMinimumDistributableFee" }>, align 1
@alloc_dfa4b02f1a1e535210ed86ba08e77652 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Instruction: DistributeCreatorFees" }>, align 1
@alloc_b0fcf64c20b81ad71800770f55784f56 = hidden unnamed_addr constant <{ [36 x i8] }> <{ [36 x i8] c"Instruction: DistributeCreatorFeesV2" }>, align 1
@alloc_f2d0166413621a0a8e3f90310535a02f = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"Instruction: UpdateBuybackConfig" }>, align 1
@alloc_a7f463d26cf9439751b72cd0709dd32a = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"Instruction: InitializeQuoteControl" }>, align 1
@alloc_7d0a03c85305aa8f638e964eceaaa713 = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"Instruction: SetQuoteControlAdmin" }>, align 1
@alloc_78a5b717a5495ad05d8415b0a59c73de = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"Instruction: AddQuoteControlMint" }>, align 1
@alloc_5775f528bff43ae2382a53798bd996f5 = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"Instruction: RemoveQuoteControlMint" }>, align 1
@alloc_ac98a1d2a793b659d0b0398352908c6d = hidden unnamed_addr constant <{ [41 x i8] }> <{ [41 x i8] c"Instruction: SetQuoteControlReservesAdmin" }>, align 1
@alloc_5c70b561f927ccfbd839dffa33fb8325 = hidden unnamed_addr constant <{ [40 x i8] }> <{ [40 x i8] c"Instruction: SetQuoteControlMintReserves" }>, align 1
@alloc_edf70a21e030ef4d3fdc345a7ebf6f1d = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\0D\00\00\00" }>, align 4
@alloc_438824954e55cae3acf8e16ddc1ac045 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 4
@alloc_1f9f655bb258fbf03b8025fb52140895 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\0E\00\00\00" }>, align 4
@alloc_63738555cfef41d17c63452561b7eb27 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\0C\00\00\00" }>, align 4
@alloc_1fc27fdd32498c20ebb48dddbe733cf8 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"\0B\00\00\00" }>, align 4
@alloc_b99730e73100e73a81f4fbfe74b3821d = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr inttoptr (i64 1 to ptr), [8 x i8] zeroinitializer }>, align 8
@alloc_7d913719491f8dc9fc738d995649021e = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"NotAuthorized" }>, align 1
@alloc_0d3be0d14102033b846c31847450ef5d = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"AlreadyInitialized" }>, align 1
@alloc_1a92e60875d18472f82a1a7ae2b1295c = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"TooMuchSolRequired" }>, align 1
@alloc_497f6c7cc61b0472f27c1af37a3984b9 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"TooLittleSolReceived" }>, align 1
@alloc_f8313f40dd58ba46f8ff39154dc2fb33 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"MintDoesNotMatchBondingCurve" }>, align 1
@alloc_38484e5f7d049d78edccc58f4caa346c = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"BondingCurveComplete" }>, align 1
@alloc_355ae2392fa42c445e09f25b4a157e96 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"BondingCurveNotComplete" }>, align 1
@alloc_be63cba0c27178ed53f30361a6efb87b = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"NotInitialized" }>, align 1
@alloc_362fef9010b95e8e8be4a470d6f6ba96 = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"WithdrawTooFrequent" }>, align 1
@alloc_9be9ea867a77e8e91cfba76aeb05217d = hidden unnamed_addr constant <{ [37 x i8] }> <{ [37 x i8] c"NewSizeShouldBeGreaterThanCurrentSize" }>, align 1
@alloc_8fbeeebb2e18a75490685588ec6174c9 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"AccountTypeNotSupported" }>, align 1
@alloc_cd3fc188dd796f1ca768ad283342f9a3 = hidden unnamed_addr constant <{ [56 x i8] }> <{ [56 x i8] c"InitialRealTokenReservesShouldBeLessThanTokenTotalSupply" }>, align 1
@alloc_45155c077d883a611ef86df8205e0f18 = hidden unnamed_addr constant <{ [70 x i8] }> <{ [70 x i8] c"InitialVirtualTokenReservesShouldBeGreaterThanInitialRealTokenReserves" }>, align 1
@alloc_0b3c36826a474b0eaf7b75ac0af0a93e = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"FeeBasisPointsGreaterThanMaximum" }>, align 1
@alloc_b2cf0c575ce9528decaa48823daef2bb = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"AllZerosWithdrawAuthority" }>, align 1
@alloc_63aa5ca0bba3c29e1cab94073bd91d7e = hidden unnamed_addr constant <{ [52 x i8] }> <{ [52 x i8] c"PoolMigrationFeeShouldBeLessThanFinalRealSolReserves" }>, align 1
@alloc_d884dfcb2c9bd0e43a7f463efc725d0a = hidden unnamed_addr constant <{ [63 x i8] }> <{ [63 x i8] c"PoolMigrationFeeShouldBeGreaterThanCreatorFeePlusMaxMigrateFees" }>, align 1
@alloc_9b9a0d06bdc6bedc7df1f11953627a41 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"DisabledWithdraw" }>, align 1
@alloc_454813238ff29d61b2492a55ac5a48ec = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"DisabledMigrate" }>, align 1
@alloc_b7a3244e6b0e383dbb0cf104442ea454 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"InvalidCreator" }>, align 1
@alloc_99c801cdf8deb71118ed914774c6d793 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"BuyZeroAmount" }>, align 1
@alloc_75a28115665eaf50ae8225c92631ff93 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"NotEnoughTokensToBuy" }>, align 1
@alloc_539711c2bafbf8db661706507cee3c81 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"SellZeroAmount" }>, align 1
@alloc_090cd7a18314a80fc10ad3092a151ae5 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"NotEnoughTokensToSell" }>, align 1
@alloc_8eb7fae8d4a03730c5f6e57ce31b7fe0 = hidden unnamed_addr constant <{ [8 x i8] }> <{ [8 x i8] c"Overflow" }>, align 1
@alloc_cad8d538009c73616855ae9edbe314d9 = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"Truncation" }>, align 1
@alloc_17b807b0bddf6d3b33a5a20f87ab13e7 = hidden unnamed_addr constant <{ [14 x i8] }> <{ [14 x i8] c"DivisionByZero" }>, align 1
@alloc_aa27b33091727e49affebfda33cc39a5 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"NotEnoughRemainingAccounts" }>, align 1
@alloc_9e4f73e0948cd8bc648c2f1c744640b6 = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"AllFeeRecipientsShouldBeNonZero" }>, align 1
@alloc_9b74a8459d9470cf0b3c3f2247dd9f9c = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"UnsortedNotUniqueFeeRecipients" }>, align 1
@alloc_23f1b29aa886f63b7a62a346209d1927 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"CreatorShouldNotBeZero" }>, align 1
@alloc_b03b3be32e9403bddccfd68e2af73307 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"StartTimeInThePast" }>, align 1
@alloc_d0fd7b8ee7ffe56671547d9ea8f21974 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"EndTimeInThePast" }>, align 1
@alloc_effc48f7a6efe1a266421a0729bef263 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"EndTimeBeforeStartTime" }>, align 1
@alloc_5b5dd863f39ddd35d3f80ba60b07c60f = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"TimeRangeTooLarge" }>, align 1
@alloc_50a47d28fbea2ee62db3a79d71a4af86 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"EndTimeBeforeCurrentDay" }>, align 1
@alloc_f30bb0bae4e2c41c5b97234a1da0e7ee = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"SupplyUpdateForFinishedRange" }>, align 1
@alloc_cb1b00223e7441f2c5d9ecc81132c694 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"DayIndexAfterEndIndex" }>, align 1
@alloc_b06038730d431df595f34b372a2c79f9 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"DayInActiveRange" }>, align 1
@alloc_1482c8173aec630f1ada72377b011cad = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"InvalidIncentiveMint" }>, align 1
@alloc_2e53f0bd8aa852b42224b77342dbe616 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"BuyNotEnoughSolToCoverRent" }>, align 1
@alloc_13755b6ec839eca662f51a2a746cf11f = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"BuyNotEnoughSolToCoverFees" }>, align 1
@alloc_a2c2029e0d772c3ad53d31229a4911e3 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"BuySlippageBelowMinTokensOut" }>, align 1
@alloc_6540289270511c0784d18181ace14d56 = hidden unnamed_addr constant <{ [11 x i8] }> <{ [11 x i8] c"NameTooLong" }>, align 1
@alloc_945cfcb8bcc10e71a26036bc83c93c74 = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"SymbolTooLong" }>, align 1
@alloc_5dc6d576856bebfca72c6101695d5f0e = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"UriTooLong" }>, align 1
@alloc_ae89fd7de1b45d19ec168ec549ce6b6d = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"CreateV2Disabled" }>, align 1
@alloc_2d036f0b111f09b2b506a49abe62876c = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"CpitializeMayhemFailed" }>, align 1
@alloc_d64750d7729f606f269d35fdfb88fc9a = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"MayhemModeDisabled" }>, align 1
@alloc_9bca31c91721b43bdbd26bbe5e7a752b = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"CreatorMigratedToSharingConfig" }>, align 1
@alloc_49a00fa4c876b57877e7a354d0efaa61 = hidden unnamed_addr constant <{ [53 x i8] }> <{ [53 x i8] c"UnableToDistributeCreatorVaultMigratedToSharingConfig" }>, align 1
@alloc_24f0bd991b900fe1af9dbf0a188a9a8b = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"SharingConfigNotActive" }>, align 1
@alloc_7b7ab138a53c0f22e84c8b0b62f8e902 = hidden unnamed_addr constant <{ [50 x i8] }> <{ [50 x i8] c"UnableToDistributeCreatorFeesToExecutableRecipient" }>, align 1
@alloc_fe70ff9eab2b4bfad3499a7bd060499f = hidden unnamed_addr constant <{ [43 x i8] }> <{ [43 x i8] c"BondingCurveAndSharingConfigCreatorMismatch" }>, align 1
@alloc_3ccb7251522fb2528f30aa0b6157f31e = hidden unnamed_addr constant <{ [40 x i8] }> <{ [40 x i8] c"ShareholdersAndRemainingAccountsMismatch" }>, align 1
@alloc_5e1fc407cf652770b428e3740c07ca7c = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"InvalidShareBps" }>, align 1
@alloc_2ba37ed29afbf57835cfd73c106e2b28 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"CashbackNotEnabled" }>, align 1
@alloc_cc003f67302507f4dce288d631672881 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"BuybackFeeRecipientNotAuthorized" }>, align 1
@alloc_83349fee255176303a5e9dfaa4e718b7 = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"AllBuybackFeeRecipientsShouldBeNonZero" }>, align 1
@alloc_d72f674593af9c402fdb8ea0abba0829 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"NotUniqueBuybackFeeRecipients" }>, align 1
@alloc_73dd6df4fefbdcc0963c2ed3c6d9a11c = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"BuybackBasisPointsOutOfRange" }>, align 1
@alloc_ce2d9aafe9a8142ffc6ba284f1c0cb18 = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"WrongBuybackFeeRecipientsCount" }>, align 1
@alloc_3c895098443a76e9ab88afbe1e19b91c = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"BuybackFeeRecipientMissing" }>, align 1
@alloc_bf4c8d0ea0aefb08f4efe588e4456825 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"UnsupportedQuoteMint" }>, align 1
@alloc_415e3e22189992a3a5ed68ea1f65faab = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"InvalidQuoteTokenProgram" }>, align 1
@alloc_6346d56b41700c9f0dc22af9290988d6 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"InvalidAssociatedQuoteBondingCurve" }>, align 1
@alloc_89cebcf2ae623fc743ff2f2d71a702c7 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"QuoteMintWhitelistFull" }>, align 1
@alloc_26c938d6284e8427a9189a0c89b5ecfb = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"QuoteMintAlreadyWhitelisted" }>, align 1
@alloc_a5bb6185b96707420c88e491f0dd26bd = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"QuoteMintNotWhitelisted" }>, align 1
@alloc_ae0f3f0a93f90ce3c503a2c322d1bce6 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"QuoteMintNotEligibleForWhitelist" }>, align 1
@alloc_dea35d56dc3ae6571c811e84da1e8f33 = hidden unnamed_addr constant <{ [51 x i8] }> <{ [51 x i8] c"UnableToDistributeCreatorFeesToUninitializedAccount" }>, align 1
@alloc_6e2c7a90dea9d39224bea9d9fd7ee233 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"MayhemModeQuoteMintNotAllowed" }>, align 1
@alloc_3d2ec7106a533c9797af0acc304701ef = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"MissingCashbackAccounts" }>, align 1
@alloc_7be73de7057997ff2317f5fac1bbcd25 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"InvalidCashbackAccumulator" }>, align 1
@alloc_746af9e49a6ff3e385aff6339691bcba = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"InvalidBondingCurveV2" }>, align 1
@alloc_2eb9ac306cef9e320c573ab86c10ad8c = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"InvalidQuoteControl" }>, align 1
@alloc_6b49620b430d5a30ebf1de39952244be = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"InvalidCashbackRecipient" }>, align 1
@alloc_9f9a6f316fa41e8820588322787c994e = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"CreatorFeeNotConfigurable" }>, align 1
@alloc_9a499984e9604a4d8e2d09b68d51a141 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"CreatorFeeBpsOutOfRange" }>, align 1
@alloc_969da5a193ef6e63b9bfd3734283aaf6 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"CreatorFeeNotEditable" }>, align 1
@alloc_04ba4e3bac2a0de66f3e26af82f02066 = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"CreatorFeeNotAllowedForCashbackCoin" }>, align 1
@alloc_0b746011e8205701184d45a5f0aa4180 = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"BondingCurveAlreadyMigrated" }>, align 1
@alloc_6174df9cb434b6dbdff9fa7a7b7c83d6 = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"CashbackDeprecated" }>, align 1
@alloc_f0b632f135af271ea14c5f97ec6aca2c = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"HolderRewardCreatorImmutable" }>, align 1
@alloc_72d3b61c8281366fad8f12d31807e52a = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"HolderRewardDisabled" }>, align 1
@alloc_d2f5fb6c585e78c9b5628c50dbfe460c = hidden unnamed_addr constant <{ [30 x i8] }> <{ [30 x i8] c"HolderRewardRecipientsMismatch" }>, align 1
@alloc_f41133abb25a6e841c8f764e07455a42 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"HolderRewardsRentFloor" }>, align 1
@alloc_05aa3d34ed6f9d5b071b10a25cf17eb4 = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"HolderRewardTokenAccountMissing" }>, align 1
@alloc_5eeeb3d5907a794978ca8e54a20f40cb = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"CtoNotAllowedForMayhemCoin" }>, align 1
@alloc_bc1acdefe97c29dbe8a5e3ef535082b0 = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"CtoNewCreatorRequired" }>, align 1
@alloc_363c5a84ac9df2e7f4feada1a4fed8d8 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"CtoNewCreatorNotAllowed" }>, align 1
@alloc_6ec04866097dab42bdb735f606890819 = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"CreatorFeeNotConfigurableForQuote" }>, align 1
@alloc_2448d6f345dae512103834c7fa33b07d = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"CtoCreatorAccountNotWritable" }>, align 1
@alloc_36e8d19bb3e5e43ab3fb40bf02e749a6 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"CtoSharedVaultFrozen" }>, align 1
@alloc_06b5430fbd2b8dd2a24a64ad210460da = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"CashbackCoinNotSupported" }>, align 1
@alloc_2175cc39173b3b527bc58aa207dc154e = hidden unnamed_addr constant <{ [19 x i8] }> <{ [19 x i8] c"CreatorFeesNotSwept" }>, align 1
@alloc_94f8e78c3d114a36ba95424cb73c158a = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"FeeTiersEmpty" }>, align 1
@alloc_8cbb48d78e879f69160d0944518bfb90 = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"FeeConfigTooShort" }>, align 1
@alloc_58f3b6f66877905952a71318efb82185 = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"MultiHopDiscontinuousPath" }>, align 1
@alloc_e68bce591d5e2c656f50e9988ea8144a = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"InvalidQuoteBondingCurve" }>, align 1
@alloc_7a40a3076cb24ceda1eeea4d7b7073d7 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"QuoteBondingCurveNotEligible" }>, align 1
@alloc_6d3467541cfdde2e8f4158ab79a1017c = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"QuotePoolAccountsRequired" }>, align 1
@alloc_befb6275329f4687758586107dec3b8f = hidden unnamed_addr constant <{ [17 x i8] }> <{ [17 x i8] c"QuotePoolNotFound" }>, align 1
@alloc_42a72ff5375a28436d2615b90df54281 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"InvalidQuotePool" }>, align 1
@alloc_9622ef7f890cb89e61c1daa09652e220 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"QuoteReservesOutOfRange" }>, align 1
@alloc_a8fcaa33c23918101ce92a3bad5c828e = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"CurveDepthExceeded" }>, align 1
@alloc_d7979e07fc429f24cc2585bd6a8a503f = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"MultiHopHopFeesMismatch" }>, align 1
@alloc_7a5396ac37fc97920570b20d32791595 = hidden unnamed_addr constant <{ [27 x i8] }> <{ [27 x i8] c"QuoteCurveAwaitingMigration" }>, align 1
@alloc_4b6a193f683ce9587057e36af3d4226d = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"MultiHopMayhemCurveNotSupported" }>, align 1
@alloc_73c3a2223d3c5abd0cea9a890d7c9c72 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"QuoteChainAccountsRequired" }>, align 1
@alloc_a857c81e8657cfa5f1ef42c25c056215 = hidden unnamed_addr constant <{ [20 x i8] }> <{ [20 x i8] c"QuoteMintNotWritable" }>, align 1
@alloc_efabff539c620c392744e091a5a2e471 = hidden unnamed_addr constant <{ [64 x i8] }> <{ [64 x i8] c"The given account is not authorized to execute this instruction." }>, align 1
@alloc_7f8cdd0af8d62134138d062ab544efe0 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_efabff539c620c392744e091a5a2e471, [8 x i8] c"@\00\00\00\00\00\00\00" }>, align 8
@alloc_ae8597933d985d1c879b7b871ea2f0cb = hidden unnamed_addr constant <{ [35 x i8] }> <{ [35 x i8] c"The program is already initialized." }>, align 1
@alloc_aceacadb344bb4eb1ba2a3a8695bed54 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_ae8597933d985d1c879b7b871ea2f0cb, [8 x i8] c"#\00\00\00\00\00\00\00" }>, align 8
@alloc_241c13b72a362c28caec39993ad55f2d = hidden unnamed_addr constant <{ [66 x i8] }> <{ [66 x i8] c"slippage: Too much SOL required to buy the given amount of tokens." }>, align 1
@alloc_bfcd11ae899205fb512db8eafc169c49 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_241c13b72a362c28caec39993ad55f2d, [8 x i8] c"B\00\00\00\00\00\00\00" }>, align 8
@alloc_91374f9e0db32fb7bcbbdc6a7a3ac5c5 = hidden unnamed_addr constant <{ [69 x i8] }> <{ [69 x i8] c"slippage: Too little SOL received to sell the given amount of tokens." }>, align 1
@alloc_2480c166b05e0bbdb8183f439f45e62d = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_91374f9e0db32fb7bcbbdc6a7a3ac5c5, [8 x i8] c"E\00\00\00\00\00\00\00" }>, align 8
@alloc_eb8a624c48886c0c004f9f71188973eb = hidden unnamed_addr constant <{ [42 x i8] }> <{ [42 x i8] c"The mint does not match the bonding curve." }>, align 1
@alloc_2b821fc0eedf84688585f21b0ff4b0dc = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_eb8a624c48886c0c004f9f71188973eb, [8 x i8] c"*\00\00\00\00\00\00\00" }>, align 8
@alloc_83dee1867d68ca58a94c154ce8117162 = hidden unnamed_addr constant <{ [66 x i8] }> <{ [66 x i8] c"The bonding curve has completed and liquidity migrated to raydium." }>, align 1
@alloc_930988c1caa60b25c3da0575c036a9ba = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_83dee1867d68ca58a94c154ce8117162, [8 x i8] c"B\00\00\00\00\00\00\00" }>, align 8
@alloc_c85e0b358f1348c990fac36b761e42ce = hidden unnamed_addr constant <{ [36 x i8] }> <{ [36 x i8] c"The bonding curve has not completed." }>, align 1
@alloc_9989c34b19bb17486517de99dd36d6a8 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_c85e0b358f1348c990fac36b761e42ce, [8 x i8] c"$\00\00\00\00\00\00\00" }>, align 8
@alloc_1fd138b1ebdd8c37a1165e92b23dc25f = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"The program is not initialized." }>, align 1
@alloc_a950d7618cda01ce7fb53ef22874d790 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_1fd138b1ebdd8c37a1165e92b23dc25f, [8 x i8] c"\1F\00\00\00\00\00\00\00" }>, align 8
@alloc_1c3f6c5fc58177434494334c1095128b = hidden unnamed_addr constant <{ [21 x i8] }> <{ [21 x i8] c"Withdraw too frequent" }>, align 1
@alloc_3e3b201f1e6788a064b49861aa64105f = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_1c3f6c5fc58177434494334c1095128b, [8 x i8] c"\15\00\00\00\00\00\00\00" }>, align 8
@alloc_5d4688e6f2fec6197225e8fb29bee02d = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"new_size should be > current_size" }>, align 1
@alloc_da102bb6ecbc5e652e06e581bed4853a = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5d4688e6f2fec6197225e8fb29bee02d, [8 x i8] c"!\00\00\00\00\00\00\00" }>, align 8
@alloc_c14174e5256d304423be5e2866db19bc = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"Account type not supported" }>, align 1
@alloc_08c3d46a29b66c0b75170129c13ce14b = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_c14174e5256d304423be5e2866db19bc, [8 x i8] c"\1A\00\00\00\00\00\00\00" }>, align 8
@alloc_6613b923b346d16550d2262f4a553df7 = hidden unnamed_addr constant <{ [66 x i8] }> <{ [66 x i8] c"initial_real_token_reserves should be less than token_total_supply" }>, align 1
@alloc_5abf773a455a004a62d715633f43e7e2 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_6613b923b346d16550d2262f4a553df7, [8 x i8] c"B\00\00\00\00\00\00\00" }>, align 8
@alloc_209688a608c64efebbdbd7b9c2ef8cde = hidden unnamed_addr constant <{ [81 x i8] }> <{ [81 x i8] c"initial_virtual_token_reserves should be greater than initial_real_token_reserves" }>, align 1
@alloc_2f0a46d875d00cf90b545bfab2c9f5de = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_209688a608c64efebbdbd7b9c2ef8cde, [8 x i8] c"Q\00\00\00\00\00\00\00" }>, align 8
@alloc_f30bc3da29654bf74f6276ba30be59ac = hidden unnamed_addr constant <{ [37 x i8] }> <{ [37 x i8] c"fee_basis_points greater than maximum" }>, align 1
@alloc_d6b45bb27856e66fd8565eb8dc2404d4 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_f30bc3da29654bf74f6276ba30be59ac, [8 x i8] c"%\00\00\00\00\00\00\00" }>, align 8
@alloc_8da42b8beed61da5d5c9f4fbbe734dba = hidden unnamed_addr constant <{ [53 x i8] }> <{ [53 x i8] c"Withdraw authority cannot be set to System Program ID" }>, align 1
@alloc_8888a86e06cf63b6c743ffbdea2280f4 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_8da42b8beed61da5d5c9f4fbbe734dba, [8 x i8] c"5\00\00\00\00\00\00\00" }>, align 8
@alloc_fd2388f3c895ceae01c0eeddf47b7037 = hidden unnamed_addr constant <{ [62 x i8] }> <{ [62 x i8] c"pool_migration_fee should be less than final_real_sol_reserves" }>, align 1
@alloc_c39f217ab8ce3e3b26bbc4c860fa3495 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_fd2388f3c895ceae01c0eeddf47b7037, [8 x i8] c">\00\00\00\00\00\00\00" }>, align 8
@alloc_31c435cd75abe6dd42ee94437d6bed6f = hidden unnamed_addr constant <{ [72 x i8] }> <{ [72 x i8] c"pool_migration_fee should be greater than creator_fee + MAX_MIGRATE_FEES" }>, align 1
@alloc_5290e26fd0584e717c2d29f23554981c = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_31c435cd75abe6dd42ee94437d6bed6f, [8 x i8] c"H\00\00\00\00\00\00\00" }>, align 8
@alloc_9553bef5185e41bbcb42315951d042c0 = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"Migrate instruction is disabled" }>, align 1
@alloc_66faa97eb21fe43b853b70759e5d055a = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_9553bef5185e41bbcb42315951d042c0, [8 x i8] c"\1F\00\00\00\00\00\00\00" }>, align 8
@alloc_d9300ab2bd81a3777782e9ab2a80b244 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"Invalid creator pubkey" }>, align 1
@alloc_b465272f98fdb9e5e19e5dfcf72b5792 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_d9300ab2bd81a3777782e9ab2a80b244, [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@alloc_5f0ebaceaa6bb9dcf3cff0066e9c999e = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"Buy zero amount" }>, align 1
@alloc_3c65974d22656582fa87a4aac065bdc7 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5f0ebaceaa6bb9dcf3cff0066e9c999e, [8 x i8] c"\0F\00\00\00\00\00\00\00" }>, align 8
@alloc_a8ac9d469a03b78bdf04e0013f7ec11e = hidden unnamed_addr constant <{ [24 x i8] }> <{ [24 x i8] c"Not enough tokens to buy" }>, align 1
@alloc_e2e76fa386c9088736220ef51fb902d4 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_a8ac9d469a03b78bdf04e0013f7ec11e, [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
@alloc_25382384f9cd53516d1c29c75a4fc041 = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"Sell zero amount" }>, align 1
@alloc_134155a0e1313dacb7d2c7a387318670 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_25382384f9cd53516d1c29c75a4fc041, [8 x i8] c"\10\00\00\00\00\00\00\00" }>, align 8
@alloc_2df59d2dc38b85305ea1e7a841b9e64f = hidden unnamed_addr constant <{ [25 x i8] }> <{ [25 x i8] c"Not enough tokens to sell" }>, align 1
@alloc_50e821a20e8ce6339d620372eb5bc52e = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_2df59d2dc38b85305ea1e7a841b9e64f, [8 x i8] c"\19\00\00\00\00\00\00\00" }>, align 8
@alloc_c8c56330031b44758a55d80c017827b7 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_8eb7fae8d4a03730c5f6e57ce31b7fe0, [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@alloc_7b24442cb9b83fa8672e80bc3c752050 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_cad8d538009c73616855ae9edbe314d9, [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@alloc_36712b18fa80a356639965f9856729fb = hidden unnamed_addr constant <{ [16 x i8] }> <{ [16 x i8] c"Division by zero" }>, align 1
@alloc_11f18d146ec29467a54c4eb63fe941c7 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_36712b18fa80a356639965f9856729fb, [8 x i8] c"\10\00\00\00\00\00\00\00" }>, align 8
@alloc_fbcf6cd02a57e0aa153676e0b8d24494 = hidden unnamed_addr constant <{ [29 x i8] }> <{ [29 x i8] c"Not enough remaining accounts" }>, align 1
@alloc_5ed8e8c723f347450e8052cfda70720c = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_fbcf6cd02a57e0aa153676e0b8d24494, [8 x i8] c"\1D\00\00\00\00\00\00\00" }>, align 8
@alloc_80325b4bbd3d78aaf2f6d4d13259a3fc = hidden unnamed_addr constant <{ [37 x i8] }> <{ [37 x i8] c"All fee recipients should be non-zero" }>, align 1
@alloc_af1293e94d8ff1e639d6c52b53b90e33 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_80325b4bbd3d78aaf2f6d4d13259a3fc, [8 x i8] c"%\00\00\00\00\00\00\00" }>, align 8
@alloc_419b82c0de9c9fe07541fe53fcf67003 = hidden unnamed_addr constant <{ [37 x i8] }> <{ [37 x i8] c"Unsorted or not unique fee recipients" }>, align 1
@alloc_be0e505c7643e17fa3f7b337bdd0ca09 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_419b82c0de9c9fe07541fe53fcf67003, [8 x i8] c"%\00\00\00\00\00\00\00" }>, align 8
@alloc_5e2640a54c27cecd636b5c30530405f9 = hidden unnamed_addr constant <{ [26 x i8] }> <{ [26 x i8] c"Creator should not be zero" }>, align 1
@alloc_933dc0d1fa50fc7d6c80ee607fb09437 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5e2640a54c27cecd636b5c30530405f9, [8 x i8] c"\1A\00\00\00\00\00\00\00" }>, align 8
@alloc_4df84b24a6a6a1d3734fae98d2dd4634 = hidden unnamed_addr constant <{ [48 x i8] }> <{ [48 x i8] c"Buy: Not enough SOL to cover for rent exemption." }>, align 1
@alloc_e410a9d7ee79dce43e6a596c07594290 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_4df84b24a6a6a1d3734fae98d2dd4634, [8 x i8] c"0\00\00\00\00\00\00\00" }>, align 8
@alloc_3c1abd284c5d20b6670c854e407d5814 = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"Buy: Not enough SOL to cover for fees." }>, align 1
@alloc_4a7bda998a0b974dc7276b59917e9d6a = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_3c1abd284c5d20b6670c854e407d5814, [8 x i8] c"&\00\00\00\00\00\00\00" }>, align 8
@alloc_698c717cf9b840bdfd0b9f7b768b059d = hidden unnamed_addr constant <{ [60 x i8] }> <{ [60 x i8] c"Slippage: Would buy less tokens than expected min_tokens_out" }>, align 1
@alloc_c4ce8d6766eaee550651fda4f2d63d43 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_698c717cf9b840bdfd0b9f7b768b059d, [8 x i8] c"<\00\00\00\00\00\00\00" }>, align 8
@alloc_fd9a7f6811ddbd9e3948c0ca996596d8 = hidden unnamed_addr constant <{ [43 x i8] }> <{ [43 x i8] c"creator has been migrated to sharing config" }>, align 1
@alloc_8e416c5a3d3df5ba73105947fccdf5f1 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_fd9a7f6811ddbd9e3948c0ca996596d8, [8 x i8] c"+\00\00\00\00\00\00\00" }>, align 8
@alloc_4d127517c0a43964a1138822f11c69b1 = hidden unnamed_addr constant <{ [91 x i8] }> <{ [91 x i8] c"creator_vault has been migrated to sharing config, use pump:distribute_creator_fees instead" }>, align 1
@alloc_a3ce1c1aefbfcea11671bc0bfb2aead1 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_4d127517c0a43964a1138822f11c69b1, [8 x i8] c"[\00\00\00\00\00\00\00" }>, align 8
@alloc_49b1ec5af23f77aec5f7056be5e06cf2 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Sharing config is not active" }>, align 1
@alloc_89e4e7efe72e08c66579888e704da539 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_49b1ec5af23f77aec5f7056be5e06cf2, [8 x i8] c"\1C\00\00\00\00\00\00\00" }>, align 8
@alloc_5db679724878183fc437a1ac80b0be60 = hidden unnamed_addr constant <{ [97 x i8] }> <{ [97 x i8] c"The recipient account is executable, so it cannot receive lamports, remove it from the team first" }>, align 1
@alloc_04824fe246a6c3a50405ec90f7ed62e4 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5db679724878183fc437a1ac80b0be60, [8 x i8] c"a\00\00\00\00\00\00\00" }>, align 8
@alloc_7460bd8af1ec9c01864dac7a04e36e72 = hidden unnamed_addr constant <{ [51 x i8] }> <{ [51 x i8] c"Bonding curve creator does not match sharing config" }>, align 1
@alloc_35dd2aca028c5540614b4234b71a707c = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_7460bd8af1ec9c01864dac7a04e36e72, [8 x i8] c"3\00\00\00\00\00\00\00" }>, align 8
@alloc_b4e2809825e457c2f677ed45a196ef2b = hidden unnamed_addr constant <{ [106 x i8] }> <{ [106 x i8] c"Remaining accounts do not match shareholders, make sure to pass exactly the same pubkeys in the same order" }>, align 1
@alloc_36decbfb8bb77558bf90d4e312ba0407 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_b4e2809825e457c2f677ed45a196ef2b, [8 x i8] c"j\00\00\00\00\00\00\00" }>, align 8
@alloc_77f529d2499e62c01b0bbfb6c0f24311 = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"Share bps must be greater than 0" }>, align 1
@alloc_40a15d85bd0ad8ae9f8d66842314b8eb = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_77f529d2499e62c01b0bbfb6c0f24311, [8 x i8] c" \00\00\00\00\00\00\00" }>, align 8
@alloc_9b5e373f067e63042e0cbd55501b2c07 = hidden unnamed_addr constant <{ [23 x i8] }> <{ [23 x i8] c"Cashback is not enabled" }>, align 1
@alloc_c6fcd07c2aa14d418e46554382952633 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_9b5e373f067e63042e0cbd55501b2c07, [8 x i8] c"\17\00\00\00\00\00\00\00" }>, align 8
@alloc_0f03a39c1094b5e51ad8c571785e2e86 = hidden unnamed_addr constant <{ [36 x i8] }> <{ [36 x i8] c"Buyback fee recipient not authorized" }>, align 1
@alloc_2612f9500abdbe5fe141d0547ddd307f = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_0f03a39c1094b5e51ad8c571785e2e86, [8 x i8] c"$\00\00\00\00\00\00\00" }>, align 8
@alloc_4298c61b79bbffd65d80a00a9fda721f = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"buyback_basis_points must be <= 10_000" }>, align 1
@alloc_ead9346710f6e46eeac3cad829515cfc = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_4298c61b79bbffd65d80a00a9fda721f, [8 x i8] c"&\00\00\00\00\00\00\00" }>, align 8
@alloc_4dcd33573a119775c90e7d98bbb65b8d = hidden unnamed_addr constant <{ [69 x i8] }> <{ [69 x i8] c"buyback fee recipients require exactly 8 remaining accounts (or none)" }>, align 1
@alloc_6a02aa68ecab4123746e2f61039d7a5f = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_4dcd33573a119775c90e7d98bbb65b8d, [8 x i8] c"E\00\00\00\00\00\00\00" }>, align 8
@alloc_e707f4906f60fb87d10b2e99a43124c1 = hidden unnamed_addr constant <{ [22 x i8] }> <{ [22 x i8] c"Unsupported quote mint" }>, align 1
@alloc_f562e8a04ac659a6a30c0610ee4ea989 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_e707f4906f60fb87d10b2e99a43124c1, [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@alloc_904ea87b0de84fb7b697c4af84986da8 = hidden unnamed_addr constant <{ [62 x i8] }> <{ [62 x i8] c"Create v2: quote token program must be SPL Token or Token-2022" }>, align 1
@alloc_dcdd6b199a1921dc1639dedfb1b1e285 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_904ea87b0de84fb7b697c4af84986da8, [8 x i8] c">\00\00\00\00\00\00\00" }>, align 8
@alloc_e386ddb335ffba3fdd2b5eaf3c031ddf = hidden unnamed_addr constant <{ [75 x i8] }> <{ [75 x i8] c"Create v2: associated quote bonding curve address does not match derivation" }>, align 1
@alloc_07b29e25802f79649aea5ac2ba6b5815 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_e386ddb335ffba3fdd2b5eaf3c031ddf, [8 x i8] c"K\00\00\00\00\00\00\00" }>, align 8
@alloc_a839c036a1613e30c5bd3c113ce28017 = hidden unnamed_addr constant <{ [28 x i8] }> <{ [28 x i8] c"Quote mint whitelist is full" }>, align 1
@alloc_e1a6533aca1f108aa49a1b6eac60e81b = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_a839c036a1613e30c5bd3c113ce28017, [8 x i8] c"\1C\00\00\00\00\00\00\00" }>, align 8
@alloc_59007adc1a888dd3bda1cc130f57d54e = hidden unnamed_addr constant <{ [33 x i8] }> <{ [33 x i8] c"Quote mint is already whitelisted" }>, align 1
@alloc_9d5f42a6a27471e6f6320709962c453e = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_59007adc1a888dd3bda1cc130f57d54e, [8 x i8] c"!\00\00\00\00\00\00\00" }>, align 8
@alloc_039a0bb5bc76da3f3d6249333d9b21d8 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Quote mint is not in the whitelist" }>, align 1
@alloc_fe74516802114ce29d37055a6476f36a = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_039a0bb5bc76da3f3d6249333d9b21d8, [8 x i8] c"\22\00\00\00\00\00\00\00" }>, align 8
@alloc_5d9ffa2678c39c6b7092c233bec47d6d = hidden unnamed_addr constant <{ [80 x i8] }> <{ [80 x i8] c"Quote mint cannot be added or removed via whitelist (default or native SOL mint)" }>, align 1
@alloc_d22dd49f4003838abada5eec133badda = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5d9ffa2678c39c6b7092c233bec47d6d, [8 x i8] c"P\00\00\00\00\00\00\00" }>, align 8
@alloc_439bf1cbc7e400bb62aa17f6e748a0b6 = hidden unnamed_addr constant <{ [58 x i8] }> <{ [58 x i8] c"Unable to distribute creator fees to uninitialized account" }>, align 1
@alloc_46f4de6ce0234dffb3daf7f29c5bc31c = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_439bf1cbc7e400bb62aa17f6e748a0b6, [8 x i8] c":\00\00\00\00\00\00\00" }>, align 8
@alloc_4b5f10899390eefffc87e67044421bf5 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Mayhem mode quote mint not allowed" }>, align 1
@alloc_05d4a6ba4356be553023d734dc17b1cb = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_4b5f10899390eefffc87e67044421bf5, [8 x i8] c"\22\00\00\00\00\00\00\00" }>, align 8
@alloc_1d99d78bc4763b8ed6cbf22aa5de0470 = hidden unnamed_addr constant <{ [57 x i8] }> <{ [57 x i8] c"Cashback trade is missing the required remaining accounts" }>, align 1
@alloc_0f924df479cf884af8b7377d2f0d7605 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_1d99d78bc4763b8ed6cbf22aa5de0470, [8 x i8] c"9\00\00\00\00\00\00\00" }>, align 8
@alloc_330b11fcd3030427e070aed665535ce3 = hidden unnamed_addr constant <{ [51 x i8] }> <{ [51 x i8] c"Cashback user_volume_accumulator account is invalid" }>, align 1
@alloc_a091f70fecb76175af8a352ab86a2c1a = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_330b11fcd3030427e070aed665535ce3, [8 x i8] c"3\00\00\00\00\00\00\00" }>, align 8
@alloc_bac6ea8ff85e3537f422ff9a8eb837da = hidden unnamed_addr constant <{ [56 x i8] }> <{ [56 x i8] c"bonding_curve_v2 remaining account is missing or invalid" }>, align 1
@alloc_c8c45dbd4b930fd86b9ce581edae6ee6 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_bac6ea8ff85e3537f422ff9a8eb837da, [8 x i8] c"8\00\00\00\00\00\00\00" }>, align 8
@alloc_2aed99feb6cbf5fe1f9391076315c952 = hidden unnamed_addr constant <{ [77 x i8] }> <{ [77 x i8] c"quote_control remaining account does not match derivation or is uninitialized" }>, align 1
@alloc_95ce20ce92c7463b28d515396d2452ea = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_2aed99feb6cbf5fe1f9391076315c952, [8 x i8] c"M\00\00\00\00\00\00\00" }>, align 8
@alloc_b03d6f1e78f01a65c62c5491b07a89dc = hidden unnamed_addr constant <{ [53 x i8] }> <{ [53 x i8] c"Cashback recipient token account is not owned by user" }>, align 1
@alloc_1656333d89d682a4fbdc39e922eb73d8 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_b03d6f1e78f01a65c62c5491b07a89dc, [8 x i8] c"5\00\00\00\00\00\00\00" }>, align 8
@alloc_38130e5ff7f9baefe5780d3726598d8e = hidden unnamed_addr constant <{ [38 x i8] }> <{ [38 x i8] c"Configurable creator fees are disabled" }>, align 1
@alloc_b91f6a858a2ffab348672f2ae798b682 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_38130e5ff7f9baefe5780d3726598d8e, [8 x i8] c"&\00\00\00\00\00\00\00" }>, align 8
@alloc_5c80e67d2b69ddc3d806e8faa381cd13 = hidden unnamed_addr constant <{ [69 x i8] }> <{ [69 x i8] c"Creator fee basis points must be between 1 and the configured maximum" }>, align 1
@alloc_759717e3c2a5618be963959e240ed9b1 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5c80e67d2b69ddc3d806e8faa381cd13, [8 x i8] c"E\00\00\00\00\00\00\00" }>, align 8
@alloc_be291d6805f92d229f8a0a193775fd03 = hidden unnamed_addr constant <{ [50 x i8] }> <{ [50 x i8] c"Creator fee is not editable for this bonding curve" }>, align 1
@alloc_ad9fb49f5ca3c180f55efa31e0f18265 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_be291d6805f92d229f8a0a193775fd03, [8 x i8] c"2\00\00\00\00\00\00\00" }>, align 8
@alloc_d9127b8d8c364560fa8aeef4bc35399d = hidden unnamed_addr constant <{ [52 x i8] }> <{ [52 x i8] c"Creator fee cannot be configured for a cashback coin" }>, align 1
@alloc_281b637a34608672ab77a19c4bf724af = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_d9127b8d8c364560fa8aeef4bc35399d, [8 x i8] c"4\00\00\00\00\00\00\00" }>, align 8
@alloc_617e7042b1aaab035a71d62ee49b0b47 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"Bonding curve has already migrated" }>, align 1
@alloc_ef3587a73e1d485f3e6b38f274699bed = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_617e7042b1aaab035a71d62ee49b0b47, [8 x i8] c"\22\00\00\00\00\00\00\00" }>, align 8
@alloc_4f144701ff006fbf7df9f9c45b1fd6fa = hidden unnamed_addr constant <{ [39 x i8] }> <{ [39 x i8] c"Cashback coins can no longer be created" }>, align 1
@alloc_b8e8b75ed5d152caad16b630af9c4dcd = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_4f144701ff006fbf7df9f9c45b1fd6fa, [8 x i8] c"'\00\00\00\00\00\00\00" }>, align 8
@alloc_5a04fca40300e880d435b12aeef60e76 = hidden unnamed_addr constant <{ [53 x i8] }> <{ [53 x i8] c"The creator of a holder-reward coin cannot be changed" }>, align 1
@alloc_2260b157a6d47e0eee5594cd4fbe9f71 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5a04fca40300e880d435b12aeef60e76, [8 x i8] c"5\00\00\00\00\00\00\00" }>, align 8
@alloc_7817295578eac2ca8de7ba1d5bf8db8a = hidden unnamed_addr constant <{ [32 x i8] }> <{ [32 x i8] c"Holder-reward coins are disabled" }>, align 1
@alloc_818999ae358e991a503114e2e620b30b = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_7817295578eac2ca8de7ba1d5bf8db8a, [8 x i8] c" \00\00\00\00\00\00\00" }>, align 8
@alloc_35401fcaeebc05513ea1e8a8458e5308 = hidden unnamed_addr constant <{ [57 x i8] }> <{ [57 x i8] c"Holder-reward amounts and recipient accounts do not match" }>, align 1
@alloc_f4bab0a4e91229c74cb13816a394eccf = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_35401fcaeebc05513ea1e8a8458e5308, [8 x i8] c"9\00\00\00\00\00\00\00" }>, align 8
@alloc_917135a5955327ad377d4118d8778af8 = hidden unnamed_addr constant <{ [67 x i8] }> <{ [67 x i8] c"The holder-rewards PDA cannot be left below its rent-exempt minimum" }>, align 1
@alloc_b13d517665e7c507eed36f1be7a95400 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_917135a5955327ad377d4118d8778af8, [8 x i8] c"C\00\00\00\00\00\00\00" }>, align 8
@alloc_b262286451a9fd275258c3857e5382bc = hidden unnamed_addr constant <{ [59 x i8] }> <{ [59 x i8] c"A holder-rewards token account is required on a token quote" }>, align 1
@alloc_166a6e77716ec43469908688350356bf = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_b262286451a9fd275258c3857e5382bc, [8 x i8] c";\00\00\00\00\00\00\00" }>, align 8
@alloc_3277e357e1c363cb24af38dcf3b6162d = hidden unnamed_addr constant <{ [40 x i8] }> <{ [40 x i8] c"CTO is not allowed on a mayhem-mode coin" }>, align 1
@alloc_9bfd160374787ddcf9d55be37d0b3bc7 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_3277e357e1c363cb24af38dcf3b6162d, [8 x i8] c"(\00\00\00\00\00\00\00" }>, align 8
@alloc_836c7c39a1a9e00aaa42b66753628395 = hidden unnamed_addr constant <{ [59 x i8] }> <{ [59 x i8] c"new_creator is required unless converting to holder rewards" }>, align 1
@alloc_8ef6606bfd8d58bef2ff19e0a06cfcb4 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_836c7c39a1a9e00aaa42b66753628395, [8 x i8] c";\00\00\00\00\00\00\00" }>, align 8
@alloc_513f9749149f734b65064d3c5f9fceb9 = hidden unnamed_addr constant <{ [61 x i8] }> <{ [61 x i8] c"new_creator must be omitted when converting to holder rewards" }>, align 1
@alloc_5f58be378eb25e5423f9152a43c93524 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_513f9749149f734b65064d3c5f9fceb9, [8 x i8] c"=\00\00\00\00\00\00\00" }>, align 8
@alloc_2456d2a22d45c3f40f54af47f68b2aaa = hidden unnamed_addr constant <{ [87 x i8] }> <{ [87 x i8] c"Creator fee is not configurable on a SOL or whitelisted quote; the fee schedule applies" }>, align 1
@alloc_de7648e779c5dfe8d2ac0737d5d702ce = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_2456d2a22d45c3f40f54af47f68b2aaa, [8 x i8] c"W\00\00\00\00\00\00\00" }>, align 8
@alloc_fa8dbda092806c6256e2dc74848b1e06 = hidden unnamed_addr constant <{ [75 x i8] }> <{ [75 x i8] c"current_creator must be passed writable so the outgoing creator can be paid" }>, align 1
@alloc_28b11ab49a417099011ecfd4a76826fc = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_fa8dbda092806c6256e2dc74848b1e06, [8 x i8] c"K\00\00\00\00\00\00\00" }>, align 8
@alloc_6cb63ec0e22ef54f44ebbf3e54ba2cd2 = hidden unnamed_addr constant <{ [91 x i8] }> <{ [91 x i8] c"A frozen sharing-config vault account holds a balance; thaw it before the holder conversion" }>, align 1
@alloc_b82dbbe195645eb6bedc73422e949a08 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_6cb63ec0e22ef54f44ebbf3e54ba2cd2, [8 x i8] c"[\00\00\00\00\00\00\00" }>, align 8
@alloc_f6c00f82890a7d12bf5cdf35201a895e = hidden unnamed_addr constant <{ [64 x i8] }> <{ [64 x i8] c"v3 trades do not support cashback coins; use the v2 instructions" }>, align 1
@alloc_636fd8640ec1d75cbd4a2950dc506443 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_f6c00f82890a7d12bf5cdf35201a895e, [8 x i8] c"@\00\00\00\00\00\00\00" }>, align 8
@alloc_763e59ab327d76d97a2f29d8ec3e298e = hidden unnamed_addr constant <{ [80 x i8] }> <{ [80 x i8] c"creator_fee must be swept before the creator changes or the vault is distributed" }>, align 1
@alloc_1c763fe55df64f7bf8e48f99e8b1b941 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_763e59ab327d76d97a2f29d8ec3e298e, [8 x i8] c"P\00\00\00\00\00\00\00" }>, align 8
@alloc_237dc76775bc3d8a5398e7c559ce7043 = hidden unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"The fee config tier table is empty" }>, align 1
@alloc_b92108d7c9c1edf16447b5da85cd2e42 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_237dc76775bc3d8a5398e7c559ce7043, [8 x i8] c"\22\00\00\00\00\00\00\00" }>, align 8
@alloc_476a9e95d8870a5f1f66c5d7cb44acc0 = hidden unnamed_addr constant <{ [58 x i8] }> <{ [58 x i8] c"The fee config account is shorter than its initialize size" }>, align 1
@alloc_4578fe1bededb8f18c2d5af1e428905d = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_476a9e95d8870a5f1f66c5d7cb44acc0, [8 x i8] c":\00\00\00\00\00\00\00" }>, align 8
@alloc_42406cb0aa1b4bc67f99f706d71ea755 = hidden unnamed_addr constant <{ [66 x i8] }> <{ [66 x i8] c"multi-hop: a hop's input mint is neither side of its bonding curve" }>, align 1
@alloc_24e3ec5866a6a7b2174da7472930cfc3 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_42406cb0aa1b4bc67f99f706d71ea755, [8 x i8] c"B\00\00\00\00\00\00\00" }>, align 8
@alloc_0aa97585dacfed1fd1aa64bd4e6f2d08 = hidden unnamed_addr constant <{ [83 x i8] }> <{ [83 x i8] c"Quote bonding curve remaining account does not match derivation or is uninitialized" }>, align 1
@alloc_5d19798d3a14fbb913b8a1a084b10205 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_0aa97585dacfed1fd1aa64bd4e6f2d08, [8 x i8] c"S\00\00\00\00\00\00\00" }>, align 8
@alloc_ff346cd678c46eb370b4f701f91e3945 = hidden unnamed_addr constant <{ [123 x i8] }> <{ [123 x i8] c"Quote bonding curve is not eligible as a quote: mayhem mode, or the chain's depth-0 root is quoted in a mint no list admits" }>, align 1
@alloc_36addb896e0ec07aaa55adeb50db15f6 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_ff346cd678c46eb370b4f701f91e3945, [8 x i8] c"{\00\00\00\00\00\00\00" }>, align 8
@alloc_5db48e3cfd2dbdb5405beb9a66f38c21 = hidden unnamed_addr constant <{ [92 x i8] }> <{ [92 x i8] c"A quote-chain bonding curve has migrated: its pool and vault remaining accounts are required" }>, align 1
@alloc_f1277ce349a2463554d4a7b7d014bd0b = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_5db48e3cfd2dbdb5405beb9a66f38c21, [8 x i8] c"\\\00\00\00\00\00\00\00" }>, align 8
@alloc_7a0e4093d5e1dfe1f749d5d88e9703ed = hidden unnamed_addr constant <{ [64 x i8] }> <{ [64 x i8] c"Quote pool remaining account is not an initialized pump-amm pool" }>, align 1
@alloc_8da607bd86aa4c25c718a063b1aaaf41 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_7a0e4093d5e1dfe1f749d5d88e9703ed, [8 x i8] c"@\00\00\00\00\00\00\00" }>, align 8
@alloc_1d80dcc460a7f23e1263c0b93c8aa6fc = hidden unnamed_addr constant <{ [77 x i8] }> <{ [77 x i8] c"Quote pool or vault remaining accounts do not match derivation or are invalid" }>, align 1
@alloc_2f3cf09263d9f1bcc9ef759b3aa2df62 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_1d80dcc460a7f23e1263c0b93c8aa6fc, [8 x i8] c"M\00\00\00\00\00\00\00" }>, align 8
@alloc_ef3ec40803c03fbfd3ac3b7120939d5a = hidden unnamed_addr constant <{ [31 x i8] }> <{ [31 x i8] c"Derived quote reserves are zero" }>, align 1
@alloc_cabb96c77be8380163eace0a1f0f2fbe = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_ef3ec40803c03fbfd3ac3b7120939d5a, [8 x i8] c"\1F\00\00\00\00\00\00\00" }>, align 8
@alloc_7d6e9b84e672b2a9d28e219ecd5ec291 = hidden unnamed_addr constant <{ [106 x i8] }> <{ [106 x i8] c"The new curve's depth (quote coin depth plus one) exceeds Global.max_curve_depth or the program's cap of 5" }>, align 1
@alloc_67ba736f5cfc0482e1d2e9e0be320561 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_7d6e9b84e672b2a9d28e219ecd5ec291, [8 x i8] c"j\00\00\00\00\00\00\00" }>, align 8
@alloc_d12027a10317faca5a52f6d0b89e3978 = hidden unnamed_addr constant <{ [99 x i8] }> <{ [99 x i8] c"multi-hop: hop_fees must carry one flag byte per curve hop using only the protocol and creator bits" }>, align 1
@alloc_77b568be10f8ba808d49bf991801c667 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_d12027a10317faca5a52f6d0b89e3978, [8 x i8] c"c\00\00\00\00\00\00\00" }>, align 8
@alloc_eb790bd38c270ed049d8bcc2adfdc75c = hidden unnamed_addr constant <{ [99 x i8] }> <{ [99 x i8] c"A quote-chain coin's curve is complete but not yet migrated; retry once migrate_v2 creates its pool" }>, align 1
@alloc_42fb297333d5f1bcb74ca0231636ca46 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_eb790bd38c270ed049d8bcc2adfdc75c, [8 x i8] c"c\00\00\00\00\00\00\00" }>, align 8
@alloc_b55bc918e09189ba5a7e00830470b7fc = hidden unnamed_addr constant <{ [71 x i8] }> <{ [71 x i8] c"multi-hop: mayhem-mode curves are not routable; use the v2 instructions" }>, align 1
@alloc_28919f8020417f62214a8adb8c1f4f76 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_b55bc918e09189ba5a7e00830470b7fc, [8 x i8] c"G\00\00\00\00\00\00\00" }>, align 8
@alloc_2c20245412c261103bb4cde9c0fce772 = hidden unnamed_addr constant <{ [130 x i8] }> <{ [130 x i8] c"The quote coin is nested: a bonding curve remaining account is required for every coin on its quote chain down to the depth-0 root" }>, align 1
@alloc_aba42ae3ce8a3c58f333368c82464ffe = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_2c20245412c261103bb4cde9c0fce772, [8 x i8] c"\82\00\00\00\00\00\00\00" }>, align 8
@alloc_d93e6b21d28423a1678877da7bb82ed7 = hidden unnamed_addr constant <{ [115 x i8] }> <{ [115 x i8] c"quote_mint must be writable for a quote with a Token-2022 transfer fee: its withheld fees are harvested to the mint" }>, align 1
@alloc_913ab829eb3d2bc297e611153a10a788 = hidden unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_d93e6b21d28423a1678877da7bb82ed7, [8 x i8] c"s\00\00\00\00\00\00\00" }>, align 8
@alloc_f9914d52604ce41deea8408cb1e97323 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00\17\07\00\00\01\00\00\00" }>, align 8
@alloc_6f879966c792ea2bed5d15805d52c0d1 = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00O\0A\00\00\01\00\00\00" }>, align 8
@alloc_265eabfc2ec217be118335bc7d5a6fbb = hidden unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ab3c76e753d2c8a1b6dd7e6114f34c72, [16 x i8] c"\18\00\00\00\00\00\00\00h\0A\00\00\01\00\00\00" }>, align 8
@alloc_893352298987e7848b034a9235bf1bbd = hidden unnamed_addr constant <{ [18 x i8] }> <{ [18 x i8] c"mpl_token_metadata" }>, align 1
@alloc_5a6fbf17302d0584802e4780c2ef04aa = hidden unnamed_addr constant <{ [13 x i8] }> <{ [13 x i8] c"new_authority" }>, align 1
@alloc_eb9259087e22c5f430e5637c053fab9f = hidden unnamed_addr constant <{ [15 x i8] }> <{ [15 x i8] c"sol_destination" }>, align 1
@alloc_40005938c21fe64297f70594790decf7 = hidden unnamed_addr constant <{ [6 x i8] }> <{ [6 x i8] c"buffer" }>, align 1
@alloc_ce73833db14b86fb8c755f332d1a32f1 = hidden unnamed_addr constant <{ [3 x i8] }> <{ [3 x i8] c"idl" }>, align 1
@alloc_bd79480061b020810849620981049cb4 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"base" }>, align 1
@alloc_c1fa7adb83c8a98ef59ff78ea2e9fda2 = hidden unnamed_addr constant <{ [2 x i8] }> <{ [2 x i8] c"to" }>, align 1
@alloc_57a9382c68afe2ba1fb52ceef5eb34e9 = hidden unnamed_addr constant <{ [4 x i8] }> <{ [4 x i8] c"from" }>, align 1
@alloc_31d6082a05efc6d1bc4943a9027a8b5b = hidden unnamed_addr constant <{ [10 x i8] }> <{ [10 x i8] c"IdlAccount" }>, align 1

; Function Attrs: nounwind
declare hidden fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17h671cdb2ca8d46d39E(i64 noundef, ptr noundef, i32 noundef) unnamed_addr #0

; Function Attrs: nounwind
declare hidden fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17hd453c060b3c9d466E(i64 noundef, ptr noundef, i64 noundef, i64 noundef) unnamed_addr #0

; Function Attrs: nounwind
declare hidden fastcc { i64, ptr } @"_ZN11anchor_lang8accounts7account16Account$LT$T$GT$6reload17hc80d8cae2ee31afdE"(ptr noalias nocapture noundef align 8 dereferenceable(184)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h224faf946767fbc8E"(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h44a058432f38c65bE"(ptr noalias nocapture readonly align 8, ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h53b179cc1d7f7e79E"(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17hbc73631fb23b9a71E"(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17hc49c56ffa469469bE"(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17hfa916cc1caf72622E"(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: inlinehint nounwind
declare hidden fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr dead_on_unwind noalias nocapture noundef writable writeonly align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 4 dereferenceable(4)) unnamed_addr #1

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN4core3fmt3num50_$LT$impl$u20$core..fmt..Debug$u20$for$u20$i64$GT$3fmt17h09fd8368c16afbbbE"(ptr noalias noundef readonly align 8 dereferenceable(8), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #1

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @_ZN4core3fmt5Write9write_fmt17h53c8d8d7fdb75a67E(ptr noalias noundef align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 8 dereferenceable(48)) unnamed_addr #0

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read, inaccessiblemem: write)
declare hidden void @"_ZN4core3ptr205drop_in_place$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$GT$17h27ac60e58d0430abE"(ptr noalias nocapture noundef readonly align 8 dereferenceable(24)) unnamed_addr #2

; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(none)
declare hidden void @"_ZN4core3ptr24drop_in_place$LT$i64$GT$17h16b078187564023cE"(ptr noalias nocapture readnone align 8) unnamed_addr #3

; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(none)
declare hidden void @"_ZN4core3ptr37drop_in_place$LT$core..fmt..Error$GT$17hfff795df28ddb366E"(ptr noalias nocapture nonnull readnone align 1) unnamed_addr #3

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read, inaccessiblemem: write)
declare hidden void @"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h53681e21be2b428cE"(ptr noalias nocapture noundef readonly align 8 dereferenceable(24)) unnamed_addr #2

; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(none)
declare hidden void @"_ZN4core3ptr42drop_in_place$LT$solana_pubkey..Pubkey$GT$17hda00edcff73cda79E"(ptr noalias nocapture readnone align 1) unnamed_addr #3

; Function Attrs: nounwind
declare hidden void @"_ZN4core3ptr42drop_in_place$LT$std..io..error..Error$GT$17h53bad7d65d9ed72bE"(ptr noalias nocapture noundef readonly align 8 dereferenceable(8)) unnamed_addr #0

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read, inaccessiblemem: write)
declare hidden fastcc void @"_ZN4core3ptr46drop_in_place$LT$anchor_lang..error..Error$GT$17h710146501a239d49E"(i64, ptr nocapture readonly) unnamed_addr #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read, inaccessiblemem: write)
declare hidden void @"_ZN4core3ptr55drop_in_place$LT$solana_program_error..ProgramError$GT$17h71466a9929f872e5E"(ptr noalias nocapture noundef readonly align 8 dereferenceable(24)) unnamed_addr #2

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN4core5array69_$LT$impl$u20$core..fmt..Debug$u20$for$u20$$u5b$T$u3b$$u20$N$u5d$$GT$3fmt17h3b707ff253e65a4fE"(ptr noalias noundef readonly align 8 dereferenceable(240), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
declare hidden { ptr, ptr } @_ZN4core5error5Error5cause17h958760fef6acec7aE(ptr noalias nocapture readonly align 8) unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
declare hidden void @_ZN4core5error5Error7provide17hb16b28c2591f110bE(ptr noalias nocapture readonly align 8, ptr nocapture nonnull readnone align 1, ptr noalias nocapture readonly align 8) unnamed_addr #4

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
declare hidden { i64, i64 } @_ZN4core5error5Error7type_id17h2110e4cd5cfd7c4fE(ptr noalias nocapture readonly align 8) unnamed_addr #4

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN53_$LT$core..fmt..Error$u20$as$u20$core..fmt..Debug$GT$3fmt17h85666afa16c4890eE"(ptr noalias nocapture nonnull readonly align 1, ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #1

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN58_$LT$alloc..string..String$u20$as$u20$core..fmt..Write$GT$10write_char17hfde5b685689164ccE"(ptr noalias nocapture noundef align 8 dereferenceable(24), i32 noundef) unnamed_addr #1

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN58_$LT$alloc..string..String$u20$as$u20$core..fmt..Write$GT$9write_str17h4b62f46a222bd5b2E"(ptr noalias nocapture noundef align 8 dereferenceable(24), ptr noalias nocapture noundef nonnull readonly align 1, i64 noundef) unnamed_addr #1

; Function Attrs: inlinehint nounwind
declare hidden fastcc noundef ptr @_ZN5alloc5alloc15exchange_malloc17h6cd8dd11b0e3424eE(i64 noundef, i64 noundef) unnamed_addr #1

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN63_$LT$solana_pubkey..PubkeyError$u20$as$u20$core..fmt..Debug$GT$3fmt17h51eee67aafad0389E"(ptr noalias nocapture noundef readonly align 1 dereferenceable(1), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #1

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN70_$LT$core..num..error..TryFromIntError$u20$as$u20$core..fmt..Debug$GT$3fmt17h19e859f4ad052900E"(ptr noalias noundef nonnull readonly align 1, ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #1

; Function Attrs: inlinehint nounwind memory(readwrite, inaccessiblemem: write)
declare hidden fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h145eade74514b58aE"(ptr dead_on_unwind noalias nocapture noundef writable writeonly align 8 dereferenceable(48), ptr noalias nocapture noundef readonly align 8 dereferenceable(48)) unnamed_addr #5

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN71_$LT$solana_program_error..ProgramError$u20$as$u20$core..fmt..Debug$GT$3fmt17he5da34f9213c2408E"(ptr noalias noundef readonly align 8 dereferenceable(24), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #1

; Function Attrs: nounwind
declare hidden fastcc void @"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h034825742f19c3e8E"(ptr dead_on_unwind noalias nocapture noundef writable writeonly align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 8 dereferenceable(48)) unnamed_addr #0

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered6buy_v215token_transfers25transfer_curve_tokens_ref17h1f421d86260b0d60E(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(216), ptr noalias nocapture noundef readonly align 8 dereferenceable(216), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), i8 noundef, ptr noalias nocapture noundef readonly align 8 dereferenceable(48), i64 noundef, ptr noalias noundef readonly align 8 dereferenceable(16)) unnamed_addr #6

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered10legacy_buy15native_payments18ensure_rent_exempt17h399eeff5d7deb0aeE(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias noundef readonly align 8 dereferenceable(48)) unnamed_addr #6

; Function Attrs: nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered11legacy_sell13fee_recipient22validate_fee_recipient17h69b101f8bf3b5f3fE(ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(1088), ptr noalias nocapture noundef readonly align 8 dereferenceable(168)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden void @_ZN14pump_recovered11legacy_sell7fee_cpi10trade_fees17h7aa59a9a9a43f0ceE(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([40 x i8]) align 8 dereferenceable(40), ptr noalias nocapture noundef readonly align 8 dereferenceable(1088), ptr noalias nocapture noundef readonly align 8 dereferenceable(168), ptr noalias nocapture noundef readonly align 8 dereferenceable(128), ptr noalias nocapture noundef readonly align 8 dereferenceable(144), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(48), i64 noundef) unnamed_addr #0

; Function Attrs: nounwind
declare hidden void @_ZN14pump_recovered11legacy_sell8fee_math3fee17h1cb7f4ca1fd3d0a4E(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([16 x i8]) align 8 dereferenceable(16), i64 noundef, i64 noundef) unnamed_addr #0

; Function Attrs: nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered11legacy_sell22check_bonding_curve_v217h00d092da4006a419E(ptr noalias nocapture noundef nonnull readonly align 8, i64 noundef, ptr noalias noundef readonly align 1 dereferenceable(32)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden void @_ZN14pump_recovered11legacy_sell21buyback_fee_recipient17h866cdb0b033da421E(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([16 x i8]) align 8 dereferenceable(16), ptr noalias noundef nonnull readonly align 8, i64 noundef, ptr noalias nocapture noundef readonly align 8 dereferenceable(1080), i64 noundef) unnamed_addr #0

; Function Attrs: noinline nounwind
declare hidden void @_ZN14pump_recovered16constant_product16tokens_for_quote17he019e08956a9d08eE(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([24 x i8]) align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 8 dereferenceable(160), i64 noundef) unnamed_addr #6

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @"_ZN14pump_recovered21mayhem_virtual_params59_$LT$impl$u20$pump_recovered..trade_types..BondingCurve$GT$27sync_virtual_quote_reserves17hf0f98df7e2783a0dE"(ptr noalias nocapture noundef align 8 dereferenceable(160), i64 noundef, i64 noundef, ptr noalias nocapture noundef readonly align 1 dereferenceable(32)) unnamed_addr #6

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered11trade_types21prepare_bonding_curve17ha540fe71dc8e912aE(ptr noalias nocapture noundef readonly align 8 dereferenceable(168), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(8)) unnamed_addr #6

; Function Attrs: nounwind
declare hidden void @_ZN14pump_recovered9buy_quote17h6e88bfeac89d1618E(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([24 x i8]) align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 8 dereferenceable(160), i64 noundef) unnamed_addr #0

; Function Attrs: noinline nounwind
declare hidden { i64, i64 } @_ZN14pump_recovered18split_protocol_fee17hcf8c01015a0dc405E(ptr noalias nocapture noundef readonly align 8 dereferenceable(1080), i64 noundef, i1 noundef zeroext) unnamed_addr #6

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered19user_quote_payments25transfer_native_unchecked17hae799f99e21990eeE(ptr noalias nocapture noundef readonly align 8 dereferenceable(48), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(48), i64 noundef) unnamed_addr #6

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered19user_quote_payments31transfer_native_curve_unchecked17h5787faa769b7ce25E(ptr noalias nocapture noundef readonly align 8 dereferenceable(48), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), i64 noundef) unnamed_addr #6

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered19user_quote_payments21transfer_native_owned17h35ba2fcd8ae234f9E(ptr noalias nocapture noundef readonly align 8 dereferenceable(48), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(48), i64 noundef) unnamed_addr #6

; Function Attrs: noinline nounwind
declare hidden { i64, ptr } @_ZN14pump_recovered19user_quote_payments21transfer_native_curve17hbd4b0131296ae669E(ptr noalias nocapture noundef readonly align 8 dereferenceable(48), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), ptr noalias nocapture noundef readonly align 8 dereferenceable(8), i64 noundef) unnamed_addr #6

; Function Attrs: inlinehint nounwind
declare hidden noundef zeroext i1 @"_ZN114_$LT$pump_recovered..token_incentives..volume_accumulator..GlobalVolumeAccumulator$u20$as$u20$core..fmt..Debug$GT$3fmt17h88a090966823c1abE"(ptr noalias noundef readonly align 8 dereferenceable(536), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #1

; Function Attrs: nounwind
declare hidden void @"_ZN81_$LT$pump_recovered..trade_types..CompleteEvent$u20$as$u20$anchor_lang..Event$GT$4data17h723d3bf216fd7573E"(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([24 x i8]) align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 8 dereferenceable(136)) unnamed_addr #0

; Function Attrs: nounwind
define hidden { i64, ptr } @_ZN14pump_recovered14pump_recovered16buy_exact_sol_in17h28eae2e2fdc8f8b2E(ptr noalias nocapture noundef readonly align 8 dereferenceable(40) %ctx, i64 noundef %spendable_sol_in, i64 noundef %min_tokens_out, i1 noundef zeroext %track_volume, i1 noundef zeroext %partial_fill) unnamed_addr #0 {
start:
  %_11.i.i = alloca [0 x i8], align 1
  %formatter.i.i = alloca [64 x i8], align 8
  %buf.i.i = alloca [24 x i8], align 8
  %_789.i = alloca [24 x i8], align 8
  %_526.i = alloca [1 x i8], align 1
  %_522.i = alloca [32 x i8], align 8
  %_519.i = alloca [16 x i8], align 8
  %_516.i = alloca [48 x i8], align 8
  %_512.i = alloca [24 x i8], align 8
  %_504.i = alloca [24 x i8], align 8
  %ix38.i = alloca [80 x i8], align 8
  %_498.i = alloca [48 x i8], align 8
  %ix_data37.i = alloca [24 x i8], align 8
  %inner_data36.i = alloca [24 x i8], align 8
  %authority_info35.i = alloca [48 x i8], align 8
  %_491.i = alloca [24 x i8], align 8
  %_489.i = alloca [16 x i8], align 8
  %event34.i = alloca [136 x i8], align 8
  %_478.i = alloca [1 x i8], align 1
  %_474.i = alloca [32 x i8], align 8
  %_471.i = alloca [16 x i8], align 8
  %_468.i = alloca [48 x i8], align 8
  %_464.i = alloca [24 x i8], align 8
  %_456.i = alloca [24 x i8], align 8
  %ix.i = alloca [80 x i8], align 8
  %_448.i = alloca [48 x i8], align 8
  %ix_data.i = alloca [24 x i8], align 8
  %inner_data.i = alloca [24 x i8], align 8
  %authority_info.i = alloca [48 x i8], align 8
  %_439.i = alloca [24 x i8], align 8
  %_437.i = alloca [16 x i8], align 8
  %_405.i = alloca [32 x i8], align 1
  %_403.i = alloca [32 x i8], align 1
  %_402.i = alloca [32 x i8], align 1
  %event.i = alloca [424 x i8], align 8
  %_395.i = alloca [48 x i8], align 8
  %creator.i = alloca [32 x i8], align 1
  %_341.i = alloca [24 x i8], align 8
  %_339.i = alloca [24 x i8], align 8
  %_338.i = alloca [160 x i8], align 8
  %_329.i = alloca [48 x i8], align 8
  %mint.i = alloca [32 x i8], align 1
  %_317.i = alloca [32 x i8], align 1
  %quote_mint.i = alloca [32 x i8], align 1
  %_299.i = alloca [32 x i8], align 1
  %_295.i = alloca [1 x i8], align 1
  %_292.i = alloca [32 x i8], align 1
  %_289.i = alloca [48 x i8], align 8
  %_286.i = alloca [16 x i8], align 8
  %_240.i = alloca [160 x i8], align 8
  %_223.i = alloca [160 x i8], align 8
  %_210.i = alloca [160 x i8], align 8
  %_193.i = alloca [16 x i8], align 8
  %_191.i = alloca [32 x i8], align 1
  %_185.i = alloca [16 x i8], align 8
  %_177.i = alloca [24 x i8], align 8
  %_155.i = alloca [24 x i8], align 8
  %_141.i = alloca [160 x i8], align 8
  %_120.i = alloca [16 x i8], align 8
  %_118.i = alloca [32 x i8], align 1
  %_111.i = alloca [16 x i8], align 8
  %_100.i = alloca [160 x i8], align 8
  %_80.i = alloca [32 x i8], align 1
  %_76.i = alloca [32 x i8], align 1
  %_67.i = alloca [40 x i8], align 8
  %_55.i = alloca [160 x i8], align 8
  %_43.i = alloca [160 x i8], align 8
  %_33.i = alloca [24 x i8], align 8
  %_32.i = alloca [160 x i8], align 8
  %_25.i = alloca [16 x i8], align 8
  %buyback_fee_recipient.i = alloca [8 x i8], align 8
  %bonding_curve.i = alloca [8 x i8], align 8
  %fee_recipient.i = alloca [8 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !2)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_512.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_498.i)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %inner_data36.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %authority_info35.i)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_464.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_448.i)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %creator.i)
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %fee_recipient.i), !noalias !2
  %0 = getelementptr inbounds i8, ptr %ctx, i64 8
  %_528.i = load ptr, ptr %0, align 8, !alias.scope !2, !nonnull !5, !align !6, !noundef !5
  %1 = getelementptr inbounds i8, ptr %_528.i, i64 976
  store ptr %1, ptr %fee_recipient.i, align 8, !noalias !2
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %bonding_curve.i), !noalias !2
  %2 = getelementptr inbounds i8, ptr %_528.i, i64 800
  store ptr %2, ptr %bonding_curve.i, align 8, !noalias !2
  %associated_bonding_curve.i = getelementptr inbounds i8, ptr %_528.i, i64 272
  %associated_user.i = getelementptr inbounds i8, ptr %_528.i, i64 488
  %token_program.i = getelementptr inbounds i8, ptr %_528.i, i64 1000
  %_14.i = getelementptr inbounds i8, ptr %_528.i, i64 992
  %_15.i = getelementptr inbounds i8, ptr %_528.i, i64 984
  %3 = tail call { i64, ptr } @_ZN14pump_recovered11trade_types21prepare_bonding_curve17ha540fe71dc8e912aE(ptr noalias noundef nonnull readonly align 8 dereferenceable(168) %2, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_14.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_15.i) #16, !noalias !2
  %4 = extractvalue { i64, ptr } %3, 0
  %5 = icmp eq i64 %4, 2
  br i1 %5, label %bb191.i, label %bb190.i

bb191.i:                                          ; preds = %start
  %6 = getelementptr inbounds i8, ptr %_528.i, i64 968
  %_529.i = load ptr, ptr %6, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %7 = tail call { i64, ptr } @_ZN14pump_recovered11legacy_sell13fee_recipient22validate_fee_recipient17h69b101f8bf3b5f3fE(ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %1, ptr noalias noundef nonnull readonly align 8 dereferenceable(1088) %_529.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(168) %2) #16, !noalias !2
  %8 = extractvalue { i64, ptr } %7, 0
  %9 = icmp eq i64 %8, 2
  br i1 %9, label %bb193.i, label %bb192.i

bb190.i:                                          ; preds = %start
  %10 = extractvalue { i64, ptr } %3, 1
  br label %bb186.i

bb193.i:                                          ; preds = %bb191.i
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %buyback_fee_recipient.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_25.i), !noalias !2
  %11 = getelementptr inbounds i8, ptr %ctx, i64 16
  %_530.0.i = load ptr, ptr %11, align 8, !alias.scope !2, !nonnull !5, !align !6, !noundef !5
  %12 = getelementptr inbounds i8, ptr %ctx, i64 24
  %_530.1.i = load i64, ptr %12, align 8, !alias.scope !2, !noundef !5
  %_531.i = load ptr, ptr %6, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_26.i = getelementptr inbounds i8, ptr %_531.i, i64 8
  call void @_ZN14pump_recovered11legacy_sell21buyback_fee_recipient17h866cdb0b033da421E(ptr noalias nocapture noundef nonnull sret([16 x i8]) align 8 dereferenceable(16) %_25.i, ptr noalias noundef nonnull readonly align 8 %_530.0.i, i64 noundef %_530.1.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(1080) %_26.i, i64 noundef 1) #16, !noalias !2
  %13 = load i64, ptr %_25.i, align 8, !range !7, !noalias !2, !noundef !5
  %14 = icmp eq i64 %13, 2
  %15 = getelementptr inbounds i8, ptr %_25.i, i64 8
  %_575.i = load ptr, ptr %15, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_25.i), !noalias !2
  br i1 %14, label %bb195.i, label %bb185.i

bb192.i:                                          ; preds = %bb191.i
  %16 = extractvalue { i64, ptr } %7, 1
  br label %bb186.i

bb195.i:                                          ; preds = %bb193.i
  store ptr %_575.i, ptr %buyback_fee_recipient.i, align 8, !noalias !2
  %17 = getelementptr inbounds i8, ptr %_528.i, i64 961
  %18 = load i8, ptr %17, align 1, !range !8, !noalias !2, !noundef !5
  %_29.not.i = icmp eq i8 %18, 0
  br i1 %_29.not.i, label %bb9.i, label %bb5.i

bb9.i:                                            ; preds = %bb195.i
  %_40.i = icmp eq i64 %min_tokens_out, 0
  br i1 %_40.i, label %bb10.i, label %bb11.i

bb5.i:                                            ; preds = %bb195.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_32.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_33.i), !noalias !2
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_33.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cdbdeba67b052fefbde5996b437aa24e) #16, !noalias !2
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i.i), !noalias !9
  store i64 0, ptr %buf.i.i, align 8, !noalias !9
  %_9.sroa.4.0.buf.sroa_idx.i.i = getelementptr inbounds i8, ptr %buf.i.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i.i, align 8, !noalias !9
  %_9.sroa.5.0.buf.sroa_idx.i.i = getelementptr inbounds i8, ptr %buf.i.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i.i, align 8, !noalias !9
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i.i), !noalias !9
  %19 = getelementptr inbounds i8, ptr %formatter.i.i, i64 52
  store i32 0, ptr %19, align 4, !noalias !9
  %20 = getelementptr inbounds i8, ptr %formatter.i.i, i64 48
  store i32 32, ptr %20, align 8, !noalias !9
  %21 = getelementptr inbounds i8, ptr %formatter.i.i, i64 56
  store i8 3, ptr %21, align 8, !noalias !9
  store i64 0, ptr %formatter.i.i, align 8, !noalias !9
  %22 = getelementptr inbounds i8, ptr %formatter.i.i, i64 16
  store i64 0, ptr %22, align 8, !noalias !9
  %23 = getelementptr inbounds i8, ptr %formatter.i.i, i64 32
  store ptr %buf.i.i, ptr %23, align 8, !noalias !9
  %24 = getelementptr inbounds i8, ptr %formatter.i.i, i64 40
  store ptr @vtable.4, ptr %24, align 8, !noalias !9
  %25 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17h8d643902cd3d27a2E"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cdbdeba67b052fefbde5996b437aa24e, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i.i) #16, !noalias !13
  br i1 %25, label %bb3.i.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E.exit.i"

bb3.i.i:                                          ; preds = %bb5.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #17, !noalias !9
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E.exit.i": ; preds = %bb5.i
  %26 = getelementptr inbounds i8, ptr %_32.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %26, ptr noundef nonnull align 8 dereferenceable(24) %buf.i.i, i64 24, i1 false), !noalias !2
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i.i), !noalias !9
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i.i), !noalias !9
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i.i), !noalias !2
  %27 = getelementptr inbounds i8, ptr %_32.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %27, ptr noundef nonnull align 8 dereferenceable(24) %_33.i, i64 24, i1 false), !noalias !2
  %28 = getelementptr inbounds i8, ptr %_32.i, i64 152
  store i32 6005, ptr %28, align 8, !noalias !2
  store i64 0, ptr %_32.i, align 8, !noalias !2
  %_36.sroa.4.0._32.sroa_idx.i = getelementptr inbounds i8, ptr %_32.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_36.sroa.4.0._32.sroa_idx.i, align 8, !noalias !2
  %_36.sroa.4.sroa.4.0._36.sroa.4.0._32.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_32.i, i64 16
  store i64 24, ptr %_36.sroa.4.sroa.4.0._36.sroa.4.0._32.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_36.sroa.4.sroa.5.0._36.sroa.4.0._32.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_32.i, i64 24
  store i32 53, ptr %_36.sroa.4.sroa.5.0._36.sroa.4.0._32.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %29 = getelementptr inbounds i8, ptr %_32.i, i64 80
  store i8 2, ptr %29, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_33.i), !noalias !2
  %30 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_32.i) #16, !noalias !2
  %_31.0.i = extractvalue { i64, ptr } %30, 0
  %_31.1.i = extractvalue { i64, ptr } %30, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_32.i), !noalias !2
  br label %bb185.i

bb11.i:                                           ; preds = %bb9.i
  %_52.i = icmp eq i64 %spendable_sol_in, 0
  br i1 %_52.i, label %bb16.i, label %bb17.i

bb10.i:                                           ; preds = %bb9.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_43.i), !noalias !2
  %31 = getelementptr inbounds i8, ptr %_43.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %31, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e3e143fb26e9bc2a81054057f78086ba) #16, !noalias !2
  %32 = getelementptr inbounds i8, ptr %_43.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %32, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e3e143fb26e9bc2a81054057f78086ba) #16, !noalias !2
  %33 = getelementptr inbounds i8, ptr %_43.i, i64 152
  store i32 6020, ptr %33, align 8, !noalias !2
  store i64 0, ptr %_43.i, align 8, !noalias !2
  %_47.sroa.4.0._43.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_47.sroa.4.0._43.sroa_idx.i, align 8, !noalias !2
  %_47.sroa.4.sroa.4.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 16
  store i64 24, ptr %_47.sroa.4.sroa.4.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_47.sroa.4.sroa.5.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 24
  store i32 57, ptr %_47.sroa.4.sroa.5.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %34 = getelementptr inbounds i8, ptr %_43.i, i64 80
  store i8 2, ptr %34, align 8, !noalias !2
  %35 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_43.i) #16, !noalias !2
  %_42.0.i = extractvalue { i64, ptr } %35, 0
  %_42.1.i = extractvalue { i64, ptr } %35, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_43.i), !noalias !2
  %36 = tail call fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17h671cdb2ca8d46d39E(i64 noundef %_42.0.i, ptr noundef %_42.1.i, i32 noundef 0) #16
  %_41.0.i = extractvalue { i64, ptr } %36, 0
  %_41.1.i = extractvalue { i64, ptr } %36, 1
  br label %bb185.i

bb17.i:                                           ; preds = %bb11.i
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %_67.i), !noalias !2
  %_532.i = load ptr, ptr %6, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_70.i = getelementptr inbounds i8, ptr %_528.i, i64 144
  %_72.i = getelementptr inbounds i8, ptr %_528.i, i64 1032
  %37 = getelementptr inbounds i8, ptr %_528.i, i64 1008
  %_73.i = load ptr, ptr %37, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  call void @_ZN14pump_recovered11legacy_sell7fee_cpi10trade_fees17h7aa59a9a9a43f0ceE(ptr noalias nocapture noundef nonnull sret([40 x i8]) align 8 dereferenceable(40) %_67.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(1088) %_532.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(168) %2, ptr noalias noundef nonnull readonly align 8 dereferenceable(128) %_70.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(144) %_528.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_72.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_73.i, i64 noundef %spendable_sol_in) #16, !noalias !2
  %_579.i = load i64, ptr %_67.i, align 8, !range !14, !noalias !2, !noundef !5
  %trunc.not.i = icmp eq i64 %_579.i, 0
  br i1 %trunc.not.i, label %bb200.i, label %bb199.i

bb16.i:                                           ; preds = %bb11.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_55.i), !noalias !2
  %38 = getelementptr inbounds i8, ptr %_55.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %38, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_73667b43dd614c93c329aef199c5ef8b) #16, !noalias !2
  %39 = getelementptr inbounds i8, ptr %_55.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %39, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_73667b43dd614c93c329aef199c5ef8b) #16, !noalias !2
  %40 = getelementptr inbounds i8, ptr %_55.i, i64 152
  store i32 6041, ptr %40, align 8, !noalias !2
  store i64 0, ptr %_55.i, align 8, !noalias !2
  %_59.sroa.4.0._55.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_59.sroa.4.0._55.sroa_idx.i, align 8, !noalias !2
  %_59.sroa.4.sroa.4.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 16
  store i64 24, ptr %_59.sroa.4.sroa.4.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_59.sroa.4.sroa.5.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 24
  store i32 59, ptr %_59.sroa.4.sroa.5.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %41 = getelementptr inbounds i8, ptr %_55.i, i64 80
  store i8 2, ptr %41, align 8, !noalias !2
  %42 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_55.i) #16, !noalias !2
  %_54.0.i = extractvalue { i64, ptr } %42, 0
  %_54.1.i = extractvalue { i64, ptr } %42, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_55.i), !noalias !2
  %43 = tail call fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17h671cdb2ca8d46d39E(i64 noundef %_54.0.i, ptr noundef %_54.1.i, i32 noundef 0) #16
  %_53.0.i = extractvalue { i64, ptr } %43, 0
  %_53.1.i = extractvalue { i64, ptr } %43, 1
  br label %bb185.i

bb200.i:                                          ; preds = %bb17.i
  %_580.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_67.i, i64 24
  %_580.sroa.6.0.copyload.i = load i64, ptr %_580.sroa.6.0..sroa_idx.i, align 8, !noalias !2
  %_580.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %_67.i, i64 32
  %_580.sroa.7.0.copyload.i = load i64, ptr %_580.sroa.7.0..sroa_idx.i, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %_67.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_76.i), !noalias !2
  %_583.i = load ptr, ptr %_15.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_584.i = load ptr, ptr %_583.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_76.i, ptr noundef nonnull align 1 dereferenceable(32) %_584.i, i64 32, i1 false), !noalias !2
  %_533.i = load ptr, ptr %6, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_587.i = getelementptr inbounds i8, ptr %_533.i, i64 648
  %44 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_76.i, ptr noundef nonnull dereferenceable(32) %_587.i, i64 32), !noalias !2
  %45 = icmp eq i32 %44, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_76.i), !noalias !2
  %._580.sroa.6.0.copyload.i = select i1 %45, i64 0, i64 %_580.sroa.6.0.copyload.i
  %._580.sroa.7.0.copyload.i = select i1 %45, i64 0, i64 %_580.sroa.7.0.copyload.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_80.i), !noalias !2
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_80.i, i8 0, i64 32, i1 false), !noalias !2
  %_589.i = getelementptr inbounds i8, ptr %_528.i, i64 808
  %46 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_589.i, ptr noundef nonnull dereferenceable(32) %_80.i, i64 32), !noalias !2
  %47 = icmp eq i32 %46, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_80.i), !noalias !2
  %.._580.sroa.7.0.copyload184.i = select i1 %47, i64 0, i64 %._580.sroa.7.0.copyload.i
  %48 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %._580.sroa.6.0.copyload.i, i64 %.._580.sroa.7.0.copyload184.i)
  %_594.0.i = extractvalue { i64, i1 } %48, 0
  %_594.1.i = extractvalue { i64, i1 } %48, 1
  br i1 %_594.1.i, label %bb205.i, label %bb206.i

bb199.i:                                          ; preds = %bb17.i
  %49 = getelementptr inbounds i8, ptr %_67.i, i64 8
  %_581.0.i = load i64, ptr %49, align 8, !range !14, !noalias !2, !noundef !5
  %50 = getelementptr inbounds i8, ptr %_67.i, i64 16
  %_581.1.i = load ptr, ptr %50, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %_67.i), !noalias !2
  br label %bb185.i

bb206.i:                                          ; preds = %bb200.i
  %51 = icmp eq i64 %_594.0.i, 0
  br i1 %51, label %bb40.i, label %bb34.i

bb205.i:                                          ; preds = %bb200.i
  %52 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 24) #16, !noalias !2
  %_600.0.i = extractvalue { i64, ptr } %52, 0
  %_600.1.i = extractvalue { i64, ptr } %52, 1
  br label %bb185.i

bb34.i:                                           ; preds = %bb206.i
  %_90.i = zext i64 %spendable_sol_in to i128
  %53 = mul nuw nsw i128 %_90.i, 10000
  %_93.i = zext i64 %_594.0.i to i128
  %54 = add nuw nsw i128 %_93.i, 10000
  %_88.i = udiv i128 %53, %54
  %55 = trunc i128 %_88.i to i64
  %_96.i = icmp eq i64 %55, 0
  br i1 %_96.i, label %bb35.i, label %bb40.i

bb40.i:                                           ; preds = %bb34.i, %bb206.i
  %raw_quote.sroa.0.0293.i = phi i64 [ %55, %bb34.i ], [ %spendable_sol_in, %bb206.i ]
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_111.i), !noalias !2
  call void @_ZN14pump_recovered11legacy_sell8fee_math3fee17h1cb7f4ca1fd3d0a4E(ptr noalias nocapture noundef nonnull sret([16 x i8]) align 8 dereferenceable(16) %_111.i, i64 noundef %raw_quote.sroa.0.0293.i, i64 noundef %._580.sroa.6.0.copyload.i) #16, !noalias !2
  %56 = load i64, ptr %_111.i, align 8, !range !7, !noalias !2, !noundef !5
  %57 = icmp eq i64 %56, 2
  %58 = getelementptr inbounds i8, ptr %_111.i, i64 8
  br i1 %57, label %bb210.i, label %bb209.i

bb35.i:                                           ; preds = %bb34.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_100.i), !noalias !2
  %59 = getelementptr inbounds i8, ptr %_100.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %59, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_73667b43dd614c93c329aef199c5ef8b) #16, !noalias !2
  %60 = getelementptr inbounds i8, ptr %_100.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %60, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_73667b43dd614c93c329aef199c5ef8b) #16, !noalias !2
  %61 = getelementptr inbounds i8, ptr %_100.i, i64 152
  store i32 6041, ptr %61, align 8, !noalias !2
  store i64 0, ptr %_100.i, align 8, !noalias !2
  %_104.sroa.4.0._100.sroa_idx.i = getelementptr inbounds i8, ptr %_100.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_104.sroa.4.0._100.sroa_idx.i, align 8, !noalias !2
  %_104.sroa.4.sroa.4.0._104.sroa.4.0._100.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_100.i, i64 16
  store i64 24, ptr %_104.sroa.4.sroa.4.0._104.sroa.4.0._100.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_104.sroa.4.sroa.5.0._104.sroa.4.0._100.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_100.i, i64 24
  store i32 92, ptr %_104.sroa.4.sroa.5.0._104.sroa.4.0._100.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %62 = getelementptr inbounds i8, ptr %_100.i, i64 80
  store i8 2, ptr %62, align 8, !noalias !2
  %63 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_100.i) #16, !noalias !2
  %_99.0.i = extractvalue { i64, ptr } %63, 0
  %_99.1.i = extractvalue { i64, ptr } %63, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_100.i), !noalias !2
  %64 = tail call fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17h671cdb2ca8d46d39E(i64 noundef %_99.0.i, ptr noundef %_99.1.i, i32 noundef 0) #16
  %_98.0.i = extractvalue { i64, ptr } %64, 0
  %_98.1.i = extractvalue { i64, ptr } %64, 1
  br label %bb185.i

bb210.i:                                          ; preds = %bb40.i
  %_602.i = load i64, ptr %58, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_111.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_118.i), !noalias !2
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_118.i, i8 0, i64 32, i1 false), !noalias !2
  %65 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_589.i, ptr noundef nonnull dereferenceable(32) %_118.i, i64 32), !noalias !2
  %.not.i = icmp eq i32 %65, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_118.i), !noalias !2
  br i1 %.not.i, label %bb45.i, label %bb42.i

bb209.i:                                          ; preds = %bb40.i
  %_603.1.i = load ptr, ptr %58, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_111.i), !noalias !2
  br label %bb185.i

bb42.i:                                           ; preds = %bb210.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_120.i), !noalias !2
  call void @_ZN14pump_recovered11legacy_sell8fee_math3fee17h1cb7f4ca1fd3d0a4E(ptr noalias nocapture noundef nonnull sret([16 x i8]) align 8 dereferenceable(16) %_120.i, i64 noundef %raw_quote.sroa.0.0293.i, i64 noundef %._580.sroa.7.0.copyload.i) #16, !noalias !2
  %66 = load i64, ptr %_120.i, align 8, !range !7, !noalias !2, !noundef !5
  %67 = icmp eq i64 %66, 2
  %68 = getelementptr inbounds i8, ptr %_120.i, i64 8
  br i1 %67, label %bb214.i, label %bb213.i

bb45.i:                                           ; preds = %bb214.i, %bb210.i
  %creator_fee.sroa.0.0.i = phi i64 [ %_611.i, %bb214.i ], [ 0, %bb210.i ]
  %69 = tail call i64 @llvm.uadd.sat.i64(i64 %raw_quote.sroa.0.0293.i, i64 %_602.i)
  %70 = tail call i64 @llvm.uadd.sat.i64(i64 %69, i64 %creator_fee.sroa.0.0.i)
  %_129.i = icmp ugt i64 %70, %spendable_sol_in
  br i1 %_129.i, label %bb46.i, label %bb53.i

bb214.i:                                          ; preds = %bb42.i
  %_611.i = load i64, ptr %68, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_120.i), !noalias !2
  br label %bb45.i

bb213.i:                                          ; preds = %bb42.i
  %_612.1.i = load ptr, ptr %68, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_120.i), !noalias !2
  br label %bb185.i

bb53.i:                                           ; preds = %bb218.i, %bb45.i
  %quote.sroa.0.0.i = phi i64 [ %_616.i, %bb218.i ], [ %raw_quote.sroa.0.0293.i, %bb45.i ]
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_155.i), !noalias !2
  call void @_ZN14pump_recovered16constant_product16tokens_for_quote17he019e08956a9d08eE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_155.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(160) %_589.i, i64 noundef %quote.sroa.0.0.i) #16, !noalias !2
  %_623.i = load i64, ptr %_155.i, align 8, !range !14, !noalias !2, !noundef !5
  %trunc175.not.i = icmp eq i64 %_623.i, 0
  %71 = getelementptr inbounds i8, ptr %_155.i, i64 8
  %_62480176.i = load i64, ptr %71, align 8, !noalias !2
  %.sroa_idx.i = getelementptr inbounds i8, ptr %_155.i, i64 16
  br i1 %trunc175.not.i, label %bb223.i, label %bb222.i

bb46.i:                                           ; preds = %bb45.i
  %72 = tail call i64 @llvm.usub.sat.i64(i64 %70, i64 %spendable_sol_in)
  %_615.not.i = icmp ult i64 %raw_quote.sroa.0.0293.i, %72
  br i1 %_615.not.i, label %bb219.i, label %bb218.i

bb219.i:                                          ; preds = %bb46.i
  %73 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 24) #16, !noalias !2
  %_622.0.i = extractvalue { i64, ptr } %73, 0
  %_622.1.i = extractvalue { i64, ptr } %73, 1
  br label %bb185.i

bb218.i:                                          ; preds = %bb46.i
  %_616.i = sub nuw i64 %raw_quote.sroa.0.0293.i, %72
  %_137.i = icmp eq i64 %_616.i, 0
  br i1 %_137.i, label %bb47.i, label %bb53.i

bb47.i:                                           ; preds = %bb218.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_141.i), !noalias !2
  %74 = getelementptr inbounds i8, ptr %_141.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %74, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_004acfa89553cbafbb2b2f00006c54c3) #16, !noalias !2
  %75 = getelementptr inbounds i8, ptr %_141.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %75, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_004acfa89553cbafbb2b2f00006c54c3) #16, !noalias !2
  %76 = getelementptr inbounds i8, ptr %_141.i, i64 152
  store i32 6042, ptr %76, align 8, !noalias !2
  store i64 0, ptr %_141.i, align 8, !noalias !2
  %_145.sroa.4.0._141.sroa_idx.i = getelementptr inbounds i8, ptr %_141.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_145.sroa.4.0._141.sroa_idx.i, align 8, !noalias !2
  %_145.sroa.4.sroa.4.0._145.sroa.4.0._141.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_141.i, i64 16
  store i64 24, ptr %_145.sroa.4.sroa.4.0._145.sroa.4.0._141.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_145.sroa.4.sroa.5.0._145.sroa.4.0._141.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_141.i, i64 24
  store i32 110, ptr %_145.sroa.4.sroa.5.0._145.sroa.4.0._141.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %77 = getelementptr inbounds i8, ptr %_141.i, i64 80
  store i8 2, ptr %77, align 8, !noalias !2
  %78 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_141.i) #16, !noalias !2
  %_140.0.i = extractvalue { i64, ptr } %78, 0
  %_140.1.i = extractvalue { i64, ptr } %78, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_141.i), !noalias !2
  %79 = tail call fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17h671cdb2ca8d46d39E(i64 noundef %_140.0.i, ptr noundef %_140.1.i, i32 noundef 0) #16
  %_139.0.i = extractvalue { i64, ptr } %79, 0
  %_139.1.i = extractvalue { i64, ptr } %79, 1
  br label %bb185.i

bb223.i:                                          ; preds = %bb53.i
  %_62481.i = load i64, ptr %.sroa_idx.i, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_155.i), !noalias !2
  %_627.not.i = icmp eq i64 %_62481.i, 0
  br i1 %_627.not.i, label %bb225.i, label %bb224.i

bb222.i:                                          ; preds = %bb53.i
  %_625.1.i = load ptr, ptr %.sroa_idx.i, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_155.i), !noalias !2
  br label %bb185.i

bb225.i:                                          ; preds = %bb223.i
  %80 = getelementptr inbounds i8, ptr %_528.i, i64 888
  %_168.i = load i64, ptr %80, align 8, !noalias !2, !noundef !5
  %_167.i = icmp ugt i64 %_62480176.i, %_168.i
  %brmerge.not.i = and i1 %_167.i, %partial_fill
  br i1 %brmerge.not.i, label %bb56.i, label %bb70.i

bb224.i:                                          ; preds = %bb223.i
  %81 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 25) #16, !noalias !2
  %_635.0.i = extractvalue { i64, ptr } %81, 0
  %_635.1.i = extractvalue { i64, ptr } %81, 1
  br label %bb185.i

bb70.i:                                           ; preds = %bb225.i
  %_220.i = icmp ult i64 %_62480176.i, %min_tokens_out
  br i1 %_220.i, label %bb71.i, label %bb77.i

bb56.i:                                           ; preds = %bb225.i
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_177.i), !noalias !2
  call void @_ZN14pump_recovered9buy_quote17h6e88bfeac89d1618E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_177.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(160) %_589.i, i64 noundef %_168.i) #16, !noalias !2
  %_636.i = load i64, ptr %_177.i, align 8, !range !14, !noalias !2, !noundef !5
  %trunc177.not.i = icmp eq i64 %_636.i, 0
  %82 = getelementptr inbounds i8, ptr %_177.i, i64 8
  %_63790178.i = load i64, ptr %82, align 8, !noalias !2
  %.sroa_idx91.i = getelementptr inbounds i8, ptr %_177.i, i64 16
  br i1 %trunc177.not.i, label %bb228.i, label %bb227.i

bb71.i:                                           ; preds = %bb70.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_223.i), !noalias !2
  %83 = getelementptr inbounds i8, ptr %_223.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %83, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_004acfa89553cbafbb2b2f00006c54c3) #16, !noalias !2
  %84 = getelementptr inbounds i8, ptr %_223.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %84, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_004acfa89553cbafbb2b2f00006c54c3) #16, !noalias !2
  %85 = getelementptr inbounds i8, ptr %_223.i, i64 152
  store i32 6042, ptr %85, align 8, !noalias !2
  store i64 0, ptr %_223.i, align 8, !noalias !2
  %_227.sroa.4.0._223.sroa_idx.i = getelementptr inbounds i8, ptr %_223.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_227.sroa.4.0._223.sroa_idx.i, align 8, !noalias !2
  %_227.sroa.4.sroa.4.0._227.sroa.4.0._223.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_223.i, i64 16
  store i64 24, ptr %_227.sroa.4.sroa.4.0._227.sroa.4.0._223.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_227.sroa.4.sroa.5.0._227.sroa.4.0._223.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_223.i, i64 24
  store i32 143, ptr %_227.sroa.4.sroa.5.0._227.sroa.4.0._223.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %86 = getelementptr inbounds i8, ptr %_223.i, i64 80
  store i8 2, ptr %86, align 8, !noalias !2
  %87 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_223.i) #16, !noalias !2
  %_222.0.i = extractvalue { i64, ptr } %87, 0
  %_222.1.i = extractvalue { i64, ptr } %87, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_223.i), !noalias !2
  %88 = tail call fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17hd453c060b3c9d466E(i64 noundef %_222.0.i, ptr noundef %_222.1.i, i64 noundef %_62480176.i, i64 noundef %min_tokens_out) #16
  %_221.0.i = extractvalue { i64, ptr } %88, 0
  %_221.1.i = extractvalue { i64, ptr } %88, 1
  br label %bb185.i

bb77.i:                                           ; preds = %bb243.bb77_crit_edge.i, %bb70.i
  %_235.i = phi i64 [ %_168.i, %bb70.i ], [ %_235.pre.i, %bb243.bb77_crit_edge.i ]
  %_853.sroa.0.0.i = phi i64 [ %_62480176.i, %bb70.i ], [ %_168.i, %bb243.bb77_crit_edge.i ]
  %_854.sroa.0.0.i = phi i64 [ %quote.sroa.0.0.i, %bb70.i ], [ %_63790178.i, %bb243.bb77_crit_edge.i ]
  %_855.sroa.0.0.i = phi i64 [ %_602.i, %bb70.i ], [ %_650.i, %bb243.bb77_crit_edge.i ]
  %_856.sroa.0.0.i = phi i64 [ %creator_fee.sroa.0.0.i, %bb70.i ], [ %creator_fee13.sroa.0.0.i, %bb243.bb77_crit_edge.i ]
  %_234.i = icmp ult i64 %_235.i, %_853.sroa.0.0.i
  br i1 %_234.i, label %bb78.i, label %bb83.i

bb228.i:                                          ; preds = %bb56.i
  %_63792.i = load i64, ptr %.sroa_idx91.i, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_177.i), !noalias !2
  %_640.not.i = icmp eq i64 %_63792.i, 0
  br i1 %_640.not.i, label %bb230.i, label %bb229.i

bb227.i:                                          ; preds = %bb56.i
  %_638.1.i = load ptr, ptr %.sroa_idx91.i, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_177.i), !noalias !2
  br label %bb185.i

bb230.i:                                          ; preds = %bb228.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_185.i), !noalias !2
  call void @_ZN14pump_recovered11legacy_sell8fee_math3fee17h1cb7f4ca1fd3d0a4E(ptr noalias nocapture noundef nonnull sret([16 x i8]) align 8 dereferenceable(16) %_185.i, i64 noundef %_63790178.i, i64 noundef %._580.sroa.6.0.copyload.i) #16, !noalias !2
  %89 = load i64, ptr %_185.i, align 8, !range !7, !noalias !2, !noundef !5
  %90 = icmp eq i64 %89, 2
  %91 = getelementptr inbounds i8, ptr %_185.i, i64 8
  br i1 %90, label %bb233.i, label %bb232.i

bb229.i:                                          ; preds = %bb228.i
  %92 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 25) #16, !noalias !2
  %_648.0.i = extractvalue { i64, ptr } %92, 0
  %_648.1.i = extractvalue { i64, ptr } %92, 1
  br label %bb185.i

bb233.i:                                          ; preds = %bb230.i
  %_650.i = load i64, ptr %91, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_185.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_191.i), !noalias !2
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_191.i, i8 0, i64 32, i1 false), !noalias !2
  %93 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_589.i, ptr noundef nonnull dereferenceable(32) %_191.i, i64 32), !noalias !2
  %.not179.i = icmp eq i32 %93, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_191.i), !noalias !2
  br i1 %.not179.i, label %bb62.i, label %bb59.i

bb232.i:                                          ; preds = %bb230.i
  %_651.1.i = load ptr, ptr %91, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_185.i), !noalias !2
  br label %bb185.i

bb59.i:                                           ; preds = %bb233.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_193.i), !noalias !2
  call void @_ZN14pump_recovered11legacy_sell8fee_math3fee17h1cb7f4ca1fd3d0a4E(ptr noalias nocapture noundef nonnull sret([16 x i8]) align 8 dereferenceable(16) %_193.i, i64 noundef %_63790178.i, i64 noundef %._580.sroa.7.0.copyload.i) #16, !noalias !2
  %94 = load i64, ptr %_193.i, align 8, !range !7, !noalias !2, !noundef !5
  %95 = icmp eq i64 %94, 2
  %96 = getelementptr inbounds i8, ptr %_193.i, i64 8
  br i1 %95, label %bb237.i, label %bb236.i

bb62.i:                                           ; preds = %bb237.i, %bb233.i
  %creator_fee13.sroa.0.0.i = phi i64 [ %_659.i, %bb237.i ], [ 0, %bb233.i ]
  %97 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %_63790178.i, i64 %_650.i)
  %_666.1.i = extractvalue { i64, i1 } %97, 1
  br i1 %_666.1.i, label %bb172.i, label %bb240.i

bb237.i:                                          ; preds = %bb59.i
  %_659.i = load i64, ptr %96, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_193.i), !noalias !2
  br label %bb62.i

bb236.i:                                          ; preds = %bb59.i
  %_660.1.i = load ptr, ptr %96, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_193.i), !noalias !2
  br label %bb185.i

bb240.i:                                          ; preds = %bb62.i
  %_666.0.i = extractvalue { i64, i1 } %97, 0
  %98 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %_666.0.i, i64 %creator_fee13.sroa.0.0.i)
  %_674.0.i = extractvalue { i64, i1 } %98, 0
  %_674.1.i = extractvalue { i64, i1 } %98, 1
  br i1 %_674.1.i, label %bb172.i, label %bb243.i

bb243.i:                                          ; preds = %bb240.i
  %_207.i = icmp ugt i64 %_674.0.i, %spendable_sol_in
  br i1 %_207.i, label %bb63.i, label %bb243.bb77_crit_edge.i

bb243.bb77_crit_edge.i:                           ; preds = %bb243.i
  %_235.pre.i = load i64, ptr %80, align 8, !noalias !2
  br label %bb77.i

bb63.i:                                           ; preds = %bb243.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_210.i), !noalias !2
  %99 = getelementptr inbounds i8, ptr %_210.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %99, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2e38410fced2c310c68bdf2d45d0c3bd) #16, !noalias !2
  %100 = getelementptr inbounds i8, ptr %_210.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %100, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2e38410fced2c310c68bdf2d45d0c3bd) #16, !noalias !2
  %101 = getelementptr inbounds i8, ptr %_210.i, i64 152
  store i32 6002, ptr %101, align 8, !noalias !2
  store i64 0, ptr %_210.i, align 8, !noalias !2
  %_214.sroa.4.0._210.sroa_idx.i = getelementptr inbounds i8, ptr %_210.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_214.sroa.4.0._210.sroa_idx.i, align 8, !noalias !2
  %_214.sroa.4.sroa.4.0._214.sroa.4.0._210.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_210.i, i64 16
  store i64 24, ptr %_214.sroa.4.sroa.4.0._214.sroa.4.0._210.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_214.sroa.4.sroa.5.0._214.sroa.4.0._210.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_210.i, i64 24
  store i32 133, ptr %_214.sroa.4.sroa.5.0._214.sroa.4.0._210.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %102 = getelementptr inbounds i8, ptr %_210.i, i64 80
  store i8 2, ptr %102, align 8, !noalias !2
  %103 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_210.i) #16, !noalias !2
  %_209.0.i = extractvalue { i64, ptr } %103, 0
  %_209.1.i = extractvalue { i64, ptr } %103, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_210.i), !noalias !2
  %104 = tail call fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17hd453c060b3c9d466E(i64 noundef %_209.0.i, ptr noundef %_209.1.i, i64 noundef %spendable_sol_in, i64 noundef %_674.0.i) #16
  %_208.0.i = extractvalue { i64, ptr } %104, 0
  %_208.1.i = extractvalue { i64, ptr } %104, 1
  br label %bb185.i

bb83.i:                                           ; preds = %bb77.i
  %105 = getelementptr inbounds i8, ptr %_528.i, i64 872
  %_255.i = load i64, ptr %105, align 8, !noalias !2, !noundef !5
  %_683.not.i = icmp ult i64 %_255.i, %_853.sroa.0.0.i
  br i1 %_683.not.i, label %bb250.i, label %bb249.i

bb78.i:                                           ; preds = %bb77.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_240.i), !noalias !2
  %106 = getelementptr inbounds i8, ptr %_240.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %106, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_9032913b93df2a93f8a032d18ba5abf9) #16, !noalias !2
  %107 = getelementptr inbounds i8, ptr %_240.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %107, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_9032913b93df2a93f8a032d18ba5abf9) #16, !noalias !2
  %108 = getelementptr inbounds i8, ptr %_240.i, i64 152
  store i32 6021, ptr %108, align 8, !noalias !2
  store i64 0, ptr %_240.i, align 8, !noalias !2
  %_244.sroa.4.0._240.sroa_idx.i = getelementptr inbounds i8, ptr %_240.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_244.sroa.4.0._240.sroa_idx.i, align 8, !noalias !2
  %_244.sroa.4.sroa.4.0._244.sroa.4.0._240.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_240.i, i64 16
  store i64 24, ptr %_244.sroa.4.sroa.4.0._244.sroa.4.0._240.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_244.sroa.4.sroa.5.0._244.sroa.4.0._240.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_240.i, i64 24
  store i32 151, ptr %_244.sroa.4.sroa.5.0._244.sroa.4.0._240.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %109 = getelementptr inbounds i8, ptr %_240.i, i64 80
  store i8 2, ptr %109, align 8, !noalias !2
  %110 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_240.i) #16, !noalias !2
  %_239.0.i = extractvalue { i64, ptr } %110, 0
  %_239.1.i = extractvalue { i64, ptr } %110, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_240.i), !noalias !2
  %_249.i = load i64, ptr %80, align 8, !noalias !2, !noundef !5
  %111 = tail call fastcc { i64, ptr } @_ZN11anchor_lang5error5Error11with_values17hd453c060b3c9d466E(i64 noundef %_239.0.i, ptr noundef %_239.1.i, i64 noundef %_249.i, i64 noundef %_853.sroa.0.0.i) #16
  %_238.0.i = extractvalue { i64, ptr } %111, 0
  %_238.1.i = extractvalue { i64, ptr } %111, 1
  br label %bb185.i

bb250.i:                                          ; preds = %bb83.i
  %112 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 24) #16, !noalias !2
  %_690.0.i = extractvalue { i64, ptr } %112, 0
  %_690.1.i = extractvalue { i64, ptr } %112, 1
  br label %bb185.i

bb249.i:                                          ; preds = %bb83.i
  %_684.i = sub nuw i64 %_255.i, %_853.sroa.0.0.i
  store i64 %_684.i, ptr %105, align 8, !noalias !2
  %113 = getelementptr inbounds i8, ptr %_528.i, i64 880
  %_264.i = load i64, ptr %113, align 8, !noalias !2, !noundef !5
  %114 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %_264.i, i64 %_854.sroa.0.0.i)
  %_694.1.i = extractvalue { i64, i1 } %114, 1
  br i1 %_694.1.i, label %bb253.i, label %bb84.i

bb253.i:                                          ; preds = %bb249.i
  %115 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 24) #16, !noalias !2
  %_700.0.i = extractvalue { i64, ptr } %115, 0
  %_700.1.i = extractvalue { i64, ptr } %115, 1
  br label %bb185.i

bb84.i:                                           ; preds = %bb249.i
  %_694.0.i = extractvalue { i64, i1 } %114, 0
  store i64 %_694.0.i, ptr %113, align 8, !noalias !2
  %_271.0.i = sub i64 %_235.i, %_853.sroa.0.0.i
  store i64 %_271.0.i, ptr %80, align 8, !noalias !2
  %116 = getelementptr inbounds i8, ptr %_528.i, i64 896
  %_275.i = load i64, ptr %116, align 8, !noalias !2, !noundef !5
  %117 = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %_275.i, i64 %_854.sroa.0.0.i)
  %_704.1.i = extractvalue { i64, i1 } %117, 1
  br i1 %_704.1.i, label %bb257.i, label %bb258.i

bb258.i:                                          ; preds = %bb84.i
  %_704.0.i = extractvalue { i64, i1 } %117, 0
  store i64 %_704.0.i, ptr %116, align 8, !noalias !2
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_286.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_289.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_292.i), !noalias !2
  %118 = getelementptr inbounds i8, ptr %_528.i, i64 232
  %_711.i = load ptr, ptr %118, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_712.i = load ptr, ptr %_711.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_292.i, ptr noundef nonnull align 1 dereferenceable(32) %_712.i, i64 32, i1 false), !noalias !2
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_295.i), !noalias !2
  %119 = getelementptr inbounds i8, ptr %ctx, i64 33
  %_296.i = load i8, ptr %119, align 1, !alias.scope !2, !noundef !5
  store i8 %_296.i, ptr %_295.i, align 1, !noalias !2
  store ptr @alloc_65b7b62d1c393af7ea07c820158a5930, ptr %_289.i, align 8, !noalias !2
  %120 = getelementptr inbounds i8, ptr %_289.i, i64 8
  store i64 13, ptr %120, align 8, !noalias !2
  %121 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_289.i, i64 0, i64 1
  store ptr %_292.i, ptr %121, align 8, !noalias !2
  %122 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_289.i, i64 0, i64 1, i32 1
  store i64 32, ptr %122, align 8, !noalias !2
  %123 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_289.i, i64 0, i64 2
  store ptr %_295.i, ptr %123, align 8, !noalias !2
  %124 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_289.i, i64 0, i64 2, i32 1
  store i64 1, ptr %124, align 8, !noalias !2
  store ptr %_289.i, ptr %_286.i, align 8, !noalias !2
  %125 = getelementptr inbounds i8, ptr %_286.i, i64 8
  store i64 3, ptr %125, align 8, !noalias !2
  %126 = getelementptr inbounds i8, ptr %_528.i, i64 192
  %_714.i = load i8, ptr %126, align 8, !noalias !2, !noundef !5
  %127 = call { i64, ptr } @_ZN14pump_recovered6buy_v215token_transfers25transfer_curve_tokens_ref17h1f421d86260b0d60E(ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %token_program.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(216) %associated_bonding_curve.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(216) %associated_user.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %bonding_curve.i, i8 noundef %_714.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_711.i, i64 noundef %_853.sroa.0.0.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(16) %_286.i) #16, !noalias !2
  %128 = extractvalue { i64, ptr } %127, 0
  %129 = icmp eq i64 %128, 2
  br i1 %129, label %bb262.i, label %bb261.i

bb257.i:                                          ; preds = %bb84.i
  %130 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 24) #16, !noalias !2
  %_710.0.i = extractvalue { i64, ptr } %130, 0
  %_710.1.i = extractvalue { i64, ptr } %130, 1
  br label %bb185.i

bb262.i:                                          ; preds = %bb258.i
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_295.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_292.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_289.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_286.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_299.i), !noalias !2
  %_720.i = load ptr, ptr %_15.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_721.i = load ptr, ptr %_720.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_299.i, ptr noundef nonnull align 1 dereferenceable(32) %_721.i, i64 32, i1 false), !noalias !2
  %_534.i = load ptr, ptr %6, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_724.i = getelementptr inbounds i8, ptr %_534.i, i64 648
  %131 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_299.i, ptr noundef nonnull dereferenceable(32) %_724.i, i64 32), !noalias !2
  %132 = icmp eq i32 %131, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_299.i), !noalias !2
  br i1 %132, label %bb85.i, label %bb88.i

bb261.i:                                          ; preds = %bb258.i
  %133 = extractvalue { i64, ptr } %127, 1
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_295.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_292.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_289.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_286.i), !noalias !2
  br label %bb185.i

bb85.i:                                           ; preds = %bb262.i
  %_725.i = getelementptr inbounds i8, ptr %_528.i, i64 304
  %134 = call fastcc { i64, ptr } @"_ZN11anchor_lang8accounts7account16Account$LT$T$GT$6reload17hc80d8cae2ee31afdE"(ptr noalias noundef nonnull align 8 dereferenceable(184) %_725.i) #16, !noalias !2
  %135 = extractvalue { i64, ptr } %134, 0
  %136 = icmp eq i64 %135, 2
  br i1 %136, label %bb266.i, label %bb265.i

bb88.i:                                           ; preds = %bb271.i, %bb262.i
  %137 = getelementptr inbounds i8, ptr %_528.i, i64 1024
  %_535.i = load ptr, ptr %137, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_317.i), !noalias !2
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_317.i, i8 0, i64 32, i1 false), !noalias !2
  %_740.i = getelementptr inbounds i8, ptr %_535.i, i64 8
  %138 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_740.i, ptr noundef nonnull dereferenceable(32) %_317.i, i64 32), !noalias !2
  %139 = icmp eq i32 %138, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_317.i), !noalias !2
  br i1 %139, label %bb89.i, label %bb91.i

bb266.i:                                          ; preds = %bb85.i
  %_729.i = getelementptr inbounds i8, ptr %_528.i, i64 520
  %140 = call fastcc { i64, ptr } @"_ZN11anchor_lang8accounts7account16Account$LT$T$GT$6reload17hc80d8cae2ee31afdE"(ptr noalias noundef nonnull align 8 dereferenceable(184) %_729.i) #16, !noalias !2
  %141 = extractvalue { i64, ptr } %140, 0
  %142 = icmp eq i64 %141, 2
  br i1 %142, label %bb269.i, label %bb268.i

bb265.i:                                          ; preds = %bb85.i
  %143 = extractvalue { i64, ptr } %134, 1
  br label %bb185.i

bb269.i:                                          ; preds = %bb266.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %quote_mint.i), !noalias !2
  %144 = getelementptr inbounds i8, ptr %_528.i, i64 840
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %quote_mint.i, ptr noundef nonnull align 8 dereferenceable(32) %144, i64 32, i1 false), !noalias !2
  %145 = getelementptr inbounds i8, ptr %_528.i, i64 376
  %_312.i = load i64, ptr %145, align 8, !noalias !2, !noundef !5
  %146 = getelementptr inbounds i8, ptr %_528.i, i64 592
  %_313.i = load i64, ptr %146, align 8, !noalias !2, !noundef !5
  %147 = call { i64, ptr } @"_ZN14pump_recovered21mayhem_virtual_params59_$LT$impl$u20$pump_recovered..trade_types..BondingCurve$GT$27sync_virtual_quote_reserves17hf0f98df7e2783a0dE"(ptr noalias noundef nonnull align 8 dereferenceable(160) %_589.i, i64 noundef %_312.i, i64 noundef %_313.i, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %quote_mint.i) #16, !noalias !2
  %148 = extractvalue { i64, ptr } %147, 0
  %149 = icmp eq i64 %148, 2
  br i1 %149, label %bb271.i, label %bb270.i

bb268.i:                                          ; preds = %bb266.i
  %150 = extractvalue { i64, ptr } %140, 1
  br label %bb185.i

bb271.i:                                          ; preds = %bb269.i
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %quote_mint.i), !noalias !2
  br label %bb88.i

bb270.i:                                          ; preds = %bb269.i
  %151 = extractvalue { i64, ptr } %147, 1
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %quote_mint.i), !noalias !2
  br label %bb185.i

bb89.i:                                           ; preds = %bb88.i
  %_742.i = load ptr, ptr %_15.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_743.i = load ptr, ptr %_742.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_740.i, ptr noundef nonnull align 1 dereferenceable(32) %_743.i, i64 32, i1 false), !noalias !2
  br label %bb91.i

bb91.i:                                           ; preds = %bb89.i, %bb88.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %mint.i), !noalias !2
  %_744.i = load ptr, ptr %118, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_745.i = load ptr, ptr %_744.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %mint.i, ptr noundef nonnull align 1 dereferenceable(32) %_745.i, i64 32, i1 false), !noalias !2
  %152 = icmp eq i64 %_856.sroa.0.0.i, 0
  br i1 %152, label %bb102.i, label %bb92.i

bb102.i:                                          ; preds = %bb282.i, %bb286.i, %bb91.i
  %cashback.sroa.0.0.off0.i = phi i1 [ false, %bb91.i ], [ true, %bb282.i ], [ false, %bb286.i ]
  %_362.i = load ptr, ptr %_14.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %153 = call { i64, ptr } @_ZN14pump_recovered19user_quote_payments21transfer_native_curve17hbd4b0131296ae669E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_362.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_15.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %bonding_curve.i, i64 noundef %_854.sroa.0.0.i) #16, !noalias !2
  %154 = extractvalue { i64, ptr } %153, 0
  %155 = icmp eq i64 %154, 2
  br i1 %155, label %bb290.i, label %bb168.i

bb92.i:                                           ; preds = %bb91.i
  %156 = call { i64, ptr } @_ZN14pump_recovered11legacy_sell22check_bonding_curve_v217h00d092da4006a419E(ptr noalias noundef nonnull readonly align 8 %_530.0.i, i64 noundef %_530.1.i, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) %mint.i) #16, !noalias !2
  %157 = extractvalue { i64, ptr } %156, 0
  %158 = icmp eq i64 %157, 2
  br i1 %158, label %bb275.i, label %bb168.i

bb275.i:                                          ; preds = %bb92.i
  %159 = getelementptr inbounds i8, ptr %_528.i, i64 963
  %160 = load i8, ptr %159, align 1, !range !8, !noalias !2, !noundef !5
  %_325.not.i = icmp eq i8 %160, 0
  br i1 %_325.not.i, label %bb98.i, label %bb94.i

bb98.i:                                           ; preds = %bb275.i
  %_352.i = getelementptr inbounds i8, ptr %_528.i, i64 704
  %161 = call { i64, ptr } @_ZN14pump_recovered10legacy_buy15native_payments18ensure_rent_exempt17h399eeff5d7deb0aeE(ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_14.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_15.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_352.i) #16, !noalias !2
  %162 = extractvalue { i64, ptr } %161, 0
  %163 = icmp eq i64 %162, 2
  br i1 %163, label %bb286.i, label %bb168.i

bb94.i:                                           ; preds = %bb275.i
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_329.i), !noalias !2
  %_537.i = load ptr, ptr %137, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_750.i = load ptr, ptr %_537.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h145eade74514b58aE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_329.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_750.i) #16, !noalias !2
  %_330.i = load ptr, ptr %_14.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %164 = call { i64, ptr } @_ZN14pump_recovered19user_quote_payments21transfer_native_owned17h35ba2fcd8ae234f9E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_330.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_15.i, ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_329.i, i64 noundef %_856.sroa.0.0.i) #16, !noalias !2
  %165 = extractvalue { i64, ptr } %164, 0
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_329.i), !noalias !2
  %166 = icmp eq i64 %165, 2
  br i1 %166, label %bb279.i, label %bb168.i

bb286.i:                                          ; preds = %bb98.i
  %_356.i = load ptr, ptr %_14.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %167 = call { i64, ptr } @_ZN14pump_recovered19user_quote_payments25transfer_native_unchecked17hae799f99e21990eeE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_356.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_15.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_352.i, i64 noundef %_856.sroa.0.0.i) #16, !noalias !2
  %168 = extractvalue { i64, ptr } %167, 0
  %169 = icmp eq i64 %168, 2
  br i1 %169, label %bb102.i, label %bb168.i

bb279.i:                                          ; preds = %bb94.i
  %_538.i = load ptr, ptr %137, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %170 = getelementptr inbounds i8, ptr %_538.i, i64 72
  %_336.i = load i64, ptr %170, align 8, !noalias !2, !noundef !5
  %171 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %_336.i, i64 %_856.sroa.0.0.i)
  %_758.1.i = extractvalue { i64, i1 } %171, 1
  br i1 %_758.1.i, label %bb281.i, label %bb282.i

bb282.i:                                          ; preds = %bb279.i
  %_758.0.i = extractvalue { i64, i1 } %171, 0
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_338.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_339.i), !noalias !2
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_339.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e7ecca184d1801ae8ba4577ecc1a7822) #16, !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_341.i), !noalias !2
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %_341.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e7ecca184d1801ae8ba4577ecc1a7822) #16, !noalias !2
  %172 = getelementptr inbounds i8, ptr %_338.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %172, ptr noundef nonnull align 8 dereferenceable(24) %_339.i, i64 24, i1 false), !noalias !2
  %173 = getelementptr inbounds i8, ptr %_338.i, i64 152
  store i32 6024, ptr %173, align 8, !noalias !2
  %174 = getelementptr inbounds i8, ptr %_338.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %174, ptr noundef nonnull align 8 dereferenceable(24) %_341.i, i64 24, i1 false), !noalias !2
  store i64 0, ptr %_338.i, align 8, !noalias !2
  %_342.sroa.8.0._338.sroa_idx110.i = getelementptr inbounds i8, ptr %_338.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_342.sroa.8.0._338.sroa_idx110.i, align 8, !noalias !2
  %_342.sroa.8.sroa.8.0._342.sroa.8.0._338.sroa_idx110.sroa_idx.i = getelementptr inbounds i8, ptr %_338.i, i64 16
  store i64 24, ptr %_342.sroa.8.sroa.8.0._342.sroa.8.0._338.sroa_idx110.sroa_idx.i, align 8, !noalias !2
  %_342.sroa.8.sroa.10.0._342.sroa.8.0._338.sroa_idx110.sroa_idx.i = getelementptr inbounds i8, ptr %_338.i, i64 24
  store i32 232, ptr %_342.sroa.8.sroa.10.0._342.sroa.8.0._338.sroa_idx110.sroa_idx.i, align 8, !noalias !2
  %175 = getelementptr inbounds i8, ptr %_338.i, i64 80
  store i8 2, ptr %175, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_341.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_339.i), !noalias !2
  %176 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_338.i) #16, !noalias !2
  %177 = extractvalue { i64, ptr } %176, 0
  %178 = extractvalue { i64, ptr } %176, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_338.i), !noalias !2
  call fastcc void @"_ZN4core3ptr46drop_in_place$LT$anchor_lang..error..Error$GT$17h710146501a239d49E"(i64 %177, ptr %178) #16
  %_539.i = load ptr, ptr %137, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %179 = getelementptr inbounds i8, ptr %_539.i, i64 72
  store i64 %_758.0.i, ptr %179, align 8, !noalias !2
  br label %bb102.i

bb281.i:                                          ; preds = %bb279.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_338.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_339.i), !noalias !2
  call void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_339.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e7ecca184d1801ae8ba4577ecc1a7822) #16, !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_341.i), !noalias !2
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %_341.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e7ecca184d1801ae8ba4577ecc1a7822) #16, !noalias !2
  %180 = getelementptr inbounds i8, ptr %_338.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %180, ptr noundef nonnull align 8 dereferenceable(24) %_339.i, i64 24, i1 false), !noalias !2
  %181 = getelementptr inbounds i8, ptr %_338.i, i64 152
  store i32 6024, ptr %181, align 8, !noalias !2
  %182 = getelementptr inbounds i8, ptr %_338.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %182, ptr noundef nonnull align 8 dereferenceable(24) %_341.i, i64 24, i1 false), !noalias !2
  store i64 0, ptr %_338.i, align 8, !noalias !2
  %_342.sroa.8.0._338.sroa_idx.i = getelementptr inbounds i8, ptr %_338.i, i64 8
  store ptr @alloc_3239b484319fa41f90ac18623353bb60, ptr %_342.sroa.8.0._338.sroa_idx.i, align 8, !noalias !2
  %_342.sroa.8.sroa.8.0._342.sroa.8.0._338.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_338.i, i64 16
  store i64 24, ptr %_342.sroa.8.sroa.8.0._342.sroa.8.0._338.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %_342.sroa.8.sroa.10.0._342.sroa.8.0._338.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_338.i, i64 24
  store i32 232, ptr %_342.sroa.8.sroa.10.0._342.sroa.8.0._338.sroa_idx.sroa_idx.i, align 8, !noalias !2
  %183 = getelementptr inbounds i8, ptr %_338.i, i64 80
  store i8 2, ptr %183, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_341.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_339.i), !noalias !2
  %184 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_338.i) #16, !noalias !2
  %185 = extractvalue { i64, ptr } %184, 0
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_338.i), !noalias !2
  br label %bb168.i

bb290.i:                                          ; preds = %bb102.i
  %_540.i = load ptr, ptr %6, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_369.i = getelementptr inbounds i8, ptr %_540.i, i64 8
  %186 = getelementptr inbounds i8, ptr %_528.i, i64 962
  %187 = load i8, ptr %186, align 2, !range !8, !noalias !2, !noundef !5
  %_370.i = icmp ne i8 %187, 0
  %188 = call { i64, i64 } @_ZN14pump_recovered18split_protocol_fee17hcf8c01015a0dc405E(ptr noalias noundef nonnull readonly align 8 dereferenceable(1080) %_369.i, i64 noundef %_855.sroa.0.0.i, i1 noundef zeroext %_370.i) #16, !noalias !2
  %_368.0.i = extractvalue { i64, i64 } %188, 0
  %_368.1.i = extractvalue { i64, i64 } %188, 1
  %189 = icmp eq i64 %_368.0.i, 0
  br i1 %189, label %bb107.i, label %bb105.i

bb107.i:                                          ; preds = %bb105.i, %bb290.i
  %_380.i = load ptr, ptr %_14.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %190 = call { i64, ptr } @_ZN14pump_recovered19user_quote_payments21transfer_native_curve17hbd4b0131296ae669E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_380.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_15.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %fee_recipient.i, i64 noundef %_368.1.i) #16, !noalias !2
  %191 = extractvalue { i64, ptr } %190, 0
  %192 = icmp eq i64 %191, 2
  br i1 %192, label %bb294.i, label %bb168.i

bb105.i:                                          ; preds = %bb290.i
  %_374.i = load ptr, ptr %_14.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %193 = call { i64, ptr } @_ZN14pump_recovered19user_quote_payments31transfer_native_curve_unchecked17h5787faa769b7ce25E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_374.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_15.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %buyback_fee_recipient.i, i64 noundef %_368.0.i) #16, !noalias !2
  %194 = extractvalue { i64, ptr } %193, 0
  %195 = icmp eq i64 %194, 2
  br i1 %195, label %bb107.i, label %bb168.i

bb294.i:                                          ; preds = %bb107.i
  %virtual_token_reserves.i = load i64, ptr %105, align 8, !noalias !2, !noundef !5
  %virtual_quote_reserves.i = load i64, ptr %113, align 8, !noalias !2, !noundef !5
  %real_token_reserves.i = load i64, ptr %80, align 8, !noalias !2, !noundef !5
  %real_quote_reserves.i = load i64, ptr %116, align 8, !noalias !2, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %creator.i, ptr noundef nonnull align 8 dereferenceable(32) %_589.i, i64 32, i1 false), !noalias !2
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_395.i), !noalias !2
  call void @"_ZN13solana_sysvar5clock71_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_clock..Clock$GT$3get17h968837c5c5c04cc1E"(ptr noalias nocapture noundef nonnull sret([48 x i8]) align 8 dereferenceable(48) %_395.i) #16, !noalias !2
  %_785.i = load i64, ptr %_395.i, align 8, !range !14, !noalias !2, !noundef !5
  %trunc181.not.i = icmp eq i64 %_785.i, 0
  br i1 %trunc181.not.i, label %bb296.i, label %bb295.i

bb296.i:                                          ; preds = %bb294.i
  %_786.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %_395.i, i64 40
  %_786.sroa.8.0.copyload.i = load i64, ptr %_786.sroa.8.0..sroa_idx.i, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_395.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 424, ptr nonnull %event.i), !noalias !2
  %_541.i = load ptr, ptr %137, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %196 = getelementptr inbounds i8, ptr %_541.i, i64 40
  %_398.i = load i64, ptr %196, align 8, !noalias !2, !noundef !5
  %197 = getelementptr inbounds i8, ptr %_541.i, i64 48
  %_399.i = load i64, ptr %197, align 8, !noalias !2, !noundef !5
  %198 = getelementptr inbounds i8, ptr %_541.i, i64 56
  %_400.i = load i64, ptr %198, align 8, !noalias !2, !noundef !5
  %199 = getelementptr inbounds i8, ptr %_541.i, i64 64
  %_401.i = load i64, ptr %199, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_402.i)
  %_791.i = load ptr, ptr %_15.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_792.i = load ptr, ptr %_791.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_402.i, ptr noundef nonnull align 1 dereferenceable(32) %_792.i, i64 32, i1 false), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_403.i)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_403.i, ptr noundef nonnull align 1 dereferenceable(32) %mint.i, i64 32, i1 false), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_405.i)
  %_793.i = load ptr, ptr %1, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_794.i = load ptr, ptr %_793.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_405.i, ptr noundef nonnull align 1 dereferenceable(32) %_794.i, i64 32, i1 false), !noalias !2
  %.._580.sroa.7.0.copyload.i = select i1 %cashback.sroa.0.0.off0.i, i64 0, i64 %._580.sroa.7.0.copyload.i
  %_409.sroa.0.0.i = select i1 %cashback.sroa.0.0.off0.i, i64 0, i64 %_856.sroa.0.0.i
  %200 = getelementptr inbounds i8, ptr %_528.i, i64 965
  %201 = load i8, ptr %200, align 1, !range !8, !noalias !2, !noundef !5
  %_413.not.i = icmp eq i8 %201, 0
  %_412.sroa.0.0.i = select i1 %_413.not.i, i64 0, i64 %._580.sroa.7.0.copyload.i
  %_415.sroa.0.0.i = select i1 %_413.not.i, i64 0, i64 %_856.sroa.0.0.i
  %202 = load i64, ptr inttoptr (i64 12884901888 to ptr), align 4294967296, !noalias !16, !noundef !5
  %203 = icmp eq i64 %202, 0
  %204 = call i64 @llvm.usub.sat.i64(i64 %202, i64 16)
  %205 = select i1 %203, i64 12884934640, i64 %204
  %_15.i.i.i.i.i10.i.i.i = icmp ult i64 %205, 12884901896
  br i1 %_15.i.i.i.i.i10.i.i.i, label %bb3.i203.i, label %"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E.exit.i"

bb3.i203.i:                                       ; preds = %bb296.i
  call void @_ZN5alloc7raw_vec12handle_error17h22fdf317f3a37641E(i64 noundef 1, i64 16) #17, !noalias !22
  unreachable

"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E.exit.i": ; preds = %bb296.i
  store i64 %205, ptr inttoptr (i64 12884901888 to ptr), align 4294967296, !noalias !16
  %206 = inttoptr i64 %205 to ptr
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(16) %206, ptr noundef nonnull align 1 dereferenceable(16) @alloc_550d7884d781858aa06fd1f9f6baa933, i64 16, i1 false), !noalias !23
  %207 = load i8, ptr %186, align 2, !range !8, !noalias !2, !noundef !5
  %_422.sroa.0.0.i = select i1 %cashback.sroa.0.0.off0.i, i64 %._580.sroa.7.0.copyload.i, i64 0
  %_424.sroa.0.0.i = select i1 %cashback.sroa.0.0.off0.i, i64 %_856.sroa.0.0.i, i64 0
  %_427.not.i = icmp eq i8 %207, 0
  br i1 %_427.not.i, label %bb129.i, label %bb130.i

bb295.i:                                          ; preds = %bb294.i
  %208 = getelementptr inbounds i8, ptr %_395.i, i64 8
  %_787.sroa.0.0.copyload.i = load i64, ptr %208, align 8, !noalias !2
  %_787.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_395.i, i64 16
  %_787.sroa.5.0.copyload.i = load i64, ptr %_787.sroa.5.0..sroa_idx.i, align 8, !noalias !2
  %_787.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_395.i, i64 24
  %_787.sroa.6.0.copyload.i = load i64, ptr %_787.sroa.6.0..sroa_idx.i, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_395.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_789.i), !noalias !2
  store i64 %_787.sroa.0.0.copyload.i, ptr %_789.i, align 8, !noalias !2
  %residual32.sroa.2.0._789.sroa_idx.i = getelementptr inbounds i8, ptr %_789.i, i64 8
  store i64 %_787.sroa.5.0.copyload.i, ptr %residual32.sroa.2.0._789.sroa_idx.i, align 8, !noalias !2
  %residual32.sroa.3.0._789.sroa_idx.i = getelementptr inbounds i8, ptr %_789.i, i64 16
  store i64 %_787.sroa.6.0.copyload.i, ptr %residual32.sroa.3.0._789.sroa_idx.i, align 8, !noalias !2
  %209 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17h910485bee7169999E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_789.i) #16, !noalias !2
  %_790.0.i = extractvalue { i64, ptr } %209, 0
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_789.i), !noalias !2
  br label %bb168.i

bb129.i:                                          ; preds = %"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E.exit.i"
  %_545.i = load ptr, ptr %6, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %210 = getelementptr inbounds i8, ptr %_545.i, i64 1056
  %211 = load i64, ptr %210, align 8, !noalias !2, !noundef !5
  br label %bb130.i

bb130.i:                                          ; preds = %bb129.i, %"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E.exit.i"
  %_426.sroa.0.0.i = phi i64 [ %211, %bb129.i ], [ 0, %"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E.exit.i" ]
  %212 = getelementptr inbounds i8, ptr %_528.i, i64 840
  %213 = getelementptr inbounds i8, ptr %event.i, i64 328
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %213, ptr noundef nonnull align 8 dereferenceable(32) %212, i64 32, i1 false), !noalias !2
  %214 = getelementptr inbounds i8, ptr %_528.i, i64 920
  %_432.i = load i64, ptr %214, align 8, !noalias !2, !noundef !5
  %215 = getelementptr inbounds i8, ptr %event.i, i64 48
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %215, ptr noundef nonnull align 1 dereferenceable(32) %_403.i, i64 32, i1 false), !noalias !2
  %216 = getelementptr inbounds i8, ptr %event.i, i64 80
  store i64 %_854.sroa.0.0.i, ptr %216, align 8, !noalias !2
  %217 = getelementptr inbounds i8, ptr %event.i, i64 88
  store i64 %_853.sroa.0.0.i, ptr %217, align 8, !noalias !2
  %218 = getelementptr inbounds i8, ptr %event.i, i64 416
  store i8 1, ptr %218, align 8, !noalias !2
  %219 = getelementptr inbounds i8, ptr %event.i, i64 96
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %219, ptr noundef nonnull align 1 dereferenceable(32) %_402.i, i64 32, i1 false), !noalias !2
  %220 = getelementptr inbounds i8, ptr %event.i, i64 128
  store i64 %_786.sroa.8.0.copyload.i, ptr %220, align 8, !noalias !2
  %221 = getelementptr inbounds i8, ptr %event.i, i64 136
  store i64 %virtual_quote_reserves.i, ptr %221, align 8, !noalias !2
  %222 = getelementptr inbounds i8, ptr %event.i, i64 144
  store i64 %virtual_token_reserves.i, ptr %222, align 8, !noalias !2
  %223 = getelementptr inbounds i8, ptr %event.i, i64 152
  store i64 %real_quote_reserves.i, ptr %223, align 8, !noalias !2
  %224 = getelementptr inbounds i8, ptr %event.i, i64 160
  store i64 %real_token_reserves.i, ptr %224, align 8, !noalias !2
  %225 = getelementptr inbounds i8, ptr %event.i, i64 168
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %225, ptr noundef nonnull align 1 dereferenceable(32) %_405.i, i64 32, i1 false), !noalias !2
  %226 = getelementptr inbounds i8, ptr %event.i, i64 200
  store i64 %._580.sroa.6.0.copyload.i, ptr %226, align 8, !noalias !2
  %227 = getelementptr inbounds i8, ptr %event.i, i64 208
  store i64 %_855.sroa.0.0.i, ptr %227, align 8, !noalias !2
  %228 = getelementptr inbounds i8, ptr %event.i, i64 216
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %228, ptr noundef nonnull align 1 dereferenceable(32) %creator.i, i64 32, i1 false), !noalias !2
  %229 = getelementptr inbounds i8, ptr %event.i, i64 248
  store i64 %.._580.sroa.7.0.copyload.i, ptr %229, align 8, !noalias !2
  %230 = getelementptr inbounds i8, ptr %event.i, i64 256
  store i64 %_409.sroa.0.0.i, ptr %230, align 8, !noalias !2
  %231 = getelementptr inbounds i8, ptr %event.i, i64 417
  %232 = zext i1 %track_volume to i8
  store i8 %232, ptr %231, align 1, !noalias !2
  %233 = getelementptr inbounds i8, ptr %event.i, i64 264
  store i64 %_398.i, ptr %233, align 8, !noalias !2
  %234 = getelementptr inbounds i8, ptr %event.i, i64 272
  store i64 %_399.i, ptr %234, align 8, !noalias !2
  %235 = getelementptr inbounds i8, ptr %event.i, i64 280
  store i64 %_400.i, ptr %235, align 8, !noalias !2
  %236 = getelementptr inbounds i8, ptr %event.i, i64 288
  store i64 %_401.i, ptr %236, align 8, !noalias !2
  store i64 16, ptr %event.i, align 8, !noalias !2
  %_418.sroa.4.0.event.sroa_idx.i = getelementptr inbounds i8, ptr %event.i, i64 8
  store ptr %206, ptr %_418.sroa.4.0.event.sroa_idx.i, align 8, !noalias !2
  %_418.sroa.5.0.event.sroa_idx.i = getelementptr inbounds i8, ptr %event.i, i64 16
  store i64 16, ptr %_418.sroa.5.0.event.sroa_idx.i, align 8, !noalias !2
  %237 = getelementptr inbounds i8, ptr %event.i, i64 418
  store i8 %207, ptr %237, align 2, !noalias !2
  %238 = getelementptr inbounds i8, ptr %event.i, i64 296
  store i64 %_422.sroa.0.0.i, ptr %238, align 8, !noalias !2
  %239 = getelementptr inbounds i8, ptr %event.i, i64 304
  store i64 %_424.sroa.0.0.i, ptr %239, align 8, !noalias !2
  %240 = getelementptr inbounds i8, ptr %event.i, i64 312
  store i64 %_426.sroa.0.0.i, ptr %240, align 8, !noalias !2
  %241 = getelementptr inbounds i8, ptr %event.i, i64 320
  store i64 %_368.0.i, ptr %241, align 8, !noalias !2
  %242 = getelementptr inbounds i8, ptr %event.i, i64 24
  store i64 0, ptr %242, align 8, !noalias !2
  %_429.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %event.i, i64 32
  store ptr inttoptr (i64 2 to ptr), ptr %_429.sroa.4.0..sroa_idx.i, align 8, !noalias !2
  %_429.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %event.i, i64 40
  store i64 0, ptr %_429.sroa.5.0..sroa_idx.i, align 8, !noalias !2
  %243 = getelementptr inbounds i8, ptr %event.i, i64 360
  store i64 %_854.sroa.0.0.i, ptr %243, align 8, !noalias !2
  %244 = getelementptr inbounds i8, ptr %event.i, i64 368
  store i64 %virtual_quote_reserves.i, ptr %244, align 8, !noalias !2
  %245 = getelementptr inbounds i8, ptr %event.i, i64 376
  store i64 %real_quote_reserves.i, ptr %245, align 8, !noalias !2
  %246 = getelementptr inbounds i8, ptr %event.i, i64 384
  store i64 %_412.sroa.0.0.i, ptr %246, align 8, !noalias !2
  %247 = getelementptr inbounds i8, ptr %event.i, i64 392
  store i64 %_415.sroa.0.0.i, ptr %247, align 8, !noalias !2
  %248 = getelementptr inbounds i8, ptr %event.i, i64 400
  store i64 %_432.i, ptr %248, align 8, !noalias !2
  %249 = getelementptr inbounds i8, ptr %event.i, i64 408
  store i64 0, ptr %249, align 8, !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_405.i)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_403.i)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_402.i)
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_437.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_439.i), !noalias !2
  call void @"_ZN65_$LT$pump_recovered..TradeEvent$u20$as$u20$anchor_lang..Event$GT$4data17h0aa4d5636074277cE"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_439.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(424) %event.i) #16, !noalias !2
  %250 = getelementptr inbounds i8, ptr %_439.i, i64 8
  %_799.i = load ptr, ptr %250, align 8, !noalias !2, !nonnull !5, !noundef !5
  %251 = getelementptr inbounds i8, ptr %_439.i, i64 16
  %_798.i = load i64, ptr %251, align 8, !noalias !2, !noundef !5
  store ptr %_799.i, ptr %_437.i, align 8, !noalias !2
  %252 = getelementptr inbounds i8, ptr %_437.i, i64 8
  store i64 %_798.i, ptr %252, align 8, !noalias !2
  call void @_ZN14solana_program3log12sol_log_data17hf0beebd5f5883a69E(ptr noalias noundef nonnull readonly align 8 %_437.i, i64 noundef 1) #16, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_439.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_437.i), !noalias !2
  %_442.i = getelementptr inbounds i8, ptr %_528.i, i64 752
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h145eade74514b58aE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %authority_info.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_442.i) #16, !noalias !2
  %253 = getelementptr inbounds i8, ptr %ctx, i64 35
  %authority_bump.i = load i8, ptr %253, align 1, !alias.scope !2, !noundef !5
  call void @"_ZN65_$LT$pump_recovered..TradeEvent$u20$as$u20$anchor_lang..Event$GT$4data17h0aa4d5636074277cE"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %inner_data.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(424) %event.i) #16, !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ix_data.i), !noalias !2
  %me.sroa.0.0.copyload.i.i = load i64, ptr %inner_data.i, align 8, !alias.scope !24, !noalias !27
  %me.sroa.4.0.self.sroa_idx.i.i = getelementptr inbounds i8, ptr %inner_data.i, i64 8
  %me.sroa.4.0.copyload.i.i = load ptr, ptr %me.sroa.4.0.self.sroa_idx.i.i, align 8, !alias.scope !24, !noalias !27, !nonnull !5, !noundef !5
  %me.sroa.5.0.self.sroa_idx.i.i = getelementptr inbounds i8, ptr %inner_data.i, i64 16
  %me.sroa.5.0.copyload.i.i = load i64, ptr %me.sroa.5.0.self.sroa_idx.i.i, align 8, !alias.scope !24, !noalias !27
  %_18.i.i = getelementptr inbounds i8, ptr %me.sroa.4.0.copyload.i.i, i64 %me.sroa.5.0.copyload.i.i
  %254 = getelementptr inbounds i8, ptr %_448.i, i64 32
  store ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, ptr %254, align 8, !noalias !2
  %255 = getelementptr inbounds i8, ptr %_448.i, i64 40
  store ptr getelementptr inbounds (<{ [8 x i8] }>, ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, i64 1, i32 0, i64 0), ptr %255, align 8, !noalias !2
  store ptr %me.sroa.4.0.copyload.i.i, ptr %_448.i, align 8, !noalias !2
  %_809.sroa.4.0._448.sroa_idx.i = getelementptr inbounds i8, ptr %_448.i, i64 8
  store ptr %me.sroa.4.0.copyload.i.i, ptr %_809.sroa.4.0._448.sroa_idx.i, align 8, !noalias !2
  %_809.sroa.5.0._448.sroa_idx.i = getelementptr inbounds i8, ptr %_448.i, i64 16
  store i64 %me.sroa.0.0.copyload.i.i, ptr %_809.sroa.5.0._448.sroa_idx.i, align 8, !noalias !2
  %_809.sroa.6.0._448.sroa_idx.i = getelementptr inbounds i8, ptr %_448.i, i64 24
  store ptr %_18.i.i, ptr %_809.sroa.6.0._448.sroa_idx.i, align 8, !noalias !2
  call fastcc void @"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h034825742f19c3e8E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %ix_data.i, ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_448.i) #16, !noalias !2
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %ix.i), !noalias !2
  %256 = getelementptr inbounds i8, ptr %ix_data.i, i64 8
  %_812.i = load ptr, ptr %256, align 8, !noalias !2, !nonnull !5, !noundef !5
  %257 = getelementptr inbounds i8, ptr %ix_data.i, i64 16
  %_811.i = load i64, ptr %257, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_456.i), !noalias !2
  %_458.i = call fastcc noundef ptr @_ZN5alloc5alloc15exchange_malloc17h6cd8dd11b0e3424eE(i64 noundef 34, i64 noundef 1) #16, !noalias !2
  %_546.i = load ptr, ptr %authority_info.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_458.i, ptr noundef nonnull align 1 dereferenceable(32) %_546.i, i64 32, i1 false), !noalias !2
  %_460.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_458.i, i64 32
  store i8 1, ptr %_460.sroa.4.0..sroa_idx.i, align 1, !noalias !2
  %_460.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_458.i, i64 33
  store i8 0, ptr %_460.sroa.5.0..sroa_idx.i, align 1, !noalias !2
  store i64 1, ptr %_456.i, align 8, !alias.scope !29, !noalias !32
  %258 = getelementptr inbounds i8, ptr %_456.i, i64 8
  store ptr %_458.i, ptr %258, align 8, !alias.scope !29, !noalias !32
  %259 = getelementptr inbounds i8, ptr %_456.i, i64 16
  store i64 1, ptr %259, align 8, !alias.scope !29, !noalias !32
  call void @_ZN18solana_instruction11Instruction14new_with_bytes17h75dd3858b6c4693eE(ptr noalias nocapture noundef nonnull sret([80 x i8]) align 8 dereferenceable(80) %ix.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h35b1dab65cd91d3eE, ptr noalias noundef nonnull readonly align 1 %_812.i, i64 noundef %_811.i, ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_456.i) #16, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_456.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_468.i), !noalias !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_468.i, ptr noundef nonnull align 8 dereferenceable(48) %authority_info.i, i64 48, i1 false), !noalias !2
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_471.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_474.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_478.i), !noalias !2
  store i8 %authority_bump.i, ptr %_478.i, align 1, !noalias !2
  store ptr @alloc_7a7952b5e0d15f2b72d0341cef6d4739, ptr %_474.i, align 8, !noalias !2
  %260 = getelementptr inbounds i8, ptr %_474.i, i64 8
  store i64 17, ptr %260, align 8, !noalias !2
  %261 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_474.i, i64 0, i64 1
  store ptr %_478.i, ptr %261, align 8, !noalias !2
  %262 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_474.i, i64 0, i64 1, i32 1
  store i64 1, ptr %262, align 8, !noalias !2
  store ptr %_474.i, ptr %_471.i, align 8, !noalias !2
  %263 = getelementptr inbounds i8, ptr %_471.i, i64 8
  store i64 2, ptr %263, align 8, !noalias !2
  call void @_ZN14solana_program7program13invoke_signed17ha5e7299f76b436f1E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_464.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %ix.i, ptr noalias noundef nonnull readonly align 8 %_468.i, i64 noundef 1, ptr noalias noundef nonnull readonly align 8 %_471.i, i64 noundef 1) #16, !noalias !2
  %264 = load i64, ptr %_464.i, align 8, !range !34, !noalias !2, !noundef !5
  %265 = icmp eq i64 %264, -9223372036854775782
  br i1 %265, label %bb303.i, label %bb302.i

bb303.i:                                          ; preds = %bb130.i
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_478.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_474.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_471.i), !noalias !2
  %266 = getelementptr inbounds i8, ptr %_468.i, i64 8
  %_468.val201.i = load ptr, ptr %266, align 8, !noalias !2, !nonnull !5, !noundef !5
  %267 = getelementptr inbounds i8, ptr %_468.i, i64 16
  %_468.val202.i = load ptr, ptr %267, align 8, !noalias !2
  %self1.val.i.i.i.i.i = load i64, ptr %_468.val201.i, align 8, !noalias !2, !noundef !5
  %val.i.i.i.i.i = add i64 %self1.val.i.i.i.i.i, -1
  store i64 %val.i.i.i.i.i, ptr %_468.val201.i, align 8, !noalias !2
  %268 = icmp eq i64 %val.i.i.i.i.i, 0
  br i1 %268, label %bb1.i.i.i.i.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i.i"

bb1.i.i.i.i.i:                                    ; preds = %bb303.i
  %269 = getelementptr i8, ptr %_468.val201.i, i64 8
  %self2.val.i.i.i.i.i = load i64, ptr %269, align 8, !noalias !2, !noundef !5
  %val6.i.i.i.i.i = add i64 %self2.val.i.i.i.i.i, -1
  store i64 %val6.i.i.i.i.i, ptr %269, align 8, !noalias !2
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i.i": ; preds = %bb1.i.i.i.i.i, %bb303.i
  %270 = icmp ne ptr %_468.val202.i, null
  call void @llvm.assume(i1 %270)
  %self1.val.i.i2.i.i.i = load i64, ptr %_468.val202.i, align 8, !noalias !2, !noundef !5
  %val.i.i3.i.i.i = add i64 %self1.val.i.i2.i.i.i, -1
  store i64 %val.i.i3.i.i.i, ptr %_468.val202.i, align 8, !noalias !2
  %271 = icmp eq i64 %val.i.i3.i.i.i, 0
  br i1 %271, label %bb1.i.i4.i.i.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit.i"

bb1.i.i4.i.i.i:                                   ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i.i"
  %272 = getelementptr i8, ptr %_468.val202.i, i64 8
  %self2.val.i.i5.i.i.i = load i64, ptr %272, align 8, !noalias !2, !noundef !5
  %val6.i.i6.i.i.i = add i64 %self2.val.i.i5.i.i.i, -1
  store i64 %val6.i.i6.i.i.i, ptr %272, align 8, !noalias !2
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit.i": ; preds = %bb1.i.i4.i.i.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_468.i), !noalias !2
  %_1.val.i.i = load i64, ptr %ix.i, align 8, !alias.scope !35, !noalias !2, !noundef !5
  %273 = icmp eq i64 %_1.val.i.i, 0
  br i1 %273, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i.i", label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit.i"
  %274 = getelementptr inbounds i8, ptr %ix.i, i64 8
  %_1.val2.i.i = load ptr, ptr %274, align 8, !alias.scope !35, !noalias !2
  %275 = icmp ne ptr %_1.val2.i.i, null
  call void @llvm.assume(i1 %275)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i.i": ; preds = %bb2.i.i.i.i.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit.i"
  %276 = getelementptr inbounds i8, ptr %ix.i, i64 24
  %.val.i.i = load i64, ptr %276, align 8, !alias.scope !35, !noalias !2, !noundef !5
  %277 = icmp eq i64 %.val.i.i, 0
  br i1 %277, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i.i"
  %278 = getelementptr inbounds i8, ptr %ix.i, i64 32
  %.val1.i.i = load ptr, ptr %278, align 8, !alias.scope !35, !noalias !2
  %279 = icmp ne ptr %.val1.i.i, null
  call void @llvm.assume(i1 %279)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data.i), !noalias !2
  %_480.i = load i64, ptr %80, align 8, !noalias !2, !noundef !5
  %280 = icmp eq i64 %_480.i, 0
  br i1 %280, label %bb142.i, label %bb155.i

bb302.i:                                          ; preds = %bb130.i
  %281 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17h910485bee7169999E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_464.i) #16, !noalias !2
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_478.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_474.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_471.i), !noalias !2
  %282 = getelementptr inbounds i8, ptr %_468.i, i64 8
  %_468.val.i = load ptr, ptr %282, align 8, !noalias !2, !nonnull !5, !noundef !5
  %283 = getelementptr inbounds i8, ptr %_468.i, i64 16
  %_468.val197.i = load ptr, ptr %283, align 8, !noalias !2
  %self1.val.i.i.i.i206.i = load i64, ptr %_468.val.i, align 8, !noalias !2, !noundef !5
  %val.i.i.i.i207.i = add i64 %self1.val.i.i.i.i206.i, -1
  store i64 %val.i.i.i.i207.i, ptr %_468.val.i, align 8, !noalias !2
  %284 = icmp eq i64 %val.i.i.i.i207.i, 0
  br i1 %284, label %bb1.i.i.i.i214.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i208.i"

bb1.i.i.i.i214.i:                                 ; preds = %bb302.i
  %285 = getelementptr i8, ptr %_468.val.i, i64 8
  %self2.val.i.i.i.i215.i = load i64, ptr %285, align 8, !noalias !2, !noundef !5
  %val6.i.i.i.i216.i = add i64 %self2.val.i.i.i.i215.i, -1
  store i64 %val6.i.i.i.i216.i, ptr %285, align 8, !noalias !2
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i208.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i208.i": ; preds = %bb1.i.i.i.i214.i, %bb302.i
  %286 = icmp ne ptr %_468.val197.i, null
  call void @llvm.assume(i1 %286)
  %self1.val.i.i2.i.i209.i = load i64, ptr %_468.val197.i, align 8, !noalias !2, !noundef !5
  %val.i.i3.i.i210.i = add i64 %self1.val.i.i2.i.i209.i, -1
  store i64 %val.i.i3.i.i210.i, ptr %_468.val197.i, align 8, !noalias !2
  %287 = icmp eq i64 %val.i.i3.i.i210.i, 0
  br i1 %287, label %bb1.i.i4.i.i211.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit217.i"

bb1.i.i4.i.i211.i:                                ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i208.i"
  %288 = getelementptr i8, ptr %_468.val197.i, i64 8
  %self2.val.i.i5.i.i212.i = load i64, ptr %288, align 8, !noalias !2, !noundef !5
  %val6.i.i6.i.i213.i = add i64 %self2.val.i.i5.i.i212.i, -1
  store i64 %val6.i.i6.i.i213.i, ptr %288, align 8, !noalias !2
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit217.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit217.i": ; preds = %bb1.i.i4.i.i211.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i208.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_468.i), !noalias !2
  %_1.val.i218.i = load i64, ptr %ix.i, align 8, !alias.scope !38, !noalias !2, !noundef !5
  %289 = icmp eq i64 %_1.val.i218.i, 0
  br i1 %289, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i221.i", label %bb2.i.i.i.i219.i

bb2.i.i.i.i219.i:                                 ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit217.i"
  %290 = getelementptr inbounds i8, ptr %ix.i, i64 8
  %_1.val2.i220.i = load ptr, ptr %290, align 8, !alias.scope !38, !noalias !2
  %291 = icmp ne ptr %_1.val2.i220.i, null
  call void @llvm.assume(i1 %291)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i221.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i221.i": ; preds = %bb2.i.i.i.i219.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit217.i"
  %292 = getelementptr inbounds i8, ptr %ix.i, i64 24
  %.val.i222.i = load i64, ptr %292, align 8, !alias.scope !38, !noalias !2, !noundef !5
  %293 = icmp eq i64 %.val.i222.i, 0
  br i1 %293, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit225.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i223.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i223.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i221.i"
  %294 = getelementptr inbounds i8, ptr %ix.i, i64 32
  %.val1.i224.i = load ptr, ptr %294, align 8, !alias.scope !38, !noalias !2
  %295 = icmp ne ptr %.val1.i224.i, null
  call void @llvm.assume(i1 %295)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit225.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit225.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i223.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i221.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data.i), !noalias !2
  br label %bb163.i

bb142.i:                                          ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit.i"
  store i8 1, ptr %17, align 1, !noalias !2
  call void @llvm.lifetime.start.p0(i64 136, ptr nonnull %event34.i), !noalias !2
  %296 = getelementptr inbounds i8, ptr %event34.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %296, ptr noundef nonnull align 1 dereferenceable(32) %mint.i, i64 32, i1 false), !noalias !2
  %_822.i = load ptr, ptr %_15.i, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_823.i = load ptr, ptr %_822.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %event34.i, ptr noundef nonnull align 1 dereferenceable(32) %_823.i, i64 32, i1 false), !noalias !2
  %_824.i = load ptr, ptr %2, align 8, !noalias !2, !nonnull !5, !align !6, !noundef !5
  %_825.i = load ptr, ptr %_824.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  %297 = getelementptr inbounds i8, ptr %event34.i, i64 64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %297, ptr noundef nonnull align 1 dereferenceable(32) %_825.i, i64 32, i1 false), !noalias !2
  %298 = getelementptr inbounds i8, ptr %event34.i, i64 96
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %298, ptr noundef nonnull align 8 dereferenceable(32) %212, i64 32, i1 false), !noalias !2
  %299 = getelementptr inbounds i8, ptr %event34.i, i64 128
  store i64 %_786.sroa.8.0.copyload.i, ptr %299, align 8, !noalias !2
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_489.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_491.i), !noalias !2
  call void @"_ZN81_$LT$pump_recovered..trade_types..CompleteEvent$u20$as$u20$anchor_lang..Event$GT$4data17h723d3bf216fd7573E"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_491.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(136) %event34.i) #16, !noalias !2
  %300 = getelementptr inbounds i8, ptr %_491.i, i64 8
  %_828.i = load ptr, ptr %300, align 8, !noalias !2, !nonnull !5, !noundef !5
  %301 = getelementptr inbounds i8, ptr %_491.i, i64 16
  %_827.i = load i64, ptr %301, align 8, !noalias !2, !noundef !5
  store ptr %_828.i, ptr %_489.i, align 8, !noalias !2
  %302 = getelementptr inbounds i8, ptr %_489.i, i64 8
  store i64 %_827.i, ptr %302, align 8, !noalias !2
  call void @_ZN14solana_program3log12sol_log_data17hf0beebd5f5883a69E(ptr noalias noundef nonnull readonly align 8 %_489.i, i64 noundef 1) #16, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_491.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_489.i), !noalias !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h145eade74514b58aE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %authority_info35.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_442.i) #16, !noalias !2
  call void @"_ZN81_$LT$pump_recovered..trade_types..CompleteEvent$u20$as$u20$anchor_lang..Event$GT$4data17h723d3bf216fd7573E"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %inner_data36.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(136) %event34.i) #16, !noalias !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ix_data37.i), !noalias !2
  %me.sroa.0.0.copyload.i230.i = load i64, ptr %inner_data36.i, align 8, !alias.scope !41, !noalias !44
  %me.sroa.4.0.self.sroa_idx.i231.i = getelementptr inbounds i8, ptr %inner_data36.i, i64 8
  %me.sroa.4.0.copyload.i232.i = load ptr, ptr %me.sroa.4.0.self.sroa_idx.i231.i, align 8, !alias.scope !41, !noalias !44, !nonnull !5, !noundef !5
  %me.sroa.5.0.self.sroa_idx.i233.i = getelementptr inbounds i8, ptr %inner_data36.i, i64 16
  %me.sroa.5.0.copyload.i234.i = load i64, ptr %me.sroa.5.0.self.sroa_idx.i233.i, align 8, !alias.scope !41, !noalias !44
  %_18.i235.i = getelementptr inbounds i8, ptr %me.sroa.4.0.copyload.i232.i, i64 %me.sroa.5.0.copyload.i234.i
  %303 = getelementptr inbounds i8, ptr %_498.i, i64 32
  store ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, ptr %303, align 8, !noalias !2
  %304 = getelementptr inbounds i8, ptr %_498.i, i64 40
  store ptr getelementptr inbounds (<{ [8 x i8] }>, ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, i64 1, i32 0, i64 0), ptr %304, align 8, !noalias !2
  store ptr %me.sroa.4.0.copyload.i232.i, ptr %_498.i, align 8, !noalias !2
  %_838.sroa.4.0._498.sroa_idx.i = getelementptr inbounds i8, ptr %_498.i, i64 8
  store ptr %me.sroa.4.0.copyload.i232.i, ptr %_838.sroa.4.0._498.sroa_idx.i, align 8, !noalias !2
  %_838.sroa.5.0._498.sroa_idx.i = getelementptr inbounds i8, ptr %_498.i, i64 16
  store i64 %me.sroa.0.0.copyload.i230.i, ptr %_838.sroa.5.0._498.sroa_idx.i, align 8, !noalias !2
  %_838.sroa.6.0._498.sroa_idx.i = getelementptr inbounds i8, ptr %_498.i, i64 24
  store ptr %_18.i235.i, ptr %_838.sroa.6.0._498.sroa_idx.i, align 8, !noalias !2
  call fastcc void @"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h034825742f19c3e8E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %ix_data37.i, ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_498.i) #16, !noalias !2
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %ix38.i), !noalias !2
  %305 = getelementptr inbounds i8, ptr %ix_data37.i, i64 8
  %_841.i = load ptr, ptr %305, align 8, !noalias !2, !nonnull !5, !noundef !5
  %306 = getelementptr inbounds i8, ptr %ix_data37.i, i64 16
  %_840.i = load i64, ptr %306, align 8, !noalias !2, !noundef !5
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_504.i), !noalias !2
  %_506.i = call fastcc noundef ptr @_ZN5alloc5alloc15exchange_malloc17h6cd8dd11b0e3424eE(i64 noundef 34, i64 noundef 1) #16, !noalias !2
  %_547.i = load ptr, ptr %authority_info35.i, align 8, !noalias !2, !nonnull !5, !align !15, !noundef !5
  call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_506.i, ptr noundef nonnull align 1 dereferenceable(32) %_547.i, i64 32, i1 false), !noalias !2
  %_508.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_506.i, i64 32
  store i8 1, ptr %_508.sroa.4.0..sroa_idx.i, align 1, !noalias !2
  %_508.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_506.i, i64 33
  store i8 0, ptr %_508.sroa.5.0..sroa_idx.i, align 1, !noalias !2
  store i64 1, ptr %_504.i, align 8, !alias.scope !46, !noalias !49
  %307 = getelementptr inbounds i8, ptr %_504.i, i64 8
  store ptr %_506.i, ptr %307, align 8, !alias.scope !46, !noalias !49
  %308 = getelementptr inbounds i8, ptr %_504.i, i64 16
  store i64 1, ptr %308, align 8, !alias.scope !46, !noalias !49
  call void @_ZN18solana_instruction11Instruction14new_with_bytes17h75dd3858b6c4693eE(ptr noalias nocapture noundef nonnull sret([80 x i8]) align 8 dereferenceable(80) %ix38.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h35b1dab65cd91d3eE, ptr noalias noundef nonnull readonly align 1 %_841.i, i64 noundef %_840.i, ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_504.i) #16, !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_504.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_516.i), !noalias !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_516.i, ptr noundef nonnull align 8 dereferenceable(48) %authority_info35.i, i64 48, i1 false), !noalias !2
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_519.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_522.i), !noalias !2
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_526.i), !noalias !2
  store i8 %authority_bump.i, ptr %_526.i, align 1, !noalias !2
  store ptr @alloc_7a7952b5e0d15f2b72d0341cef6d4739, ptr %_522.i, align 8, !noalias !2
  %309 = getelementptr inbounds i8, ptr %_522.i, i64 8
  store i64 17, ptr %309, align 8, !noalias !2
  %310 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_522.i, i64 0, i64 1
  store ptr %_526.i, ptr %310, align 8, !noalias !2
  %311 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_522.i, i64 0, i64 1, i32 1
  store i64 1, ptr %311, align 8, !noalias !2
  store ptr %_522.i, ptr %_519.i, align 8, !noalias !2
  %312 = getelementptr inbounds i8, ptr %_519.i, i64 8
  store i64 2, ptr %312, align 8, !noalias !2
  call void @_ZN14solana_program7program13invoke_signed17ha5e7299f76b436f1E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_512.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %ix38.i, ptr noalias noundef nonnull readonly align 8 %_516.i, i64 noundef 1, ptr noalias noundef nonnull readonly align 8 %_519.i, i64 noundef 1) #16, !noalias !2
  %313 = load i64, ptr %_512.i, align 8, !range !34, !noalias !2, !noundef !5
  %314 = icmp eq i64 %313, -9223372036854775782
  br i1 %314, label %bb309.i, label %bb308.i

bb309.i:                                          ; preds = %bb142.i
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_526.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_522.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_519.i), !noalias !2
  %315 = getelementptr inbounds i8, ptr %_516.i, i64 8
  %_516.val199.i = load ptr, ptr %315, align 8, !noalias !2, !nonnull !5, !noundef !5
  %316 = getelementptr inbounds i8, ptr %_516.i, i64 16
  %_516.val200.i = load ptr, ptr %316, align 8, !noalias !2
  %self1.val.i.i.i.i236.i = load i64, ptr %_516.val199.i, align 8, !noalias !2, !noundef !5
  %val.i.i.i.i237.i = add i64 %self1.val.i.i.i.i236.i, -1
  store i64 %val.i.i.i.i237.i, ptr %_516.val199.i, align 8, !noalias !2
  %317 = icmp eq i64 %val.i.i.i.i237.i, 0
  br i1 %317, label %bb1.i.i.i.i244.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i238.i"

bb1.i.i.i.i244.i:                                 ; preds = %bb309.i
  %318 = getelementptr i8, ptr %_516.val199.i, i64 8
  %self2.val.i.i.i.i245.i = load i64, ptr %318, align 8, !noalias !2, !noundef !5
  %val6.i.i.i.i246.i = add i64 %self2.val.i.i.i.i245.i, -1
  store i64 %val6.i.i.i.i246.i, ptr %318, align 8, !noalias !2
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i238.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i238.i": ; preds = %bb1.i.i.i.i244.i, %bb309.i
  %319 = icmp ne ptr %_516.val200.i, null
  call void @llvm.assume(i1 %319)
  %self1.val.i.i2.i.i239.i = load i64, ptr %_516.val200.i, align 8, !noalias !2, !noundef !5
  %val.i.i3.i.i240.i = add i64 %self1.val.i.i2.i.i239.i, -1
  store i64 %val.i.i3.i.i240.i, ptr %_516.val200.i, align 8, !noalias !2
  %320 = icmp eq i64 %val.i.i3.i.i240.i, 0
  br i1 %320, label %bb1.i.i4.i.i241.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit247.i"

bb1.i.i4.i.i241.i:                                ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i238.i"
  %321 = getelementptr i8, ptr %_516.val200.i, i64 8
  %self2.val.i.i5.i.i242.i = load i64, ptr %321, align 8, !noalias !2, !noundef !5
  %val6.i.i6.i.i243.i = add i64 %self2.val.i.i5.i.i242.i, -1
  store i64 %val6.i.i6.i.i243.i, ptr %321, align 8, !noalias !2
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit247.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit247.i": ; preds = %bb1.i.i4.i.i241.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i238.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_516.i), !noalias !2
  %_1.val.i248.i = load i64, ptr %ix38.i, align 8, !alias.scope !51, !noalias !2, !noundef !5
  %322 = icmp eq i64 %_1.val.i248.i, 0
  br i1 %322, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i251.i", label %bb2.i.i.i.i249.i

bb2.i.i.i.i249.i:                                 ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit247.i"
  %323 = getelementptr inbounds i8, ptr %ix38.i, i64 8
  %_1.val2.i250.i = load ptr, ptr %323, align 8, !alias.scope !51, !noalias !2
  %324 = icmp ne ptr %_1.val2.i250.i, null
  call void @llvm.assume(i1 %324)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i251.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i251.i": ; preds = %bb2.i.i.i.i249.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit247.i"
  %325 = getelementptr inbounds i8, ptr %ix38.i, i64 24
  %.val.i252.i = load i64, ptr %325, align 8, !alias.scope !51, !noalias !2, !noundef !5
  %326 = icmp eq i64 %.val.i252.i, 0
  br i1 %326, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit255.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i253.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i253.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i251.i"
  %327 = getelementptr inbounds i8, ptr %ix38.i, i64 32
  %.val1.i254.i = load ptr, ptr %327, align 8, !alias.scope !51, !noalias !2
  %328 = icmp ne ptr %.val1.i254.i, null
  call void @llvm.assume(i1 %328)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit255.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit255.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i253.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i251.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix38.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data37.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 136, ptr nonnull %event34.i), !noalias !2
  br label %bb155.i

bb308.i:                                          ; preds = %bb142.i
  %329 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17h910485bee7169999E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_512.i) #16, !noalias !2
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_526.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_522.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_519.i), !noalias !2
  %330 = getelementptr inbounds i8, ptr %_516.i, i64 8
  %_516.val.i = load ptr, ptr %330, align 8, !noalias !2, !nonnull !5, !noundef !5
  %331 = getelementptr inbounds i8, ptr %_516.i, i64 16
  %_516.val198.i = load ptr, ptr %331, align 8, !noalias !2
  %self1.val.i.i.i.i258.i = load i64, ptr %_516.val.i, align 8, !noalias !2, !noundef !5
  %val.i.i.i.i259.i = add i64 %self1.val.i.i.i.i258.i, -1
  store i64 %val.i.i.i.i259.i, ptr %_516.val.i, align 8, !noalias !2
  %332 = icmp eq i64 %val.i.i.i.i259.i, 0
  br i1 %332, label %bb1.i.i.i.i266.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i260.i"

bb1.i.i.i.i266.i:                                 ; preds = %bb308.i
  %333 = getelementptr i8, ptr %_516.val.i, i64 8
  %self2.val.i.i.i.i267.i = load i64, ptr %333, align 8, !noalias !2, !noundef !5
  %val6.i.i.i.i268.i = add i64 %self2.val.i.i.i.i267.i, -1
  store i64 %val6.i.i.i.i268.i, ptr %333, align 8, !noalias !2
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i260.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i260.i": ; preds = %bb1.i.i.i.i266.i, %bb308.i
  %334 = icmp ne ptr %_516.val198.i, null
  call void @llvm.assume(i1 %334)
  %self1.val.i.i2.i.i261.i = load i64, ptr %_516.val198.i, align 8, !noalias !2, !noundef !5
  %val.i.i3.i.i262.i = add i64 %self1.val.i.i2.i.i261.i, -1
  store i64 %val.i.i3.i.i262.i, ptr %_516.val198.i, align 8, !noalias !2
  %335 = icmp eq i64 %val.i.i3.i.i262.i, 0
  br i1 %335, label %bb1.i.i4.i.i263.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit269.i"

bb1.i.i4.i.i263.i:                                ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i260.i"
  %336 = getelementptr i8, ptr %_516.val198.i, i64 8
  %self2.val.i.i5.i.i264.i = load i64, ptr %336, align 8, !noalias !2, !noundef !5
  %val6.i.i6.i.i265.i = add i64 %self2.val.i.i5.i.i264.i, -1
  store i64 %val6.i.i6.i.i265.i, ptr %336, align 8, !noalias !2
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit269.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit269.i": ; preds = %bb1.i.i4.i.i263.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17heb66b278ce1180d5E.exit.i.i260.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_516.i), !noalias !2
  %_1.val.i270.i = load i64, ptr %ix38.i, align 8, !alias.scope !54, !noalias !2, !noundef !5
  %337 = icmp eq i64 %_1.val.i270.i, 0
  br i1 %337, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i273.i", label %bb2.i.i.i.i271.i

bb2.i.i.i.i271.i:                                 ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit269.i"
  %338 = getelementptr inbounds i8, ptr %ix38.i, i64 8
  %_1.val2.i272.i = load ptr, ptr %338, align 8, !alias.scope !54, !noalias !2
  %339 = icmp ne ptr %_1.val2.i272.i, null
  call void @llvm.assume(i1 %339)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i273.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i273.i": ; preds = %bb2.i.i.i.i271.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h3edb24bee85ec507E.exit269.i"
  %340 = getelementptr inbounds i8, ptr %ix38.i, i64 24
  %.val.i274.i = load i64, ptr %340, align 8, !alias.scope !54, !noalias !2, !noundef !5
  %341 = icmp eq i64 %.val.i274.i, 0
  br i1 %341, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit277.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i275.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i275.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i273.i"
  %342 = getelementptr inbounds i8, ptr %ix38.i, i64 32
  %.val1.i276.i = load ptr, ptr %342, align 8, !alias.scope !54, !noalias !2
  %343 = icmp ne ptr %.val1.i276.i, null
  call void @llvm.assume(i1 %343)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit277.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit277.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i275.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17he40c5f195ee1ac87E.exit.i273.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix38.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data37.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 136, ptr nonnull %event34.i), !noalias !2
  br label %bb163.i

bb155.i:                                          ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit255.i", %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit.i"
  %_1.val.i.i.i = load i64, ptr %event.i, align 8, !alias.scope !57, !noalias !2, !noundef !5
  %344 = icmp eq i64 %_1.val.i.i.i, 0
  br i1 %344, label %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i.i": ; preds = %bb155.i
  %_1.val1.i.i.i = load ptr, ptr %_418.sroa.4.0.event.sroa_idx.i, align 8, !alias.scope !57, !noalias !2
  %345 = icmp ne ptr %_1.val1.i.i.i, null
  call void @llvm.assume(i1 %345)
  br label %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit.i"

"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i.i", %bb155.i
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %event.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %mint.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %buyback_fee_recipient.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %bonding_curve.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %fee_recipient.i), !noalias !2
  br label %_ZN14pump_recovered10legacy_buy16buy_exact_sol_in17h56330eb58410ba36E.exit

bb163.i:                                          ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit277.i", %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit225.i"
  %.pn182.i = phi { i64, ptr } [ %329, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit277.i" ], [ %281, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E.exit225.i" ]
  %_0.sroa.0.2.i = extractvalue { i64, ptr } %.pn182.i, 0
  %_1.val.i.i283.i = load i64, ptr %event.i, align 8, !alias.scope !62, !noalias !2, !noundef !5
  %346 = icmp eq i64 %_1.val.i.i283.i, 0
  br i1 %346, label %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit290.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i284.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i284.i": ; preds = %bb163.i
  %_1.val1.i.i285.i = load ptr, ptr %_418.sroa.4.0.event.sroa_idx.i, align 8, !alias.scope !62, !noalias !2
  %347 = icmp ne ptr %_1.val1.i.i285.i, null
  call void @llvm.assume(i1 %347)
  br label %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit290.i"

"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit290.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i284.i", %bb163.i
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %event.i), !noalias !2
  br label %bb168.i

bb168.i:                                          ; preds = %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit290.i", %bb295.i, %bb105.i, %bb107.i, %bb281.i, %bb286.i, %bb94.i, %bb98.i, %bb92.i, %bb102.i
  %.pn294.i = phi { i64, ptr } [ %209, %bb295.i ], [ %.pn182.i, %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit290.i" ], [ %184, %bb281.i ], [ %156, %bb92.i ], [ %161, %bb98.i ], [ %167, %bb286.i ], [ %164, %bb94.i ], [ %153, %bb102.i ], [ %193, %bb105.i ], [ %190, %bb107.i ]
  %_0.sroa.0.4.i = phi i64 [ %_790.0.i, %bb295.i ], [ %_0.sroa.0.2.i, %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit290.i" ], [ %185, %bb281.i ], [ %157, %bb92.i ], [ %162, %bb98.i ], [ %168, %bb286.i ], [ %165, %bb94.i ], [ %154, %bb102.i ], [ %194, %bb105.i ], [ %191, %bb107.i ]
  %_0.sroa.44.4.i = extractvalue { i64, ptr } %.pn294.i, 1
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %mint.i), !noalias !2
  br label %bb185.i

bb172.i:                                          ; preds = %bb240.i, %bb62.i
  %348 = tail call { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef 24) #16, !noalias !2
  %_0.sroa.0.5.i = extractvalue { i64, ptr } %348, 0
  %_0.sroa.44.5.i = extractvalue { i64, ptr } %348, 1
  br label %bb185.i

bb185.i:                                          ; preds = %bb172.i, %bb168.i, %bb270.i, %bb268.i, %bb265.i, %bb261.i, %bb257.i, %bb253.i, %bb250.i, %bb78.i, %bb63.i, %bb236.i, %bb232.i, %bb229.i, %bb227.i, %bb71.i, %bb224.i, %bb222.i, %bb47.i, %bb219.i, %bb213.i, %bb209.i, %bb35.i, %bb205.i, %bb199.i, %bb16.i, %bb10.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E.exit.i", %bb193.i
  %_0.sroa.44.13.i = phi ptr [ %_31.1.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E.exit.i" ], [ %_41.1.i, %bb10.i ], [ %_53.1.i, %bb16.i ], [ %_581.1.i, %bb199.i ], [ %_575.i, %bb193.i ], [ %_600.1.i, %bb205.i ], [ %_98.1.i, %bb35.i ], [ %_603.1.i, %bb209.i ], [ %_612.1.i, %bb213.i ], [ %_139.1.i, %bb47.i ], [ %_622.1.i, %bb219.i ], [ %_221.1.i, %bb71.i ], [ %_651.1.i, %bb232.i ], [ %_238.1.i, %bb78.i ], [ %_700.1.i, %bb253.i ], [ %_710.1.i, %bb257.i ], [ %_0.sroa.44.4.i, %bb168.i ], [ %151, %bb270.i ], [ %150, %bb268.i ], [ %143, %bb265.i ], [ %133, %bb261.i ], [ %_690.1.i, %bb250.i ], [ %_0.sroa.44.5.i, %bb172.i ], [ %_208.1.i, %bb63.i ], [ %_660.1.i, %bb236.i ], [ %_638.1.i, %bb227.i ], [ %_648.1.i, %bb229.i ], [ %_625.1.i, %bb222.i ], [ %_635.1.i, %bb224.i ]
  %_0.sroa.0.13.i = phi i64 [ %_31.0.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E.exit.i" ], [ %_41.0.i, %bb10.i ], [ %_53.0.i, %bb16.i ], [ %_581.0.i, %bb199.i ], [ %13, %bb193.i ], [ %_600.0.i, %bb205.i ], [ %_98.0.i, %bb35.i ], [ %56, %bb209.i ], [ %66, %bb213.i ], [ %_139.0.i, %bb47.i ], [ %_622.0.i, %bb219.i ], [ %_221.0.i, %bb71.i ], [ %89, %bb232.i ], [ %_238.0.i, %bb78.i ], [ %_700.0.i, %bb253.i ], [ %_710.0.i, %bb257.i ], [ %_0.sroa.0.4.i, %bb168.i ], [ %148, %bb270.i ], [ %141, %bb268.i ], [ %135, %bb265.i ], [ %128, %bb261.i ], [ %_690.0.i, %bb250.i ], [ %_0.sroa.0.5.i, %bb172.i ], [ %_208.0.i, %bb63.i ], [ %94, %bb236.i ], [ %_63790178.i, %bb227.i ], [ %_648.0.i, %bb229.i ], [ %_62480176.i, %bb222.i ], [ %_635.0.i, %bb224.i ]
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %buyback_fee_recipient.i), !noalias !2
  br label %bb186.i

bb186.i:                                          ; preds = %bb185.i, %bb192.i, %bb190.i
  %_0.sroa.44.14.i = phi ptr [ %_0.sroa.44.13.i, %bb185.i ], [ %16, %bb192.i ], [ %10, %bb190.i ]
  %_0.sroa.0.14.i = phi i64 [ %_0.sroa.0.13.i, %bb185.i ], [ %8, %bb192.i ], [ %4, %bb190.i ]
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %bonding_curve.i), !noalias !2
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %fee_recipient.i), !noalias !2
  br label %_ZN14pump_recovered10legacy_buy16buy_exact_sol_in17h56330eb58410ba36E.exit

_ZN14pump_recovered10legacy_buy16buy_exact_sol_in17h56330eb58410ba36E.exit: ; preds = %bb186.i, %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit.i"
  %_0.sroa.44.3.i = phi ptr [ %_0.sroa.44.14.i, %bb186.i ], [ undef, %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit.i" ]
  %_0.sroa.0.3.i = phi i64 [ %_0.sroa.0.14.i, %bb186.i ], [ 2, %"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E.exit.i" ]
  %349 = insertvalue { i64, ptr } poison, i64 %_0.sroa.0.3.i, 0
  %350 = insertvalue { i64, ptr } %349, ptr %_0.sroa.44.3.i, 1
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_512.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_498.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data36.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info35.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_464.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_448.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %creator.i)
  ret { i64, ptr } %350
}

; Function Attrs: nounwind
declare hidden void @_ZN14pump_recovered9PumpError4name17h51fd1d4597ee47f5E(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([24 x i8]) align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 4 dereferenceable(4)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden { i64, ptr } @"_ZN14pump_recovered108_$LT$impl$u20$core..convert..From$LT$pump_recovered..PumpError$GT$$u20$for$u20$anchor_lang..error..Error$GT$4from17h8d64914d583c8e8dE"(i32 noundef) unnamed_addr #0

; Function Attrs: nounwind
declare hidden noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17h8d643902cd3d27a2E"(ptr noalias nocapture noundef readonly align 4 dereferenceable(4), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare hidden void @"_ZN65_$LT$pump_recovered..TradeEvent$u20$as$u20$anchor_lang..Event$GT$4data17h0aa4d5636074277cE"(ptr dead_on_unwind noalias nocapture noundef writable writeonly sret([24 x i8]) align 8 dereferenceable(24), ptr noalias nocapture noundef readonly align 8 dereferenceable(424)) unnamed_addr #0

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #7

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare hidden i64 @llvm.uadd.sat.i64(i64, i64) #8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare hidden { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #8

; Function Attrs: cold noreturn nounwind
declare void @_ZN5alloc7raw_vec12handle_error17h22fdf317f3a37641E(i64 noundef, i64) unnamed_addr #9

; Function Attrs: nounwind
declare { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17h910485bee7169999E"(ptr noalias nocapture noundef readonly align 8 dereferenceable(24)) unnamed_addr #0

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare hidden i32 @memcmp(ptr nocapture, ptr nocapture, i64) local_unnamed_addr #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare hidden i64 @llvm.usub.sat.i64(i64, i64) #8

; Function Attrs: nounwind
declare noundef zeroext i1 @"_ZN221_$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$u20$as$u20$core..fmt..Debug$GT$3fmt17hec448305f4a90e51E"(ptr noalias noundef readonly align 8 dereferenceable(24), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare noundef zeroext i1 @"_ZN223_$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$u20$as$u20$core..fmt..Display$GT$3fmt17h90a7b52b4b824722E"(ptr noalias noundef readonly align 8 dereferenceable(24), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare { ptr, i64 } @"_ZN223_$LT$$LT$alloc..boxed..Box$LT$dyn$u20$core..error..Error$u2b$core..marker..Sync$u2b$core..marker..Send$GT$$u20$as$u20$core..convert..From$LT$alloc..string..String$GT$$GT$..from..StringError$u20$as$u20$core..error..Error$GT$11description17hf25e5ff77ea0398dE"(ptr noalias noundef readonly align 8 dereferenceable(24)) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare hidden void @llvm.assume(i1 noundef) #11

; Function Attrs: cold noinline noreturn nounwind
declare void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1, i64 noundef, ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 dereferenceable(24), ptr noalias noundef readonly align 8 dereferenceable(24)) unnamed_addr #12

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #13

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr nocapture writeonly, ptr nocapture readonly, i64, i1 immarg) #7

; Function Attrs: nounwind
declare { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17ha531868a68c48b86E"(ptr noalias nocapture noundef readonly align 8 dereferenceable(160)) unnamed_addr #0

; Function Attrs: nounwind
declare void @"_ZN13solana_sysvar5clock71_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_clock..Clock$GT$3get17h968837c5c5c04cc1E"(ptr dead_on_unwind noalias nocapture noundef writable sret([48 x i8]) align 8 dereferenceable(48)) unnamed_addr #0

; Function Attrs: nounwind
declare void @_ZN14solana_program3log12sol_log_data17hf0beebd5f5883a69E(ptr noalias noundef nonnull readonly align 8, i64 noundef) unnamed_addr #0

; Function Attrs: nounwind
declare void @_ZN18solana_instruction11Instruction14new_with_bytes17h75dd3858b6c4693eE(ptr dead_on_unwind noalias nocapture noundef writable sret([80 x i8]) align 8 dereferenceable(80), ptr noalias nocapture noundef readonly align 1 dereferenceable(32), ptr noalias noundef nonnull readonly align 1, i64 noundef, ptr noalias nocapture noundef readonly align 8 dereferenceable(24)) unnamed_addr #0

; Function Attrs: nounwind
declare void @_ZN14solana_program7program13invoke_signed17ha5e7299f76b436f1E(ptr dead_on_unwind noalias nocapture noundef writable sret([24 x i8]) align 8 dereferenceable(24), ptr noalias noundef readonly align 8 dereferenceable(80), ptr noalias noundef nonnull readonly align 8, i64 noundef, ptr noalias noundef nonnull readonly align 8, i64 noundef) unnamed_addr #0

; Function Attrs: nounwind
declare noundef zeroext i1 @"_ZN58_$LT$std..io..error..Error$u20$as$u20$core..fmt..Debug$GT$3fmt17had9d55c5608fe73bE"(ptr noalias noundef readonly align 8 dereferenceable(8), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nounwind
declare noundef zeroext i1 @"_ZN58_$LT$solana_pubkey..Pubkey$u20$as$u20$core..fmt..Debug$GT$3fmt17h45f9cee000b25b6cE"(ptr noalias noundef readonly align 1 dereferenceable(32), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #14

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #14

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #15

attributes #0 = { nounwind "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #1 = { inlinehint nounwind "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read, inaccessiblemem: write) "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #3 = { inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(none) "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #5 = { inlinehint nounwind memory(readwrite, inaccessiblemem: write) "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #6 = { noinline nounwind "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #7 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { cold noreturn nounwind "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #10 = { mustprogress nofree nounwind willreturn memory(argmem: read) }
attributes #11 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #12 = { cold noinline noreturn nounwind "target-cpu"="generic" "target-features"="+store-imm,+jmp-ext" }
attributes #13 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #14 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #16 = { nounwind }
attributes #17 = { noreturn nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{!"rustc version 1.79.0-dev"}
!2 = !{!3}
!3 = distinct !{!3, !4, !"_ZN14pump_recovered10legacy_buy16buy_exact_sol_in17h56330eb58410ba36E: %ctx"}
!4 = distinct !{!4, !"_ZN14pump_recovered10legacy_buy16buy_exact_sol_in17h56330eb58410ba36E"}
!5 = !{}
!6 = !{i64 8}
!7 = !{i64 0, i64 3}
!8 = !{i8 0, i8 2}
!9 = !{!10, !12, !3}
!10 = distinct !{!10, !11, !"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E: %_0"}
!11 = distinct !{!11, !"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E"}
!12 = distinct !{!12, !11, !"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17hf3143c9adfa65d69E: %self"}
!13 = !{!10, !3}
!14 = !{i64 0, i64 2}
!15 = !{i64 1}
!16 = !{!17, !19, !21, !3}
!17 = distinct !{!17, !18, !"_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$15try_allocate_in17h6d8d89c546cd4bf9E: %_0"}
!18 = distinct !{!18, !"_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$15try_allocate_in17h6d8d89c546cd4bf9E"}
!19 = distinct !{!19, !20, !"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E: %_0"}
!20 = distinct !{!20, !"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E"}
!21 = distinct !{!21, !20, !"_ZN52_$LT$T$u20$as$u20$alloc..slice..hack..ConvertVec$GT$6to_vec17hcb6fd5f4b292df38E: %s.0"}
!22 = !{!19, !21, !3}
!23 = !{!19, !3}
!24 = !{!25}
!25 = distinct !{!25, !26, !"_ZN90_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..collect..IntoIterator$GT$9into_iter17h417d3dbcba736c51E: %self"}
!26 = distinct !{!26, !"_ZN90_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..collect..IntoIterator$GT$9into_iter17h417d3dbcba736c51E"}
!27 = !{!28, !3}
!28 = distinct !{!28, !26, !"_ZN90_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..collect..IntoIterator$GT$9into_iter17h417d3dbcba736c51E: %_0"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"_ZN5alloc5slice4hack8into_vec17h42e54ee532dc4e1bE: %_0"}
!31 = distinct !{!31, !"_ZN5alloc5slice4hack8into_vec17h42e54ee532dc4e1bE"}
!32 = !{!33, !3}
!33 = distinct !{!33, !31, !"_ZN5alloc5slice4hack8into_vec17h42e54ee532dc4e1bE: %b.0"}
!34 = !{i64 0, i64 -9223372036854775781}
!35 = !{!36}
!36 = distinct !{!36, !37, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E: %_1"}
!37 = distinct !{!37, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E"}
!38 = !{!39}
!39 = distinct !{!39, !40, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E: %_1"}
!40 = distinct !{!40, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E"}
!41 = !{!42}
!42 = distinct !{!42, !43, !"_ZN90_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..collect..IntoIterator$GT$9into_iter17h417d3dbcba736c51E: %self"}
!43 = distinct !{!43, !"_ZN90_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..collect..IntoIterator$GT$9into_iter17h417d3dbcba736c51E"}
!44 = !{!45, !3}
!45 = distinct !{!45, !43, !"_ZN90_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..collect..IntoIterator$GT$9into_iter17h417d3dbcba736c51E: %_0"}
!46 = !{!47}
!47 = distinct !{!47, !48, !"_ZN5alloc5slice4hack8into_vec17h42e54ee532dc4e1bE: %_0"}
!48 = distinct !{!48, !"_ZN5alloc5slice4hack8into_vec17h42e54ee532dc4e1bE"}
!49 = !{!50, !3}
!50 = distinct !{!50, !48, !"_ZN5alloc5slice4hack8into_vec17h42e54ee532dc4e1bE: %b.0"}
!51 = !{!52}
!52 = distinct !{!52, !53, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E: %_1"}
!53 = distinct !{!53, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E"}
!54 = !{!55}
!55 = distinct !{!55, !56, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E: %_1"}
!56 = distinct !{!56, !"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17hccb81614544ccbe2E"}
!57 = !{!58, !60}
!58 = distinct !{!58, !59, !"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h53681e21be2b428cE: %_1"}
!59 = distinct !{!59, !"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h53681e21be2b428cE"}
!60 = distinct !{!60, !61, !"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E: %_1"}
!61 = distinct !{!61, !"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E"}
!62 = !{!63, !65}
!63 = distinct !{!63, !64, !"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h53681e21be2b428cE: %_1"}
!64 = distinct !{!64, !"_ZN4core3ptr42drop_in_place$LT$alloc..string..String$GT$17h53681e21be2b428cE"}
!65 = distinct !{!65, !66, !"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E: %_1"}
!66 = distinct !{!66, !"_ZN4core3ptr47drop_in_place$LT$pump_recovered..TradeEvent$GT$17h30f16fc99db84131E"}

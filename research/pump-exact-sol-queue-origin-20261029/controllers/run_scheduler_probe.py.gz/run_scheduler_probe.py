"""Qualify and inspect the diagnostic derivative without executing target code."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,time
D=Path(__file__).resolve().parent;O=D/'scheduler-derivative01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())

def main():
 build=read(O/'build-result.json');tool=O/'llc.exe';assert sha(tool)==build['outputs']['llc.exe']
 assert build['stock_build_unchanged'] and build['stock_source_unchanged']
 s=importlib.util.spec_from_file_location('qualified_codegen',D/'inspect_codegen.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 results=[]
 for name,launchpath in [('baseline',D/'scheduler01/launch.json'),('swapped',D/'extract-order02/swapped-launch.json')]:
  p=O/name;p.mkdir();(p/'temp').mkdir();old=read(launchpath);command=old['command'].copy();parent_tool=Path(command[0]);input_path=Path(command[8]);output=Path(command[command.index('-o')+1]);command[0]=str(tool);command[command.index('-o')+1]=str(p/'target.o')
  assert sha(parent_tool)==old['tool_sha256'];env=old['environment'].copy();env.update(TEMP=str(p/'temp'),TMP=str(p/'temp'))
  launch=dict(command=command,cwd=str(D),environment=env,input_sha256=sha(input_path),tool_sha256=sha(tool),
   parent_launch_sha256=sha(launchpath),parent_object_sha256=sha(output),controller_sha256=sha(Path(__file__)),target_executions=0)
  save(p/'launch.json',launch);start=time.time()
  with(p/'stdout.log').open('wb') as stdout,(p/'stderr.log').open('wb') as stderr:r=subprocess.run(command,cwd=D,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
  result=dict(returncode=r.returncode,seconds=time.time()-start,tool_unchanged=sha(tool)==launch['tool_sha256'],input_unchanged=sha(input_path)==launch['input_sha256'],
   logs={n:dict(bytes=(p/n).stat().st_size,sha256=sha(p/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
  if r.returncode==0:
   obj,raw=m.target(p/'target.o');parent,rawparent=m.target(output)
   result.update(object_sha256=sha(p/'target.o'),complete_object_equal=(p/'target.o').read_bytes()==output.read_bytes(),target_bytes=len(raw),
    target_raw_equal=raw==rawparent,relocations_equal=obj['relocations']==parent['relocations'],relocation_count=len(obj['relocations']))
   save(p/'target-analysis.json',dict(target=obj,parent=parent))
  save(p/'result.json',result);print(json.dumps(dict(name=name,**result)),flush=True)
  assert r.returncode==0 and result['tool_unchanged'] and result['input_unchanged'] and result['complete_object_equal']
  assert result['target_raw_equal'] and result['relocations_equal'] and result['target_bytes']==13224 and result['relocation_count']==144
  results.append(dict(name=name,**result))
 save(O/'qualification.json',dict(result='PASS',runs=results,scope='Logging-only diagnostic derivative; full-object equality to each unmodified compiler control,13224targetbytes/all144relocations. Swapped input is an IR-only counterfactual, not recovered Rust or a production build.'))
if __name__=='__main__':main()

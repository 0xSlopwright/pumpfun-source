"""Build an isolated logging-only llc derivative from qualified existing objects."""
from pathlib import Path
import ctypes,difflib,hashlib,json,re,subprocess,time

D=Path(__file__).resolve().parent;B=D/'build01';O=D/'scheduler-derivative01'
REL='llvm/lib/CodeGen/SelectionDAG/ScheduleDAGRRList.cpp'
SYMBOL='_ZN14pump_recovered14pump_recovered16buy_exact_sol_in17h28eae2e2fdc8f8b2E'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def inv(p):return {f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def argv(s):
 n=ctypes.c_int();parse=ctypes.windll.shell32.CommandLineToArgvW
 parse.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];parse.restype=ctypes.POINTER(ctypes.c_wchar_p)
 a=parse(s,ctypes.byref(n));assert a;out=[a[i] for i in range(n.value)];ctypes.windll.kernel32.LocalFree(a);return out
def inner(s):
 prefix='C:\\WINDOWS\\system32\\cmd.exe /C "cd . && ';suffix=' && cd ."'
 assert s.startswith(prefix) and s.endswith(suffix);return s[len(prefix):-len(suffix)]
def replace_once(text,old,new):
 assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)

def main():
 assert O.is_dir() and not (O/'build-launch.json').exists()
 (O/'temp').mkdir();(O/'int').mkdir()
 stock=(D/'source'/REL).read_text();modified=stock
 helper='''
// Diagnostic derivative only: log actual queue pops, excluding dump() simulations.
static bool SchedulerProbeActive = false;
static bool schedulerProbeDecision(const char *Reason, SUnit *Left,
                                   SUnit *Right, bool Result) {
  LLVM_DEBUG(if (SchedulerProbeActive)
    dbgs() << "SCHED_PROBE decision " << Reason << " left=" << Left->NodeNum
           << " right=" << Right->NodeNum << " left_queue=" << Left->NodeQueueId
           << " right_queue=" << Right->NodeQueueId << " result=" << Result << "\\n");
  return Result;
}
'''
 modified=replace_once(modified,'#define DEBUG_TYPE "pre-RA-sched"','#define DEBUG_TYPE "pre-RA-sched"\n'+helper)
 pop='''    SUnit *V = popFromQueue(Queue, Picker, scheduleDAG);
    V->NodeQueueId = 0;'''
 replacement='''    const bool PreviousProbe = SchedulerProbeActive;
    SchedulerProbeActive = MF.getName() == "'''+SYMBOL+'''";
    LLVM_DEBUG(if (SchedulerProbeActive) {
      dbgs() << "SCHED_PROBE pop";
      for (const SUnit *Item : Queue)
        dbgs() << " " << Item->NodeNum << ":" << Item->NodeQueueId;
      dbgs() << "\\n";
    });
    SUnit *V = popFromQueue(Queue, Picker, scheduleDAG);
    LLVM_DEBUG(if (SchedulerProbeActive)
      dbgs() << "SCHED_PROBE selected " << V->NodeNum << "\\n");
    SchedulerProbeActive = PreviousProbe;
    V->NodeQueueId = 0;'''
 modified=replace_once(modified,pop,replacement)
 replacements=[]
 for name,start,end in [('BURRSort','static bool BURRSort(', '\n// Bottom up'),
                        ('ilp_ls_rr_sort','bool ilp_ls_rr_sort::operator()(', '\nvoid RegReductionPQBase::initNodes')]:
  i=modified.index(start);j=modified.index(end,i);piece=modified[i:j]
  def change(m):
   expr=m[1];reason=name+':'+expr;replacements.append(reason)
   return 'return schedulerProbeDecision('+json.dumps(reason)+', left, right, ('+expr+'));'
  updated=re.sub(r'\breturn ([^;\n]+);',change,piece)
  modified=modified[:i]+updated+modified[j:]
 assert len(replacements)==22,len(replacements)
 path=O/'ScheduleDAGRRList.cpp';path.write_bytes(modified.encode())
 (O/'diagnostic.patch').write_text(''.join(difflib.unified_diff(stock.splitlines(True),modified.splitlines(True),fromfile=REL,tofile=REL)),encoding='utf-8')
 commands=json.loads((O/'stock-commands.json').read_bytes());compile=argv(commands['compile']);archive=argv(inner(commands['archive']));link=argv(inner(commands['link']))
 assert Path(compile[-1]).resolve()==(D/'source'/REL).resolve();compile[-1]=str(path)
 obj=r'lib\CodeGen\SelectionDAG\CMakeFiles\LLVMSelectionDAG.dir\ScheduleDAGRRList.cpp.obj'
 for i,a in enumerate(compile):
  if a.startswith('/Fo'):compile[i]='/Fo'+str(O/'ScheduleDAGRRList.cpp.obj')
  if a.startswith('/Fd'):compile[i]='/Fd'+str(O/'ScheduleDAGRRList.pdb')
 assert archive.count(obj)==1
 archive=[str(O/'ScheduleDAGRRList.cpp.obj') if a==obj else '/out:'+str(O/'LLVMSelectionDAG.lib') if a.lower().startswith('/out:') else a for a in archive]
 for i,a in enumerate(link):
  if a.startswith('--intdir='):link[i]='--intdir='+str(O/'int')
  elif a.lower().startswith('/out:'):link[i]='/out:'+str(O/'llc.exe')
  elif a.lower().startswith('/implib:'):link[i]='/implib:'+str(O/'llc.lib')
  elif a.lower().startswith('/pdb:'):link[i]='/pdb:'+str(O/'llc.pdb')
  elif a==r'lib\LLVMSelectionDAG.lib':link[i]=str(O/'LLVMSelectionDAG.lib')
 # No command-shell wrapper is executed. Every explicit output is in this derivative.
 for command in [compile,archive,link]:
  for a in command:
   for prefix in ['/Fo','/Fd','/out:','/implib:','/pdb:','--intdir=']:
    if a.startswith(prefix):assert Path(a[len(prefix):]).resolve().is_relative_to(O)
 old=json.loads((D/'attempt01/build-launch.json').read_bytes());env=old['environment'].copy();env.update(TEMP=str(O/'temp'),TMP=str(O/'temp'))
 expected=json.loads((D/'source-inventory.json').read_bytes());assert inv(D/'source')==expected
 before=inv(B);save(O/'stock-build-before.json',before)
 plan=dict(source_revision='08aedd64bf3abe4f163407b7bcf680403b84b32d',source_path=REL,stock_source_sha256=sha(D/'source'/REL),
  derivative_source_sha256=sha(path),patch_sha256=sha(O/'diagnostic.patch'),wrapped_return_expressions=replacements,
  commands=dict(compile=compile,archive=archive,link=link),cwd=str(B),environment=env,controller_sha256=sha(Path(__file__)),
  stock_build_inventory_sha256=sha(O/'stock-build-before.json'),stock_source_inventory_sha256=sha(D/'source-inventory.json'),
  scope='Logging-only derivative of one compiler translation unit; reuse qualified stock objects/libraries. Do not overwrite stock source, objects, tools or build metadata. Target output must be separately qualified; no target program execution.')
 save(O/'build-launch.json',plan);results=[]
 for name,command in plan['commands'].items():
  start=time.time()
  with(O/(name+'.stdout.log')).open('wb') as stdout,(O/(name+'.stderr.log')).open('wb') as stderr:
   r=subprocess.run(command,cwd=B,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
  results.append(dict(stage=name,returncode=r.returncode,seconds=time.time()-start,logs={s:sha(O/(name+'.'+s+'.log')) for s in ['stdout','stderr']}))
  save(O/'build-progress.json',results);print(json.dumps(results[-1]),flush=True)
  if r.returncode:break
 result=dict(stages=results,stock_build_unchanged=inv(B)==before,stock_source_unchanged=inv(D/'source')==expected,
  outputs={n:sha(O/n) for n in ['ScheduleDAGRRList.cpp.obj','LLVMSelectionDAG.lib','llc.exe'] if (O/n).exists()})
 save(O/'build-result.json',result)
 assert len(results)==3 and all(r['returncode']==0 for r in results) and result['stock_build_unchanged'] and result['stock_source_unchanged']
 print(json.dumps(dict(result='PASS',tool_sha256=result['outputs']['llc.exe'],stock_build_unchanged=True,stock_source_unchanged=True)),flush=True)
if __name__=='__main__':main()
